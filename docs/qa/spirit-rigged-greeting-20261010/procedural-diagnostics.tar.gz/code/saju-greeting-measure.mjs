import fs from 'node:fs/promises';import * as THREE from '/workspace/saju-project/node_modules/three/build/three.module.js';
import {GLTFLoader} from '/workspace/saju-project/node_modules/three/examples/jsm/loaders/GLTFLoader.js';
const r='/workspace/saju-spirit-greeting-length-preserving-20261010',bytes=await fs.readFile(r+'/public/spirits/jade-v002/body.glb');
const loader=new GLTFLoader().register(()=>({name:'QA_TEXTURE',loadTexture:async()=>new THREE.Texture()}));const gltf=await loader.parseAsync(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),'');
let body;gltf.scene.traverse(o=>{if(o.isMesh&&o.geometry.attributes.position.count===33207)body=o});
const p=body.geometry.attributes.position;
const curve=new THREE.CubicBezierCurve3(new THREE.Vector3(.34,1.17,.08),new THREE.Vector3(.58,1.08,.11),new THREE.Vector3(.68,.92,.15),new THREE.Vector3(.75,.71,.19));
const points=Array.from({length:513},(_,i)=>curve.getPoint(i/512));const arc=[0];for(let i=1;i<points.length;i++)arc.push(arc.at(-1)+points[i].distanceTo(points[i-1]));const L=arc.at(-1);
const rows=[];for(let id=0;id<p.count;id++){const q=new THREE.Vector3().fromBufferAttribute(p,id);if(q.x<.36||q.y<.45||q.y>1.41)continue;let near=0,distance=Infinity;for(let i=0;i<points.length;i++){const d=q.distanceToSquared(points[i]);if(d<distance){distance=d;near=i}} rows.push({id,p:q.toArray(),t:near/512,u:arc[near]/L,r:Math.sqrt(distance)});}
const ranges=Array.from({length:10},(_,i)=>{const a=rows.filter(x=>x.u>=i/10&&x.u<(i+1)/10&&x.r<.16&&x.p[0]>.46);const avg=a.reduce((p,a)=>p.add(new THREE.Vector3(...a.p)),new THREE.Vector3()).multiplyScalar(1/(a.length||1));return{u:i/10,count:a.length,centroid:avg.toArray(),radialRange:[Math.min(...a.map(x=>x.r)),Math.max(...a.map(x=>x.r))]}});
const smoother=x=>{x=Math.max(0,Math.min(1,x));return x*x*x*(x*(x*6-15)+10)};
const centerlines=[];
for(const shoulder of[65,70,75])for(const bend of[65,70,75]){let c=points[0].clone();const cs=[c.clone()];for(let i=1;i<points.length;i++){const u=(arc[i]+arc[i-1])/2/L;const angle=(shoulder*smoother(u/.16)+bend*smoother((u-.10)/.68))*Math.PI/180;const delta=points[i].clone().sub(points[i-1]).applyAxisAngle(new THREE.Vector3(0,0,1),angle);c=c.clone().add(delta);cs.push(c)} centerlines.push({shoulder,bend,endpoint:c.toArray(),at90:cs[460].toArray(),length:cs.slice(1).reduce((s,p,i)=>s+p.distanceTo(cs[i]),0)});}
const result={bodyBounds:body.geometry.boundingBox,originalCurveLength:L,sourceCenterline:curve.points,ranges,centerlines};await fs.writeFile(r+'/outputs/greeting-length-preserving/rest-arm-measurement.json',JSON.stringify(result,null,2)+'\n');await fs.writeFile(r+'/outputs/greeting-length-preserving/vertex-bindings-diagnostic.json',JSON.stringify(rows));console.log(JSON.stringify(result));
