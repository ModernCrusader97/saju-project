**후보 통합 접근 결과 — 2026-10-09 UTC**

사용자가 지정한 두 Library ID로 현재 Library 지침의 준비·전송 흐름을 이 실행 환경에서 직접 실행했습니다. Library 준비 응답은 두 전송을 반환했고 `unavailable_items`와 `warnings`는 비어 있었습니다. 실제 파일 전송은 모두 실패했습니다. 준비 응답만으로 파일이 이 환경에 내려받아졌다고 판단하지 않았습니다.

| 지정 원본 | 확인된 전송 결과 | 로컬 파일 |
| --- | --- | --- |
| SaJu_Mobile_Home_Validated_20261009_0708.zip | 지원 helper 종료 1, `URLError` / `OSError`; 오류만 기록하는 진단에서 프록시 터널 HTTP 403 확인 | 없음 |
| SaJu_Ten_Stem_Material_Commit_a97c418_20261009.zip | 지원 helper 종료 1, `URLError` / `OSError`, `download failed` | 없음 |

목적지 `/workspace/scratch/saju-integration-candidates-20261009`를 직접 읽었고 비어 있음을 확인했습니다. helper 원문은 현재 skill source에서 받아 변경하지 않았습니다. 진단은 표준 라이브러리 예외의 종류/숫자 코드만 기록했습니다. 서명 URL·헤더·비밀값은 보고서에 기록하지 않았습니다. 프록시 거부와 Library 선택 범위 거부를 동일한 오류라고 단정하지 않습니다. Library 준비 자체는 성공했고, 실제 전송 경계에서 차단되었습니다.

별도 원본, 다른 실행기, 직접 curl, GitHub의 같은 후보 소스 조회 등으로 우회하지 않았습니다. 후보 ZIP을 읽을 수 없으므로 내부 원본·Git bundle·patch·독립 커밋 `c5d13cfc61b85526675ed2fb6705bef29856e8ab` 및 `a97c4182ed2b71f9f2ce92fd8d4bc6348073b890`은 확인하지 못했습니다. 제공된 재질 ZIP SHA-256 `816ba284a1c7b4fa7c836c02dacd7be5a02843dabb695c4f02e3cb2e31da8702`도 실물 대조하지 못했습니다.

소스의 현재 기준은 여전히 별도 검증 worktree의 `40f0c9a4b66bcae1c222d33d99cc6f6963e2f573`입니다. 코드 읽기로 `APPROVED_BODY_PRESENTATION_DEPTH = 1.35`, approved GLB loader의 jade 조건이 아직 `day.stem === '을'`임을 확인했습니다. `기`의 현재 소개 문구는 흙빛 도자/토양입니다. 사용자가 승인한 기토=옥·초록빛, 을목=덩굴·잎의 새 연결은 아직 적용되지 않았습니다. 현재 홈은 기존 생년월일 폼과 `window.location.assign`, 내부 `<a>`를 사용하며 최신 후보의 Link/모바일 변경과 실제 대조할 수 없는 상태입니다.

원본 대조, 통합 브랜치 생성, 제품 소스 변경, 로컬 기능 커밋, 후보의 실제 GLB/GPU/전체 빌드 검증은 미실행입니다. 이 접근 시도 이후에도 검증 worktree의 소스는 깨끗하고 기존 원본·잠금파일·합성 DB는 보존되어 있습니다. `2709bb7`의 복원 범위를 확대하지 않았습니다. 사이트/환경 설정 Publish, 외부 LLM, 자격 증명/인증 변경, push/PR/merge는 하지 않았습니다.

다음 진행에는 이 실행 환경에서 두 지정 원본의 실제 바이트를 지원 흐름으로 읽을 수 있어야 합니다. 접근이 해결되면 원본 ZIP과 체크섬을 별도로 보존하고, 기준 `40f0c9a`에서 별도 통합 브랜치를 만든 뒤 홈과 재질을 각각 대조·검증·로컬 커밋합니다. 전체 덩굴 몸체·무토 모래·임수 물보라는 계속 미구현으로 보고합니다.
