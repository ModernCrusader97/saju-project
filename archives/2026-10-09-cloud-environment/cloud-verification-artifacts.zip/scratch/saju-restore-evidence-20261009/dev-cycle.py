#!/usr/bin/env python3
"""Verify two real dev-server lifetimes against a fresh worktree-local D1."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import urllib.error
import urllib.request

project = Path('/workspace/scratch/saju-restore-verify-20261009')
evidence = Path(__file__).resolve().parent
base = 'http://127.0.0.1:5173'
opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
cookie = '__sites_local_auth=1'  # Existing loopback-only synthetic preview identity.
checks = []
servers = []
active = None
log_handle = None
result = {'status': 'FAIL', 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}

def request(path, body=None, authenticated=True):
    assert path.startswith('/') and not path.startswith('//')
    headers = {'Cookie': cookie} if authenticated else {}
    encoded = None
    if body is not None:
        encoded = json.dumps(body).encode()
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(base + path, data=encoded, headers=headers)
    try:
        response = opener.open(req, timeout=20)
    except urllib.error.HTTPError as error:
        response = error
    with response:
        data = response.read()
        if 'application/json' in response.headers.get('content-type', ''):
            data = json.loads(data)
        else:
            data = data.decode(errors='replace')
        return response.status, data

def start(label):
    global active, log_handle
    assert not list(project.glob('.env*')) and not list(project.glob('.dev.vars*'))
    log_path = evidence / f'{label}.log'
    log_handle = log_path.open('x')
    unset_names = [key for key in os.environ if any(part in key.upper() for part in ('API_KEY', 'API_TOKEN', 'GEMINI', 'OPENAI', 'ANTHROPIC'))]
    command = ['env']
    for key in unset_names:
        command.extend(['-u', key])
    command.extend([
        'NEXT_TELEMETRY_DISABLED=1', 'WRANGLER_SEND_METRICS=false',
        'CLOUDFLARE_CF_FETCH_ENABLED=false', 'WRANGLER_WRITE_LOGS=false',
        f'XDG_CONFIG_HOME={evidence / "xdg-config"}',
        'npm', 'run', 'dev', '--', '--hostname', '127.0.0.1', '--port', '5173',
    ])
    active = subprocess.Popen(command, cwd=project, stdout=log_handle, stderr=subprocess.STDOUT, start_new_session=True)
    servers.append({'label': label, 'pid': active.pid, 'log': str(log_path), 'command': ['npm', 'run', 'dev', '--', '--hostname', '127.0.0.1', '--port', '5173']})
    deadline = time.monotonic() + 45
    while time.monotonic() < deadline:
        if active.poll() is not None:
            raise RuntimeError(f'{label} exited before readiness: {active.returncode}; inspect its log')
        try:
            status, html = request('/')
            if status == 200 and isinstance(html, str) and '<html' in html:
                servers[-1]['home_status'] = status
                print(f'{label}: home HTML responded HTTP {status}', flush=True)
                return
        except (OSError, urllib.error.URLError, TimeoutError):
            pass
        time.sleep(.25)
    raise RuntimeError(f'{label} did not become ready in 45 seconds')

def stop():
    global active, log_handle
    if active is None:
        return
    process = active
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=8)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=4)
    servers[-1]['stop_exit_code'] = process.returncode
    log_handle.close()
    active = None
    log_handle = None
    # Confirm the port closes before the next server is launched.
    for _ in range(20):
        try:
            request('/')
        except (OSError, urllib.error.URLError, TimeoutError):
            servers[-1]['port_closed'] = True
            return
        time.sleep(.1)
    raise RuntimeError('The owned dev server still responds after stopping')

def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()

try:
    start('dev-first')
    for path in ['/saved', '/manse', '/planet']:
        status, html = request(path)
        assert status == 200 and isinstance(html, str) and '<html' in html, (path, status)
    checks.append('real npm run dev serves home/saved/manse/planet HTML over loopback')
    status, data = request('/api/saju', authenticated=False)
    assert status == 401, status
    checks.append('anonymous API remains rejected without changing authentication')
    status, data = request('/api/saju?view=summary')
    assert status == 200 and data['fortuneSummaries'] == [], (status, data)
    checks.append('new isolated D1 begins with an empty saved archive')
    fixture = {'name': 'Synthetic Restore Fixture 20261009', 'gender': 'male', 'birthYear': 2000, 'birthMonth': 1, 'birthDay': 1, 'birthHour': 12, 'birthMinute': 30, 'isUnknownTime': False, 'calendarType': 'solar'}
    status, data = request('/api/saju', fixture)
    assert status == 200 and data['fortune']['generation']['mode'] == 'template', (status, data)
    fortune_id = data['fortune']['id']
    status, data = request('/api/saju/' + fortune_id + '/chat', {'question': 'Synthetic restart persistence check'})
    assert status == 200 and isinstance(data['reply'], str), (status, data)
    status, before_fortune = request('/api/saju/' + fortune_id)
    assert status == 200 and [x['role'] for x in before_fortune['chats']] == ['user', 'doryeong']
    status, data = request('/api/guin', fixture)
    assert status == 200, (status, data)
    map_id = data['guinMap']['id']
    status, data = request('/api/guin/' + map_id, {**fixture, 'friendName': 'Synthetic Restore Friend'})
    assert status == 200, (status, data)
    status, before_map = request('/api/guin/' + map_id)
    assert status == 200 and len(before_map['guinMap']['guins']) == 2
    checks.append('synthetic template fortune/chat/relationship map written only to isolated local D1')
    stop()
    start('dev-restarted')
    status, after_fortune = request('/api/saju/' + fortune_id)
    assert status == 200 and digest(after_fortune) == digest(before_fortune), 'Fortune/chat changed after process restart'
    status, after_map = request('/api/guin/' + map_id)
    assert status == 200 and digest(after_map) == digest(before_map), 'Map/friend changed after process restart'
    status, summaries = request('/api/saju?view=summary')
    assert status == 200 and [x['id'] for x in summaries['fortuneSummaries']] == [fortune_id]
    checks.append('fortune, two chat messages, map and friend remain byte-equivalent through API after actual dev-server restart')
    result.update({'status': 'PASS', 'count': len(checks), 'checks': checks, 'synthetic_fortune_id': fortune_id, 'synthetic_map_id': map_id, 'fortune_chat_sha256': digest(after_fortune), 'map_sha256': digest(after_map), 'd1_state_path': str(project / '.wrangler/state/v3/d1'), 'limits': ['Existing loopback-only synthetic preview identity; hosted sign-in not exercised', 'Process restart on the same local disk; no environment Publish or cloud snapshot restoration', 'No external AI endpoint requested']})
except Exception as error:
    result.update({'error': str(error), 'checks_completed': checks})
    raise
finally:
    try:
        stop()
    finally:
        result['servers'] = servers
        result['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        (evidence / 'dev-cycle.result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
        print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
