오늘의 운세 화면을 열어 둔 채 자정을 지나면 전날 날짜와 일주가 남는 현상을 직접 재현했고, 기존 자정 갱신 개선 범위를 복원 브랜치에 재적용했습니다. 새 커밋은 `0dec3e47581437b01390fbb3e8343b20b4b00048`이며 기존 비공개 브랜치 `maint/guin-map-loading-20261009`에 정상 fast-forward push했습니다. 2026-10-09 12:01:26 UTC의 원격 readback에서 전체 SHA가 로컬 HEAD와 일치했습니다.

[새 커밋](https://github.com/ModernCrusader97/saju-project/commit/0dec3e47581437b01390fbb3e8343b20b4b00048), [누적 작업 브랜치](https://github.com/ModernCrusader97/saju-project/tree/maint/guin-map-loading-20261009), [원격·종료 상태 증거](final-state.json).

시작 시 실제 로컬·원격 HEAD는 `5829fc21c34f00b8dd7684259b4d3e712fddd580`으로 같았고 작업 트리는 clean이었습니다. 그 이후의 다른 작업 변경은 발견하지 않았습니다. 원본 `/workspace/saju-project`의 `work` 브랜치와 HEAD `2e2d82b05f87b39ff8057ae914e8dfa01100a974`도 clean이었습니다. 새 지침 파일은 발견하지 않았고 이 회차에 의존성·환경 설정·인증을 변경하지 않았습니다. `baseline.json`은 재현·수정 뒤 본격 회귀 실행을 준비하며 수집한 잠금파일·합성 DB 메타데이터이며, 시작의 clean 상태를 나타내는 파일은 아닙니다.

선정한 기존 lint 문제는 `app/daily/page.tsx`의 `react-hooks/set-state-in-effect`였습니다. 날짜를 처음 마운트할 때 한 번만 계산해, 화면의 “매일 자정 바뀌는” 안내와 실제 동작이 어긋났습니다. 실제 DailyPage와 기존 오프라인 만세력 계산을 JSDOM에 로드하고 합성 시계로 2026-10-09 23:59:59.900에서 자정을 통과시켰습니다. 수정 전 제목은 계속 `2026년 10월 9일 운세`, 일주는 계속 `병진 (丙辰)일`이었습니다. 수정 후 제목은 `2026년 10월 10일 운세`, 일주는 `정사 (丁巳)일`로 함께 갱신됐습니다. 탭 복귀·focus·연말 전환도 기존 코드에서 재현됐습니다.

부모가 알려준 이전 작업의 자정 갱신 범위에 해당하므로 새 독립 발견으로 주장하지 않습니다. 원본 자정 갱신 commit/patch를 받지 못해 바이트 단위 동일성은 미검증입니다. `2709bb7` 전체 복구가 아닙니다.

변경은 세 파일에 한정했습니다:

| 파일 | 변경 목적 |
|---|---|
| `app/daily/page.tsx` | 브라우저의 현재 날짜로 날짜·일주를 함께 계산하고 일회성 effect/미사용 mounted 상태 제거 |
| `lib/use-local-date.ts` | 다음 로컬 자정 예약, 탭 복귀/focus 시 갱신, 타이머·리스너 정리, 서버 placeholder 유지 |
| `scripts/qa/daily-rollover-dom.mjs` | 실제 페이지의 합성 시계·DOM 회귀 8개 |

달력 계산 규칙과 화면 스타일은 유지했습니다. `useSyncExternalStore`에 날짜 문자열과 고정된 서버 snapshot을 제공해 최초 서버 출력과 hydration의 placeholder가 일치하도록 했습니다. 이 동작은 [React 공식 문서](https://react.dev/reference/react/useSyncExternalStore)의 서버 snapshot 계약을 따릅니다. 다음 자정은 로컬 달력으로 계산하므로 고정 24시간 간격을 사용하지 않습니다. 테스트 시계의 `setTime`으로 타이머 실행 없이 날짜만 이동시켜 탭 복귀도 검증했습니다. [Node MockTimers 문서](https://nodejs.org/docs/latest-v24.x/api/test.html#class-mocktimers).

| 실행 항목 | 직접 결과 | 근거 |
|---|---|---|
| 수정 전 날짜 DOM | 8개 중 2 성공·6 실패, 재현 목적의 예상 실패 | `daily-red.log`, `daily-red.result.json` |
| 수정 후 날짜 DOM — UTC | 8/8 성공 | `daily-green-utc.log` |
| 수정 후 날짜 DOM — America/New_York | 8/8 성공, 봄 23시간·가을 25시간 경계 확인 | `daily-green-dst.log` |
| TypeScript, noEmit/incremental false | 성공 | `typecheck.log` |
| 새 production build | 성공, 승인 runtime 자산·GLB checksum 검사 수행 | `build.log` |
| 기존 지도 GET DOM | 7/7 성공 | `guin-dom.log` |
| 기존 대화 복구 DOM | 7 그룹 성공 | `chat-recovery-dom.log` |
| 채팅 원자적 저장, 새 메모리 D1 | 3/3 성공, 저장 실패 뒤 실제 행 0건·명시적 재전송 성공 | `chat-atomic.log` |
| 기존 통합 suite, 새 메모리 D1 | 23/23 성공, `/daily` 포함 페이지 응답·일반 흐름 외부 요청 0건 | `integration-23.log` |
| 전체 lint | 실패 유지, 44오류·38경고 → 43오류·37경고 | `lint.json`, `lint-comparison.json` |

날짜 8개는 자정 전후의 날짜·일주, 정지된 탭 복귀, focus 후 시계 이동, 서버 출력 hydration, Strict Mode/연말 전환, unmount 정리, 봄·가을의 자정 직전/직후를 포함합니다. 최종 QA에서는 DST 경계 직전에도 전날을 유지하는 단언을 보강했습니다. 처음 green 실행 `daily-green.log` 이후 보강된 최종 파일로 UTC와 New_York 검사를 모두 다시 통과했습니다.

lint에서 제거된 진단은 해당 effect 오류 1개와 미사용 mounted 경고 1개입니다. 규칙/메시지 기준 새 진단은 없고 새 두 파일의 lint 진단은 없습니다. DailyPage의 기존 JSX 따옴표 오류 2개는 남았습니다. 전체 lint 성공으로 보고하지 않습니다. 빌드의 기존 chunk 크기·vinext route 분류 경고도 별도로 남습니다.

검사는 원본과 분리된 checkout 및 `/workspace/scratch/saju-daily-rollover-run-20261009`의 출력 경로에서 실행했습니다. 기존 지속 DB 내용을 읽지 않았고 D1 검사는 매번 새 메모리 DB만 사용했습니다. 과거 복원 검사에서 만든 합성 지속 DB/캐시 9개 파일의 크기·mtime이 유지됐습니다. 로컬 빌드가 ignored `.wrangler/deploy/config.json`의 mtime만 갱신한 사실도 `precommit.json`에 기록했습니다. 이는 로컬 빌드 메타데이터이며 사이트 배포 또는 환경 설정 Publish 실행을 의미하지 않습니다.

원본 checkout은 최종에도 clean, 검증 checkout도 커밋 이후 clean입니다. 양쪽 `package-lock.json`의 SHA-256은 모두 `ffb8ad533a7ea1d2f48ca306489d19884296f7902423fbbc00c48f3b8fd11d4e`로 유지됐습니다. 실데이터·실제 API 키·비밀값은 읽거나 출력하지 않았습니다. 통합 suite의 AI 부분은 명시적 합성 key와 모의 응답만 사용하고, 실제 외부 LLM을 호출하지 않았습니다. 이번 회차에서 데이터 재시작 지속성 검사를 새로 수행하지 않았으며 그 성공 증거는 [초기 직접 검사 결과](../saju-restore-evidence-20261009/dev-persistence.json)에 보존돼 있습니다.

| Git 확인 | 직접 결과 |
|---|---|
| 저장소 | `ModernCrusader97/saju-project`, 연결된 GitHub metadata로 private 및 push 권한 확인 |
| 이번 커밋/원격 readback | `0dec3e47581437b01390fbb3e8343b20b4b00048` |
| 직접 부모 | `5829fc21c34f00b8dd7684259b4d3e712fddd580` |
| push 전 작업 브랜치 | `5829fc21c34f00b8dd7684259b4d3e712fddd580`, 로컬 HEAD의 조상 확인 |
| main, push 전후 | `2e2d82b05f87b39ff8057ae914e8dfa01100a974`, 동일 |
| 이번 변화 | 3개 파일, 206줄 추가·18줄 삭제 |
| `40f0c9a..0dec3e4` 누적 변화 | 8개 파일, 509줄 추가·37줄 삭제 |

push는 기존 작업 브랜치 하나를 명시한 정상 fast-forward였습니다. force·tag·main 변경·PR·merge·새 인증 설정은 실행하지 않았습니다. `push.log`, `remote-before.json`, `final-state.json`에 전후 근거가 있습니다. 복원 기준은 이제 `40f0c9a → a10d920 → 5829fc2 → 0dec3e4`이며 마지막 SHA를 pin하면 지도 GET·채팅 원자성·자정 갱신 재적용을 함께 받을 수 있습니다. 기본 main만 checkout하면 이 누적 수정은 포함되지 않습니다. 의존성·생성 모델·dist·DB는 checkout 후 별도 준비가 필요합니다.

현재 남은 차단/미검증은 전체 lint 잔여 문제, 클라우드 환경 설정 Publish 및 그 설정으로 만든 새 환경 자동 복원, 저장됐다고 보고된 install_script/start_skill 원문, 실제 브라우저/GPU·모바일 시각 결과, 실제 hosted 로그인입니다. 배포·사이트 공개·환경 Publish를 실행하지 않았습니다. 초기 설치·모델 복원·D1·개발 서버·재시작의 직접 검증 결과는 [초기 보고](../saju-restore-evidence-20261009/REPORT.md), 직전 누적 회귀는 [누적 보고](../saju-cumulative-regression-evidence-20261009/REPORT.md)에 있습니다.

최신 홈과 10천간 재질 원본은 여전히 다운로드가 차단된 상태이며 이번 회차에 Library 403을 재시도하거나 우회하지 않았습니다. 다음 통합은 현재 `0dec3e4`를 기준으로 승인된 홈 원본을 먼저 대조하고, 다음 10천간 재질 원본을 대조하는 순서입니다. 공식 지원 경로에서 접근 가능한 실제 ZIP bytes, checksum, base/patch 정보가 필요합니다. 기존 후보를 새로 재생성하지 않았습니다. 재질 후보의 제공 checksum과 실제 bytes 일치는 미검증이고, 홈 ZIP checksum은 아직 전달받지 못했습니다.

전체 증거는 이 폴더의 `.log`/`.result.json`, `lint-comparison.json`, `precommit.json`, `remote-before.json`, `final-state.json`에 있습니다. 코드와 QA는 원격 커밋에 보존됐고 이 로컬 evidence 폴더는 그 커밋에 포함되지 않습니다.
