import datetime
import hashlib
import json
import pathlib
import subprocess

root = pathlib.Path('/workspace/scratch/saju-restore-verify-20261009')
evidence = pathlib.Path(__file__).resolve().parent
base = json.loads((evidence / 'baseline.json').read_text())
files = ('app/daily/page.tsx', 'lib/use-local-date.ts', 'scripts/qa/daily-rollover-dom.mjs')
results = {p.stem.removesuffix('.result'): json.loads(p.read_text()) for p in evidence.glob('*.result.json')}
required = ('daily-green-utc', 'daily-green-dst', 'typecheck', 'build', 'guin-dom', 'chat-recovery-dom', 'chat-atomic', 'integration-23')
assert all(results[name]['exit_code'] == 0 for name in required)
assert results['daily-red']['exit_code'] == 1
lint = json.loads((evidence / 'lint-comparison.json').read_text())
assert lint['after'] == {'errors': 43, 'warnings': 37} and lint['added'] == [] and lint['new_files'] == []
locks = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in map(pathlib.Path, base['lock_sha256'])}
assert locks == base['lock_sha256']
before = base['synthetic_persisted_db_file_metadata']
after = {str(p.relative_to(root)): {'size': p.stat().st_size, 'mtime_ns': p.stat().st_mtime_ns} for p in (root / '.wrangler').rglob('*') if p.is_file()}
assert {k: v for k, v in after.items() if k.startswith('.wrangler/state/')} == {k: v for k, v in before.items() if k.startswith('.wrangler/state/')}
runtime_changes = {k: {'before': before.get(k), 'after': after.get(k)} for k in before.keys() | after.keys() if before.get(k) != after.get(k)}
assert set(runtime_changes) == {'.wrangler/deploy/config.json'}

def git(*args, cwd=root):
    return subprocess.run(['git', *args], cwd=cwd, text=True, capture_output=True, check=True).stdout.rstrip('\n')

assert git('rev-parse', 'HEAD') == base['base_sha']
assert git('branch', '--show-current') == base['branch']
assert git('status', '--porcelain', '--untracked-files=all', cwd='/workspace/saju-project') == ''
status = git('status', '--porcelain', '--untracked-files=all')
assert set(line[3:] for line in status.splitlines()) == set(files), status
assert set(git('diff', '--cached', '--name-only').splitlines()) == set(files)
assert git('diff', '--name-only') == ''
result = {
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'base_sha': base['base_sha'],
    'branch': base['branch'], 'changed_files': files, 'source_sha256': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files},
    'passed_commands': required, 'lint': lint['after'], 'lint_added': lint['added'],
    'lock_preserved': True, 'synthetic_persisted_db_metadata_unchanged': True, 'original_repository_clean': True,
    'status': status, 'db_method': 'Metadata only; no persistent DB contents read',
    'build_generated_runtime_metadata_changes': runtime_changes,
    'publication': 'Only local build output; no deployment or environment Publish action',
    'lineage': 'Known previous daily midnight rollover improvement reapplied; original patch/SHA unavailable, not 2709bb7 full recovery.'
}
with (evidence / 'precommit.json').open('x') as file:
    json.dump(result, file, ensure_ascii=False, indent=2)
    file.write('\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
