복원본에서 답변 저장 실패 후 질문만 기록에 남는 동작을 직접 재현하고 재수정했습니다. 이는 부모가 알려준 예전 '채팅 원자적 저장' 개선을 복원본에 다시 적용한 범위이며 새로운 독립 발견으로 기록하지 않습니다. 원래 개선의 전체 커밋 SHA나 patch는 제공받지 못해 바이트 단위 대조는 미검증입니다. 사라진 `2709bb7` 전체를 복구한 결과가 아닙니다.

시작 HEAD와 원격 작업 브랜치는 모두 `a10d920e6e492ba16f75a16cbbbf53a63eb4f178`였고 작업 트리는 clean이었습니다. 격리 작업 트리 `/workspace/scratch/saju-restore-verify-20261009`에서만 소스와 합성 테스트를 변경했습니다.

실제 재현은 빌드된 Worker의 채팅 POST와 풀이 상세 GET, 새 in-memory D1을 함께 사용했습니다. 합성 DB에 답변 INSERT만 거절하는 SQLite trigger를 넣자 POST는 HTTP 500을 반환했지만 상세 GET에서 `user` 질문 1건이 남았습니다. 최초 3개 QA 중 이 부분 저장 사례 1개가 실패했고, 동시 전송과 잘못된 입력·익명·없는 기록·다른 소유자 검사는 통과했습니다. 동시 전송 오류를 새로 발견했다고 주장하지 않습니다.

답변 생성 후 소유자 조건이 있는 질문 INSERT와 답변 INSERT를 하나의 D1 batch로 저장하게 바꿨습니다. [Cloudflare D1 batch 문서](https://developers.cloudflare.com/d1/worker-api/d1-database/#batch)는 batch 내부 실패 시 전체 sequence를 롤백하는 동작을 설명합니다. 현재 설치된 Miniflare/D1에서도 실제 답변 INSERT 실패를 주입해 질문이 0건으로 롤백되고, 실패 원인을 없앤 다음 명시적인 새 전송은 질문·답변 1쌍을 정상 저장하는 것을 확인했습니다.

수정 파일은 세 개뿐입니다:

- `app/api/saju/[id]/chat/route.ts`: 답변 생성 후 교환 저장 메서드 호출
- `lib/db/store.ts`: 소유자 범위를 유지하는 `addChatExchange` batch
- `scripts/qa/chat-atomic-persistence.mjs`: 실제 Worker/메모리 D1 실패 주입·동시 전송·권한 회귀 QA

UI·입력 모달·공유 링크·클립보드·자정 갱신·no-store·LLM 공급자·인증·스키마·마이그레이션·홈 및 재질 후보는 수정하지 않았습니다. 서버의 내구성 있는 중복 요청 식별 기능은 추가하지 않았습니다. 이미 존재할 수 있는 부분 저장 기록을 읽거나 정리하지 않았으며 실사용자 데이터와 DB를 변경하지 않았습니다.

| 실행 항목 | 결과 | 직접 근거 |
|---|---|---|
| 수정 전 실제 Worker/D1 QA | 실패: 3개 중 부분 저장 1개 실패, 2개 통과 | `atomic-red.log`, `atomic-red.result.json` |
| 수정 후 실제 Worker/D1 QA | 성공: 3/3 | `atomic-green.log`, `atomic-green.result.json` |
| 기존 대화 복구 DOM | 성공: 7 그룹 | `chat-recovery-dom.log` |
| TypeScript `--noEmit --incremental false` | 성공 | `typecheck.log` |
| 제품 빌드 | 성공, 기존 큰 청크 경고 유지 | `build.log` |
| 격리 통합 | 성공: 23/23 | `integration-preview.log` |
| 전체 lint | 실패 유지: 44 오류·38 경고, 새 위반 없음 | `lint.json`, `lint-summary.json` |
| 원본과 양쪽 잠금파일 보존·관련 변경 비밀정보 검사 | 성공 | `precommit-check.json` |
| 비공개 작업 브랜치 push 및 원격 SHA readback | 성공 | `push-result.json`, `push-operations.json` |

이 라운드의 직접 실패 검증은 채팅 기록의 저장 실패 후 불러오기, 동시 전송, 잘못된 입력 및 권한 오류입니다. 저장된 풀이와 귀인 지도의 정상 경로는 통합 23개에 포함돼 통과했습니다. 그 화면의 모든 실패 조건을 새로 조사한 것은 아닙니다. JSDOM 대화 QA는 합성 응답과 실제 컴포넌트를 사용하며 브라우저 렌더링·GPU·실사용자 인증 검증은 아닙니다.

새 D1은 메모리에만 존재하며 기존 검증용 `.wrangler` DB와 원본 DB는 사용하지 않았습니다. 외부 요청은 차단/모의 처리했고 실제 LLM·유료 API를 호출하지 않았습니다. 새 QA의 outbound는 0회이며 통합 검사의 AI 6회는 모의 응답입니다. 수정 파일 검토와 주요 비밀정보 패턴 검사에서 발견 사항은 없었습니다. 이 검사는 관련 변경 범위이고 무관한 전체 과거 이력의 보안 감사는 아닙니다.

원격 보존 결과:

- 저장소: 비공개 `ModernCrusader97/saju-project`
- 브랜치: `maint/guin-map-loading-20261009`
- 전체 SHA: `5829fc21c34f00b8dd7684259b4d3e712fddd580`
- 직접 부모: `a10d920e6e492ba16f75a16cbbbf53a63eb4f178`
- 원격 직전 SHA: `a10d920e6e492ba16f75a16cbbbf53a63eb4f178`
- [브랜치](https://github.com/ModernCrusader97/saju-project/tree/maint/guin-map-loading-20261009)
- [커밋](https://github.com/ModernCrusader97/saju-project/commit/5829fc21c34f00b8dd7684259b4d3e712fddd580)
- 원격 readback 시각: `2026-10-09T09:24:57.826614+00:00`
- push는 기존 인증을 이용한 비강제 fast-forward였습니다. `main`은 전후 `2e2d82b05f87b39ff8057ae914e8dfa01100a974`로 동일합니다.
- 원본과 검증 작업 트리는 clean이며, 양쪽 잠금파일 SHA-256은 `ffb8ad533a7ea1d2f48ca306489d19884296f7902423fbbc00c48f3b8fd11d4e`로 유지했습니다.

PR·merge·배포·공개 전환·환경 Publish·새 자격 증명 변경은 실행하지 않았습니다. 이전 `a10d920` Library ZIP은 그대로 보존했고 차단된 Library 다운로드·홈/재질 후보를 재시도·우회하거나 재생성하지 않았습니다. 이번 커밋을 막는 차단은 없지만 기존 lint 실패, 새 환경 자동 복원 미검증, 차단된 후보 통합 미실행은 남아 있습니다.
