#!/usr/bin/env python3
"""Capture verification output and exit status without changing source files."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
label, *command = sys.argv[1:]
if command and command[0] == "--":
    command.pop(0)
if not command or not label.replace("-", "").replace("_", "").isalnum():
    raise SystemExit("Usage: run-command.py label -- command [args...]")
log_path = root / f"{label}.log"
result_path = root / f"{label}.result.json"
if log_path.exists() or result_path.exists():
    raise SystemExit("Refusing to overwrite prior verification evidence")
unset_names = [key for key in os.environ if any(part in key.upper() for part in ("API_KEY", "API_TOKEN", "GEMINI", "OPENAI", "ANTHROPIC"))]
settings = {
    "npm_config_cache": str(root / "npm-cache"),
    "npm_config_audit": "false",
    "npm_config_fund": "false",
    "npm_config_update_notifier": "false",
    "NEXT_TELEMETRY_DISABLED": "1",
    "CLOUDFLARE_CF_FETCH_ENABLED": "false",
    "WRANGLER_SEND_METRICS": "false",
    "WRANGLER_WRITE_LOGS": "false",
    "XDG_CONFIG_HOME": str(root / "xdg-config"),
}
safe_command = ["env"]
for key in unset_names:
    safe_command.extend(["-u", key])
safe_command.extend(f"{key}={value}" for key, value in settings.items())
safe_command.extend(command)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
tick = time.monotonic()
print(json.dumps({"label": label, "command": command, "cwd": os.getcwd(), "started_utc": started}), flush=True)
with log_path.open("x") as log:
    child = subprocess.Popen(safe_command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for line in child.stdout:
        log.write(line)
        log.flush()
        print(line, end="", flush=True)
    code = child.wait()
result = {
    "label": label, "command": command, "cwd": os.getcwd(),
    "started_utc": started,
    "ended_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "duration_seconds": round(time.monotonic() - tick, 3),
    "exit_code": code, "log": str(log_path),
}
result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(result, ensure_ascii=False), flush=True)
raise SystemExit(code)
