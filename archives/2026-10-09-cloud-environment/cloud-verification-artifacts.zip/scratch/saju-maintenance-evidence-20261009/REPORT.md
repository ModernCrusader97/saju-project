검증된 `40f0c9a` 기준에서 귀인 상세 지도의 GET 요청 수명 결함을 재수정하고 별도 로컬 커밋으로 남겼습니다. 부모가 전달한 기존 작업 기록에 따르면 이는 사라진 `2709` 작업 계보의 `fed2211` 지도 GET 경합 수정과 같은 범위이며, 새로운 독립 발견으로 기록하지 않습니다. `fed2211` 원본은 현재 저장소에 없어 바이트 단위 비교는 미검증입니다. 사라진 `2709bb7`, 최신 홈 후보 및 10천간 재질 후보는 통합하지 않았습니다. Library 공식 다운로드는 VM 프록시 CONNECT 403 이후 중단 상태이며 재시도하거나 다른 경로로 우회하지 않았습니다.

- 작업 트리: `/workspace/scratch/saju-restore-verify-20261009`
- 브랜치: `maint/guin-map-loading-20261009`
- 로컬 커밋: `a10d920e6e492ba16f75a16cbbbf53a63eb4f178`
- 직접 부모: `40f0c9a4b66bcae1c222d33d99cc6f6963e2f573`
- 커밋 파일: `app/guin/[id]/page.tsx`, `scripts/qa/guin-map-loading-dom.mjs`
- 원본: `/workspace/saju-project`, `work`, `2e2d82b05f87b39ff8057ae914e8dfa01100a974`
- 원본과 검증 작업 트리는 모두 clean이며 원본 소스와 양쪽 잠금파일은 보존했습니다. 잠금파일 SHA-256은 모두 `ffb8ad533a7ea1d2f48ca306489d19884296f7902423fbbc00c48f3b8fd11d4e`입니다.

주소 ID 변경 후 늦은 이전 GET이 현재 지도 제목을 이전 소유자로 덮어쓰는 DOM 실패, 이전 로딩·오류 상태가 남는 실패, unmount 후 복원 함수 호출, Strict Mode의 폐기된 효과를 합성 테스트로 직접 재현했습니다. 수정 전 7개 중 6개가 실패했고, 기존 현재 요청의 HTTP·응답 오류 처리 1개는 통과했습니다. ID별 내부 화면 key로 상태를 분리하고 GET 효과에서 AbortController와 active 플래그를 사용해 취소된 요청의 상태 업데이트와 복원 함수 호출을 막았습니다.

POST 요청 본문·API·DB 저장 형식·인증·LLM 동작은 수정하지 않았습니다. 홈 진입, Header, 공통 입력 폼 및 내비게이션, 행성/10천간 재질 파일도 수정하지 않았습니다. 차단된 후보의 실제 파일 목록은 확인하지 못했으며 후보 패치를 재생성하거나 대체하지 않았습니다.

| 직접 실행한 확인 | 결과 | 증거 |
|---|---|---|
| 최소 수정 전 DOM 실패 재현 | 실패, 1 통과 / 6 실패 | `guin-loading-red.log` |
| 최종 귀인 지도 DOM | 성공, 7/7 | `guin-loading-final.log` |
| 기존 대화 복구 DOM | 성공, 7 그룹 | `chat-recovery-dom.log` |
| 기존 저장 목록 DOM | 성공, 6 그룹 | `saved-archive-dom.log` |
| TypeScript `--noEmit --incremental false` | 성공 | `typecheck.log` |
| 제품 빌드 | 성공, 기존 큰 청크 경고 유지 | `build.log` |
| 새 빌드의 격리 통합 검사 | 성공, 23/23 | `integration-preview.log` |
| 전체 lint, 기존 규칙 그대로 | 실패, 44 오류·38 경고 | `lint-after.json`, `lint-after-summary.json` |
| 원본·잠금파일·최종 clean 및 부모 커밋 | 성공 | `summary.json` |

최초 lint의 44 오류·39 경고 중 React 관련은 12 오류·6 경고였고 나머지는 타입·선언·JSX·모듈·탐색·이미지 규칙입니다. 모두 실제 사용자 결함이라고 단정하지 않았습니다. 직접 재현한 귀인 상세 효과의 의존성 경고 1개만 해소했으며 새 위반은 없습니다. 새 QA 파일의 lint는 오류·경고 0개입니다. 기존 상세 페이지의 내부 anchor 오류 2개와 unused 경고 3개는 유지했습니다. 규칙 약화와 일괄 스타일 정리는 하지 않았습니다. [분류와 추가 제안](LINT_CLASSIFICATION.md)에 다른 React 경고의 한계와 보류 근거를 적었습니다.

JSDOM은 실제 상세 페이지와 API 응답 파서를 실행하며 라우터·복원 경계·3D 및 시각 컴포넌트는 stub입니다. 실브라우저 시각·GPU·터치 검증이나 실제 세션 저장 기록 검증은 이 테스트의 범위에 포함되지 않습니다. 통합 검사는 새 in-memory D1과 합성 사용자만 사용하고, Worker 외부 요청은 모두 모의 처리합니다. 일반 흐름 외부 요청 0회, AI 시험의 6회는 모의 응답입니다. 실사용자 데이터와 비밀값을 읽거나 출력하지 않았고 외부 LLM을 호출하지 않았습니다.

앞선 동일 격리 작업 트리의 복원 검증에서는 의존성 설치, 모델/텍스처 체크섬 확인 및 모델 복원, 로컬 D1 두 마이그레이션, 타입 검사·빌드·통합 23개, 실제 개발 서버 응답과 프로세스 재시작 후 합성 데이터 유지가 직접 성공했습니다. 이 검증은 `portable` 프로필을 사용했습니다. 자세한 명령과 초기 상태는 [복원 검증 보고](../saju-restore-evidence-20261009/REPORT.md), [재시작 유지 결과](../saju-restore-evidence-20261009/dev-persistence.json)에 있습니다. 해당 검증용 D1은 보존했고 이번 회귀 통합 검사는 별도 메모리 DB를 사용했습니다. 원본 작업 트리에 DB나 런타임 생성물을 추가하지 않았습니다.

복원 가능 범위는 원격에서 확인한 `40f0c9a` 소스와 저장소에 보존된 모델/텍스처이며, 이번 재수정 커밋은 그 위의 로컬 변경입니다. 원격 `main`은 `2e2d82b`였고 최신 수정 브랜치와 같지 않았습니다. 앞선 `a5a76df`, `90b92db`, `2e2d82b`가 `40f0c9a`의 조상임을 확인했습니다. `2709bb7`의 연결된 GitHub 조회는 422 `No commit found for SHA`였으므로 복원 성공 범위에 포함하지 않습니다.

다음 통합 대상은 승인된 홈 원본 `SaJu_Mobile_Home_Validated_20261009_0708.zip` 및 별도 10천간 원본 `SaJu_Ten_Stem_Material_Commit_a97c418_20261009.zip`입니다. 공식 전송이 가능해져 실제 원본과 checksum을 확보한 뒤 홈, 재질 순으로 별도 변경과 검증을 해야 합니다. 지금은 두 ZIP의 내용·checksum·커밋·GPU 결과를 검증하지 못했습니다. 己 jade green / 乙 vine leaves, depth 1.35 및 기존 기능 보존 요구가 다음 재질 통합 기준이며, 완전한 덩굴 몸체·戊 모래·壬 물보라는 미구현 범위로 유지합니다. 전송 차단의 증거와 네트워크 분류는 [별도 차단 보고](../saju-restore-evidence-20261009/INTEGRATION_BLOCKED.md), [프록시 차단 분류](../saju-restore-evidence-20261009/NETWORK_BLOCK_CLASSIFICATION.md)에 있습니다.

환경 화면에 저장됐다는 `install_script` / `start_skill` 초안 원문은 이 체크아웃에서 찾지 못해 확인하지 않았습니다. 환경 설정 Publish와 그 설정으로 생성한 새 클라우드 환경 자동 복원, `managed-linux` 프로필, 사이트 공개 전환/배포는 미실행·미검증입니다. 환경 설정 Publish와 사이트 공개는 별개의 작업입니다. PR·원격 push·merge·결제·인증 변경·새 자격 증명 생성은 실행하지 않았습니다.
