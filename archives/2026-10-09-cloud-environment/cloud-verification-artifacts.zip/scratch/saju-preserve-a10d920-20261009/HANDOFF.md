`a10d920e6e492ba16f75a16cbbbf53a63eb4f178`의 복구 자료를 Library에 보존했고, 후속 사용자 승인에 따라 비공개 `ModernCrusader97/saju-project`의 작업 브랜치에 기존 인증으로 일반 Git push했습니다. 원격 readback은 로컬 전체 SHA와 일치했습니다.

- 작업 브랜치: `maint/guin-map-loading-20261009`
- 원격 커밋: `a10d920e6e492ba16f75a16cbbbf53a63eb4f178`
- 직접 부모: `40f0c9a4b66bcae1c222d33d99cc6f6963e2f573`
- tree: `fe4203c945de810b4f50b6d39d91d7597e4e1f2c`
- 원격 검증 시각: `2026-10-09T09:06:29.000941+00:00`
- 브랜치 URL: https://github.com/ModernCrusader97/saju-project/tree/maint/guin-map-loading-20261009
- 커밋 URL: https://github.com/ModernCrusader97/saju-project/commit/a10d920e6e492ba16f75a16cbbbf53a63eb4f178
- 원격 브랜치는 push 전 없었고, push 후 위 SHA로 생성됐습니다. force·merge·PR 생성·배포·공개 전환·자격 증명 변경은 하지 않았습니다.
- `main`은 push 전후 `2e2d82b05f87b39ff8057ae914e8dfa01100a974`로 동일했습니다. 원본과 검증 작업 트리는 clean입니다.

수정 계보는 부모가 제공한 기록에 따라 사라진 `2709` 작업 계보의 `fed2211` 지도 GET 경합 수정과 같은 범위의 재수정으로 정정했습니다. 새로운 독립 발견으로 기록하지 않습니다. `fed2211` 원본 객체가 없어 원본과의 바이트 단위 비교와 전체 `2709bb7` 복원은 미검증입니다. 이 후속 작업에서 제품 코드를 더 수정하거나 커밋을 amend하지 않았습니다. 기존 수정 기록과 중복 여부를 확인하지 못한 lint 조사 후보는 추가 수정·확정 제안으로 진행하지 않았습니다.

Library 저장 결과:

- 권위 있는 저장 경로: `/SaJu_Map_GET_Race_Reapplied_a10d920_20261009.zip`
- `library_file_id`: `libfile_a19d0837125081919e95a56b711cf28e`
- `file_id`: `file_0000000016e8820c87e73bb0773c035f`
- 현재 버전 번호: `0` (생성 결과 그대로)
- 크기: 185,807바이트
- ZIP SHA-256: `d247c822443fa8bc69671cf78937708ec6d4890660ad509a5a6a418c064b4c41`
- 로컬 ZIP: `SaJu_Map_GET_Race_Reapplied_a10d920_20261009.zip`
- Library skill의 단일 파일 공식 생성 경로가 성공했고, 같은 호출에서 현재 helper로 로컬 파일의 Library identity를 보존했습니다. 업로드 뒤 로컬 ZIP 바이트와 체크섬도 그대로입니다.

묶음에는 `a10d920.bundle`, binary/full-index `a10d920.patch`, 변경 파일 두 개의 원문, 수정 계보 정정, 실패·성공 테스트 근거, 결과 JSON, 복구 설명 및 SHA256SUMS가 있습니다. DB·node_modules·캐시·환경 파일·API 키/비밀값·전송 URL은 포함하지 않았습니다. 전체 저장소 이력이나 기반 모델 파일도 포함하지 않았습니다.

bundle은 정확한 부모 `40f0c9a4b66bcae1c222d33d99cc6f6963e2f573`를 prerequisite로 갖는 증분 파일입니다. 별도 빈 저장소에 부모를 로컬 fetch해 bundle의 기존 전체 커밋 SHA와 patch의 exact tree를 모두 직접 복구해 확인했습니다. 이제 일반 복구에는 위 원격 작업 브랜치를 사용할 수도 있습니다. Library 저장은 성공했지만, 기존 VM의 Library 다운로드 403은 재시험하거나 우회하지 않았습니다. 공식 다운로드가 가능한 환경에서 ZIP을 가져오고 SHA-256을 확인할 수 있습니다.

검증 근거는 변하지 않았습니다. 수정 전 DOM 7개 중 6개 실패, 최종 귀인 DOM 7/7, 대화 DOM 7 그룹, 저장 목록 DOM 6 그룹, 타입 검사·빌드·격리 통합 23/23 성공입니다. 전체 lint는 기존 44 오류·38 경고로 실패 유지입니다. push 직전 파일의 checksum이 검증·보존한 파일과 같고, 변경 두 파일의 검토 및 주요 비밀정보 패턴 검사에서 발견 사항이 없었습니다. 검사는 관련 변경 범위이며 무관한 전체 과거 이력의 보안 감사는 아닙니다.

Library ZIP은 push 승인 전에 만들어진 시점별 보존 자료입니다. 그 안의 당시 보고에는 원격 push 미실행이라고 기록되어 있으며, 이번 후속 승인·실제 push 결과는 이 인계 기록과 `push-result.json`이 최신 근거입니다. ZIP을 다시 만들거나 중복 업로드하지 않았습니다.

주요 직접 증거:

- `artifact-result.json`, `recovery-verification.json` 및 `recovery-operations.json` (ZIP 내부)
- `library-upload-result.json`
- `push-preflight.json`, `push-result.json`, `push-operations.json`
- `final-preservation.json`
- `../saju-maintenance-evidence-20261009/LINEAGE_CORRECTION.md`

환경 Publish·새 환경 자동 복원·최신 홈 및 10천간 후보 통합은 여전히 미실행·미검증입니다.
