이 묶음은 a10d920을 작업 VM 밖에 보존하기 위한 복구 자료입니다.

전체 커밋: a10d920e6e492ba16f75a16cbbbf53a63eb4f178
직접 부모: 40f0c9a4b66bcae1c222d33d99cc6f6963e2f573
결과 tree: fe4203c945de810b4f50b6d39d91d7597e4e1f2c
원래 로컬 ref: refs/heads/maint/guin-map-loading-20261009

수정 계보 정정: 부모가 전달한 기록에 따르면 이 변경은 사라진 2709 작업 계보의 fed2211 지도 GET 경합 수정과 같은 범위의 재수정입니다. 새로운 독립 발견으로 기록하지 않습니다. fed2211 객체가 없어 원본 patch와의 바이트 비교는 미검증이며, 2709bb7 전체를 복원한 자료가 아닙니다.

내용: 증분 Git bundle, binary/full-index format-patch, 변경 파일 원문 2개, 수정 계보 정정, 실패 및 성공 DOM 테스트 로그, 타입 검사·빌드·통합 23개·기존 DOM 회귀·lint 결과, 복구 검증, 체크섬.
DB, node_modules, 설치 캐시, 환경 파일, API 키/비밀값, Library 전송 URL은 포함하지 않습니다. 기반 모델과 전체 저장소 이력도 포함하지 않습니다.

복구 조건: a10d920.bundle은 정확한 부모 40f0c9a4b66bcae1c222d33d99cc6f6963e2f573를 prerequisite로 갖는 증분 bundle입니다. 먼저 기존 승인된 사본 또는 origin의 fix/chat-recovery 이력에서 이 부모의 Git 객체를 확보하세요. main만으로 최신 수정을 추정하지 마세요. base가 없으면 bundle verify 실패를 해결하기 전 적용하지 마세요.

Git bundle 복구 예시 — 부모 객체가 있는 별도/격리 저장소에서:

git cat-file -e 40f0c9a4b66bcae1c222d33d99cc6f6963e2f573^{commit}
git bundle verify /absolute/path/a10d920.bundle
git fetch /absolute/path/a10d920.bundle refs/heads/maint/guin-map-loading-20261009:refs/heads/restore/a10d920
git rev-parse refs/heads/restore/a10d920

위 마지막 해시는 a10d920e6e492ba16f75a16cbbbf53a63eb4f178여야 합니다. 현재 작업 트리를 덮어쓰지 말고 새 작업 트리에 restore/a10d920을 여세요. 원격 push가 필요하지 않습니다.

Patch 복구: 부모 40f0c9a4b66bcae1c222d33d99cc6f6963e2f573의 clean 격리 작업 트리에서 git apply --check --index /absolute/path/a10d920.patch, 이어서 git apply --index를 실행할 수 있습니다. git write-tree 결과는 fe4203c945de810b4f50b6d39d91d7597e4e1f2c여야 합니다. git am도 원래 patch metadata로 변경을 적용할 수 있지만 committer 시간에 따라 새 커밋 SHA가 달라질 수 있습니다. 정확한 기존 커밋 SHA 보존에는 bundle을 사용하세요.

이 환경에서 별도 빈 저장소에 부모를 로컬 fetch한 뒤 patch의 exact tree와 bundle의 exact commit을 모두 직접 복구해 검증했습니다. recovery-verification.json과 recovery-operations.json에 명령·결과가 있습니다. 이미 있는 소스·잠금파일·DB를 삭제하거나 덮어쓰지 않았습니다.

검증: 수정 전 DOM 7개 중 6개 실패, 최종 귀인 DOM 7/7, 대화 DOM 7 그룹, 저장 목록 DOM 6 그룹, 타입 검사·빌드·격리 통합 23/23 성공. 전체 lint는 44 오류·38 경고로 실패 유지입니다. 모든 외부 LLM 응답은 모의 처리했으며 실제 호출은 하지 않았습니다. DOM은 합성 응답과 시각·라우터·복원 경계 stub을 사용하므로 실제 브라우저/GPU/실세션 데이터 검증을 의미하지 않습니다.

시험 재실행: 기반 프로젝트에서 npm run install:ci를 먼저 실행하고, 제품 잠금파일을 변경하지 않는 별도 임시 prefix에 jsdom@26.1.0을 설치하세요. SAJU_QA_JSDOM_PATH=/absolute/test-tools/node_modules/jsdom/lib/api.js node scripts/qa/guin-map-loading-dom.mjs를 사용할 수 있습니다. 기존 회귀 DOM 두 개도 같은 변수를 사용합니다. 타입 검사는 node node_modules/typescript/bin/tsc --noEmit --incremental false, 빌드는 npm run build, 격리 통합 검사는 node --import ./scripts/sites-env.mjs scripts/integration-preview.mjs입니다.

원격 push·PR·merge, 환경 Publish, 새 환경 자동 복원, 사이트 배포는 하지 않았습니다. Library 저장 여부는 별도의 업로드 결과로 확인해야 하며 이 로컬 묶음 생성만으로 외부 보존 성공을 주장하지 않습니다. 기존 Library 다운로드 403을 우회하거나 차단된 후보 ZIP을 옮기는 자료가 아닙니다.
