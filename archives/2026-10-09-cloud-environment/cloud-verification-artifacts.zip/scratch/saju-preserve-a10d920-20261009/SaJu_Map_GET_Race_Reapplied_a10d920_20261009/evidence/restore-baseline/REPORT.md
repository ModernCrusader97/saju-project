**saju-project 새 실행 환경 검증 — 2026-10-09 UTC**

현재 환경에서 개발 준비를 직접 재현했습니다. 설치, 모델 복원, 로컬 D1 초기화, 타입 검사, 빌드, 통합 검사 23개, 실제 개발 서버 응답과 서버 재시작 후 합성 데이터 유지가 통과했습니다. 추가 lint는 실패했습니다. 환경 설정 Publish와 그 설정을 이용한 새 환경 자동 복원은 검증하지 않았습니다.

원격은 `https://github.com/ModernCrusader97/saju-project.git`입니다. 실제 초기 체크아웃은 `/workspace/saju-project`, 브랜치 `work`, HEAD `2e2d82b05f87b39ff8057ae914e8dfa01100a974`였습니다. 처음에는 `node_modules`, `dist`, `.wrangler`, `.sites-runtime`, 복원 대상 porcelain GLB가 모두 없었습니다. 따라서 기존 보고의 실행 준비 상태가 이번 환경에 이미 복원되어 있었다고 판단할 수 없습니다.

| 직접 조회한 원격 브랜치 | 실제 SHA |
| --- | --- |
| main | 2e2d82b05f87b39ff8057ae914e8dfa01100a974 |
| feat/jade-spirit-universe | a5a76df53d628191ecdbbee71626d8dc4480a481 |
| perf/saved-archive-summary | 90b92db056b1fa9728ae5da3d232c22a28540e94 |
| fix/chat-recovery | 40f0c9a4b66bcae1c222d33d99cc6f6963e2f573 |

`git merge-base --is-ancestor`로 앞선 세 브랜치가 모두 `fix/chat-recovery`에 포함됨을 확인했습니다. `2709bb7`은 로컬에 없었고, 연결된 GitHub의 commit 조회는 HTTP 422, `No commit found for SHA: 2709bb7`로 응답했습니다. 해당 커밋은 복원 범위에 포함할 수 없습니다.

검증 작업 공간은 `/workspace/scratch/saju-restore-verify-20261009`, 새 브랜치는 `verify/cloud-restore-20261009`, 기준 HEAD는 `40f0c9a`입니다. 원본 브랜치는 바꾸지 않았습니다. 원격 refs를 읽기 위해 fetch하고 로컬 worktree/브랜치를 추가했으며, commit/push/PR/merge는 실행하지 않았습니다.

저장소와 최신 기준 커밋에 `AGENTS.md` 또는 `.agents/skills` 지침은 없었고, `/workspace/.agents`는 비어 있었습니다. 저장소 README와 관련 설치·복원·실행·검사 스크립트를 읽었습니다. `install_script`/`start_skill`라는 별도 초안 파일은 이 체크아웃에서 확인하지 못했습니다. 외부 환경 설정 화면에 저장되었다는 보고는 이번 파일 검사로 확인할 수 없습니다.

실행 도구는 Git 2.52.0, Node 24.19.0, npm 11.9.0, Python 3.12.14입니다. 프로젝트의 Node 최소 버전은 22.13.0입니다. 설치 후 로컬 Vinext 1.0.0-beta.5, Vite 8.0.13, Wrangler 4.92.0, Miniflare 4.20260515.0, TypeScript 5.9.3, Three 0.186.1을 확인했습니다. 글로벌 Wrangler와 sqlite3 실행파일은 없었지만 프로젝트 Wrangler로 로컬 D1 준비에 성공했습니다. 이 작업은 기본 `portable` 실행 프로필을 사용했으며 `managed-linux` 프로필은 검증하지 않았습니다.

| 항목 | 직접 실행 결과 | 근거 |
| --- | --- | --- |
| `npm run install:ci` | 성공, 746개 패키지, 종료 0 | install.log / install.result.json |
| `node scripts/sync-approved-jade-assets.mjs` | 성공, Jade 런타임 자산 4개와 porcelain GLB 복원 | restore-assets.log |
| 승인 원본 해시·PNG/raw 대조 | 성공, 원본 46개 파일, 정확한 RGBA 일치 | verify-assets.log |
| Python 복원 스크립트 재실행 | 성공, 기존 일치 모델 유지 | restore-python-idempotence.log |
| `tsc --noEmit --incremental false` | 성공, 종료 0 | typecheck.result.json |
| `npm run build` | 성공, 종료 0, 7.416초 | build.log |
| `node scripts/integration-preview.mjs` | 성공, 23개 검사 | integration-23.log |
| Jade CPU 검사 | 성공, 10/10, 실패 0 | jade-cpu.log |
| 저장목록 API 회귀 검사 | 성공, 4개 그룹, 합성 기록 120개 | saved-archive-api.log |
| D1 SQL 0000 / 0001 | 성공, 각각 5개 / 1개 명령 | d1-init-0000.log / d1-init-0001.log |
| 실제 개발 서버 시작·재시작 | 성공, 5개 검증 그룹 | dev-persistence.json / dev-first.log / dev-restarted.log |
| `npm run lint` | 실패, 종료 1, 오류 44개·경고 39개 | lint.log / lint-summary.json |

복원된 porcelain GLB는 13,700,928바이트, SHA-256 `57d7ee5b3c4e0b99eaadefb8095283bed44986beaa5a91c096dd7a0c514bf9c2`로 일치했습니다. 잠금파일 SHA-256은 원본·검증 작업 공간의 시작과 종료에서 모두 `ffb8ad533a7ea1d2f48ca306489d19884296f7902423fbbc00c48f3b8fd11d4e`였습니다.

통합 검사 D1은 새 메모리 DB이고, 모든 Worker 외부 요청은 테스트의 `outboundService`에서 가로챘습니다. 일반 흐름의 외부 요청은 0회였으며 Gemini 관련 6회는 모의 응답입니다. 실제 LLM, 결제, 실제 인증 서비스는 호출하지 않았습니다.

개발 서버 검증에는 이 새 worktree의 `.wrangler/state/v3/d1`만 사용했습니다. 초기 저장목록이 비어 있음을 먼저 확인하고, 기존 loopback 전용 합성 미리보기 신원으로 풀이 1개·채팅 2개·관계지도와 친구 1명을 생성했습니다. `npm run dev -- --hostname 127.0.0.1 --port 5173`로 홈·저장목록·만세·행성 HTML 200 응답과 익명 API 401을 확인했습니다. 첫 프로세스를 종료한 후 동일 명령으로 재시작하여 풀이/채팅/지도의 API 결과 해시가 이전과 동일함을 검증했습니다. 두 서버는 검사 후 모두 종료했고 포트 해제도 확인했습니다. 합성 DB는 삭제하지 않고 이 worktree에 보존했습니다. 이는 같은 디스크에서의 개발 프로세스 재시작 검증이며, 클라우드 환경 간 DB 이동 또는 스냅샷 복원 증거는 아닙니다.

lint는 설치 실패가 아니라 현재 HEAD의 코드 규칙 위반입니다. 대표적으로 API의 `any`, effect 안의 동기 상태 갱신, 내부 `<a>` 링크, 선언 전 함수 참조, JSX 따옴표, CJS 검사 스크립트의 `require` 규칙 위반이 있습니다. 최신 변경과 원본 main의 잠금파일·ESLint 설정은 동일했고, 검사 작업 중 소스 수정은 없었습니다. 오류를 수정하거나 `--fix`로 파일을 바꾸지 않았습니다. 빌드에는 500 kB 초과 클라이언트 청크 경고가, 개발 서버에는 Vinext dependency optimization 경고가 남았습니다.

**미실행·미확인 범위**

- 환경 설정 Publish, 게시된 설정에서 별도의 클라우드 환경 생성/자동 복원, saved install_script/start_skill 초안 원문 확인.
- 사이트 배포 또는 공개 전환. 환경 설정 Publish와 사이트 공개는 별개의 작업이며 둘 다 실행하지 않았습니다.
- 실제 브라우저 렌더링, WebGL, 터치, 호스팅된 로그인.
- JSDOM 기반 chat-recovery/saved-archive DOM 검사: 저장소 잠금파일에 해당 보조 도구가 없고 이번 작업 공간에도 없으므로 실행하지 않았습니다.
- 부모가 이후 전달할 최신 홈 후보와 10천간 재질 원본의 통합. 해당 원본은 아직 이 검증의 입력으로 받지 않았습니다.
- Library 선택 범위 밖의 백업 조회/복원. Library 파일을 읽거나 거부된 접근을 우회하지 않았습니다.

**복원 가능한 범위와 다음 통합 대상**

원격에서 확인된 `40f0c9a`까지의 소스와 저장소에 보존된 모델/텍스처는 다시 개발 가능한 상태로 준비할 수 있습니다. 이번 환경의 기본 시작점은 `main`과 같은 `2e2d82b`였으므로, 이후 복원 설정의 기준 ref/SHA를 명시적으로 결정해야 합니다. `2709bb7`에서만 존재했던 작업은 별도 승인된 원본 전달 없이는 복원할 수 없습니다.

다음 통합 기준은 앞선 수정들을 포함한 `40f0c9a`입니다. 부모가 전달할 홈 후보와 10천간 재질 원본을 먼저 별도로 보존·대조한 뒤 별도 통합 브랜치에서 적용하고, 이번 검사를 다시 수행하는 것이 다음 작업입니다. 홈 후보와 재질 작업을 이미 검증했다고 간주하지 않습니다. lint 해결과 브라우저/DOM 보조 검사 준비는 별도 남은 개발 작업입니다.

검증에 사용한 D1 준비 명령은 아래와 같습니다. 이 명령은 새 격리 DB에만 적용했습니다. SQL의 `CREATE TABLE`에는 `IF NOT EXISTS`가 없으므로 시작할 때마다 그대로 재실행하는 방식은 검증되지 않았습니다. 이후 시작 초안에는 현재 DB 상태/적용 이력을 확인하는 절차가 필요합니다.

```bash
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_windy_maestro.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_fuzzy_blue_blade.sql
```

마지막 보존 검사에서 원본 HEAD·브랜치·잠금파일·런타임 경로 존재 상태가 시작과 일치했고, 원본과 검증 worktree 모두 `git status --porcelain`이 비어 있었습니다. 보존 판정은 `baseline.json`과 `preservation-final.json`에 기록했습니다. 사용자 데이터/비밀 파일은 열지 않았고, 환경 설정·자격 증명·애플리케이션 인증 코드는 변경하지 않았습니다.
