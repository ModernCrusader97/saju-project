누적 브랜치 `maint/guin-map-loading-20261009`의 로컬·원격 HEAD는 `5829fc21c34f00b8dd7684259b4d3e712fddd580`으로 일치합니다. `40f0c9a → a10d920 → 5829fc2`의 실제 부모 관계를 확인했고, 기존 빌드에서 지도·채팅 수정과 관련 합성 회귀를 함께 재실행했습니다. 실행한 회귀 범위에서 새 결함은 발견하지 못했으며 이 회차에는 소스 수정·새 커밋·push를 하지 않았습니다.

| 역할 | 실제 전체 SHA | 직접 부모 | 정확한 원격 URL |
|---|---|---|---|
| 복원 기준 `fix/chat-recovery` | `40f0c9a4b66bcae1c222d33d99cc6f6963e2f573` | `90b92db056b1fa9728ae5da3d232c22a28540e94` | [40f0c9a](https://github.com/ModernCrusader97/saju-project/commit/40f0c9a4b66bcae1c222d33d99cc6f6963e2f573) |
| 지도 GET 경합 재수정 | `a10d920e6e492ba16f75a16cbbbf53a63eb4f178` | `40f0c9a4b66bcae1c222d33d99cc6f6963e2f573` | [a10d920](https://github.com/ModernCrusader97/saju-project/commit/a10d920e6e492ba16f75a16cbbbf53a63eb4f178) |
| 채팅 원자적 저장 재수정, 현재 HEAD | `5829fc21c34f00b8dd7684259b4d3e712fddd580` | `a10d920e6e492ba16f75a16cbbbf53a63eb4f178` | [5829fc2](https://github.com/ModernCrusader97/saju-project/commit/5829fc21c34f00b8dd7684259b4d3e712fddd580) |

[현재 작업 브랜치](https://github.com/ModernCrusader97/saju-project/tree/maint/guin-map-loading-20261009)는 비공개 `ModernCrusader97/saju-project`에 있습니다. 이번 읽기 전용 readback 전후 원격 작업 브랜치는 `5829fc2…`, `fix/chat-recovery`는 `40f0c9a…`, `main`은 `2e2d82b05f87b39ff8057ae914e8dfa01100a974`로 동일했습니다. `main`을 현재 누적 수정본이라고 판단하지 않습니다.

`a10d920`은 부모가 전달한 기존 `fed2211` 지도 GET 경합 수정과 같은 범위의 재수정입니다. `5829fc2`도 부모가 알려준 기존 채팅 원자적 저장 개선을 복원본에 다시 적용한 범위입니다. 두 변경 모두 새로운 독립 발견으로 기록하지 않습니다. 이전 수정 원본 객체/patch가 없어 바이트 단위 대조는 미검증이고, 사라진 `2709bb7` 전체를 복구했다는 주장이 아닙니다.

전체 git status는 아래와 같습니다. `--untracked-files=all`로 시작과 종료 모두 확인했습니다. ignored 런타임/테스트 생성물의 존재와 git clean은 별개입니다.

```text
/workspace/scratch/saju-restore-verify-20261009
On branch maint/guin-map-loading-20261009
nothing to commit, working tree clean

/workspace/saju-project
On branch work
nothing to commit, working tree clean
HEAD: 2e2d82b05f87b39ff8057ae914e8dfa01100a974
```

`40f0c9a..5829fc2`의 누적 변화는 5개 파일, 303줄 추가/19줄 삭제입니다:

| 파일 | 변경 | 담당 커밋 |
|---|---|---|
| `app/guin/[id]/page.tsx` | 수정, ID별 화면 상태와 GET 취소/늦은 응답 방지 | a10d920 |
| `scripts/qa/guin-map-loading-dom.mjs` | 추가, 실제 페이지의 합성 DOM 수명 QA | a10d920 |
| `app/api/saju/[id]/chat/route.ts` | 수정, 답변 생성 뒤 질문·답변 교환 저장 | 5829fc2 |
| `lib/db/store.ts` | 수정, owner 조건을 유지하는 D1 batch 교환 저장 | 5829fc2 |
| `scripts/qa/chat-atomic-persistence.mjs` | 추가, 실제 Worker와 메모리 D1 실패/동시/권한 QA | 5829fc2 |

현재 이 5개 파일의 SHA-256은 각각 이전 커밋 검증 당시 저장한 소스 checksum과 같았습니다. 이번 테스트의 출력 및 런타임 임시 경로는 `/workspace/scratch/saju-cumulative-regression-run-20261009`와 이 evidence 폴더로 분리했습니다. 기존 소스·빌드·검증용 지속 DB에 쓰지 않았습니다. 각 D1 QA는 새 메모리 DB만 사용했고, Worker 외부 요청은 차단/모의 처리했습니다.

이번 새 실행 결과:

| 항목 | 결과 | 직접 증거 |
|---|---|---|
| 지도 GET DOM | 성공 7/7 | `guin-dom.log` |
| 채팅 원자적 저장 D1 | 성공 3/3, 답변 INSERT 실패 후 기록 0건·재전송 성공 | `chat-atomic.log` |
| 기존 대화 복구 DOM | 성공 7 그룹 | `chat-recovery-dom.log` |
| 저장 목록 DOM | 성공 6 그룹 | `saved-archive-dom.log` |
| 저장 목록 API | 성공 4 그룹, 합성 120건·기존 인덱스·소유자 격리 유지 | `saved-archive-api.log` |
| 전체 기존 통합 suite | 성공 23/23, 지도와 채팅 API/페이지 모두 포함 | `integration-23.log` |
| Jade CPU | 성공 10/10 | `jade-cpu.log` |
| 승인 자산·모델 | 성공, 보존 source 파일 46개·PNG/raw 일치·GLB checksum 일치 | `verify-assets.log` |
| TypeScript `--noEmit --incremental false` | 성공 | `typecheck.log` |
| 전체 lint | 실패 유지 44 오류·38 경고 | `lint.json`, `lint-summary.json` |

lint는 직전 `5829fc2` 검증의 모든 파일/규칙/위치/메시지와 동일했습니다. 새 위반이나 회귀는 없고 기존 규칙을 약화하지 않았습니다. 테스트 pass와 lint pass를 혼동하지 않습니다.

이번 읽기 전용 검토에서는 빌드를 다시 생성하지 않았습니다. 바로 이전 채팅 재수정 때 `npm run build`가 성공한 결과를 사용했고, entry의 mtime은 시작·종료 모두 `2026-10-09T09:19:11.977992+00:00`입니다. 새 통합/D1 테스트는 그 실제 빌드 Worker를 실행했습니다. 빌드 성공 근거는 [직전 build 결과](../saju-chat-atomic-evidence-20261009/build.result.json), 이번 재실행 근거는 각 `*.result.json`에 있습니다.

이전 회차에서 직접 확인한 준비 결과도 구분해 보존합니다:

- `portable` 프로필의 `npm run install:ci`, 모델 복원 및 checksum 확인, 로컬 D1 0000/0001 초기화, 타입·빌드·통합 23개가 성공했습니다.
- 실제 개발 서버 페이지 응답과 프로세스 재시작 후 합성 풀이·채팅·지도 데이터 유지가 성공했습니다. 이번에는 기존 지속 DB를 다시 열지 않고 당시 [재시작 결과](../saju-restore-evidence-20261009/dev-persistence.json)를 근거로 표시합니다.
- 양쪽 잠금파일 SHA-256은 `ffb8ad533a7ea1d2f48ca306489d19884296f7902423fbbc00c48f3b8fd11d4e`입니다.
- porcelain GLB는 13,700,928바이트, SHA-256 `57d7ee5b3c4e0b99eaadefb8095283bed44986beaa5a91c096dd7a0c514bf9c2`를 이번에도 직접 확인했습니다.
- `a10d920`의 증분 bundle·patch·실패/성공 근거는 Library `/SaJu_Map_GET_Race_Reapplied_a10d920_20261009.zip` (`libfile_a19d0837125081919e95a56b711cf28e`)에 저장돼 있습니다. 이 ZIP은 지도 커밋까지의 보존 자료이며 `5829fc2`를 포함한 전체 누적 백업은 아닙니다. 현재 두 수정의 소스/QA는 원격 `5829fc2` 브랜치에서 함께 복원할 수 있습니다.

복원 가능 범위는 원격의 정확한 `5829fc21c34f00b8dd7684259b4d3e712fddd580` 소스, 그 조상 `40f0c9a`에 보존된 모델/텍스처, 두 재수정과 QA입니다. 새 checkout의 기준 ref/SHA를 이 값으로 명시해야 이 누적 수정본을 대상으로 할 수 있습니다. 기본 `main`만 checkout하면 두 재수정은 포함되지 않습니다. 의존성·`dist`·runtime GLB·로컬 DB는 ignored 상태이므로 Git checkout 그 자체만으로 준비됐다고 판단할 수 없습니다. 저장소의 설치/승인 자산 복원 스크립트와 새 격리 DB 준비가 별도로 필요합니다. SQL 0000/0001은 이미 있는 DB에 무조건 재실행하면 안 되며 적용 이력/현재 상태를 먼저 확인해야 합니다.

미실행/미검증 범위:

- native WebGL 렌더, 물리 GPU·모바일 터치·native shader 외형, 최신 10천간 loader/GPU 결과. 이번 자산 checksum·CPU 및 JSDOM은 이를 검증하지 않습니다.
- 실제 hosted 로그인, 사용자 실데이터, 외부 LLM·유료 API.
- 사이트 배포·공개 전환, PR·merge·추가 권한 또는 새 인증 설정.
- 클라우드 환경 설정 Publish와 그 게시 설정에서 새 환경을 생성한 자동 복원, `managed-linux` 프로필, 화면에 저장됐다는 install_script/start_skill 초안 원문. 환경 Publish와 사이트 공개는 별개이며 둘 다 실행하지 않았습니다.
- 사라진 `2709bb7` 전체, 차단된 최신 홈/10천간 후보의 실제 ZIP 내용·checksum·원본 commit 적용. Library 다운로드 403은 이번에 재시도하거나 우회하지 않았습니다.

다음 통합에 필요한 최소 입력은 기존 승인된 원본 두 개의 실제 bytes와 원본 검증 정보입니다. 현재 계보 검토나 회귀 재실행을 막는 추가 입력은 없습니다.

| 통합 순서 | 필요한 승인 원본 | 이미 전달된 정보 | 아직 필요한 입력 |
|---|---|---|---|
| 1. 홈 | `SaJu_Mobile_Home_Validated_20261009_0708.zip`, Library `libfile_063ee0caabbc8191a4a106468826f1dc` | 원본 commit `c5d13cfc61b85526675ed2fb6705bef29856e8ab` | 공식 지원 경로에서 접근 가능한 실제 ZIP, ZIP SHA-256, archive 안의 base/patch 정보. 홈 ZIP SHA는 현재 받지 못했습니다. |
| 2. 10천간 재질 | `SaJu_Ten_Stem_Material_Commit_a97c418_20261009.zip`, Library `libfile_ea461fe7b4b08191a368a1023c392bfb` | commit `a97c4182ed2b71f9f2ce92fd8d4bc6348073b890`, 제공 SHA-256 `816ba284a1c7b4fa7c836c02dacd7be5a02843dabb695c4f02e3cb2e31da8702` | 공식 지원 경로의 실제 ZIP과 base/patch 정보. 제공 SHA와 실제 bytes 일치는 아직 확인하지 못했습니다. |

통합 기준은 현재 `5829fc2`이며, 먼저 홈 원본을 대조해 기존 입력 폼·모바일 진입·내부 Link를 보존하고, 다음 재질 원본을 대조합니다. 이미 승인된 己 jade green / 乙 vine leaves 및 depth 1.35 보존 요구를 기준으로 하고 실제 loader/GPU 결과는 별도 검증이 필요합니다. 완전한 덩굴 몸체·戊 모래·壬 물보라는 미구현 범위로 유지합니다. 후보를 재생성하거나 차단된 파일을 다른 경로로 가져오는 절차는 제안하지 않습니다.

전체 직접 증거는 `baseline.json`(시작 상태), 각 `.log`/`.result.json`, `final-state.json`(종료 상태·원격 SHA·lint 일치)에 있습니다. 이전 상세 근거는 [초기 복원 보고](../saju-restore-evidence-20261009/REPORT.md), [지도 계보/보존 인계](../saju-preserve-a10d920-20261009/HANDOFF.md), [채팅 재수정 보고](../saju-chat-atomic-evidence-20261009/REPORT.md)에 있습니다.
