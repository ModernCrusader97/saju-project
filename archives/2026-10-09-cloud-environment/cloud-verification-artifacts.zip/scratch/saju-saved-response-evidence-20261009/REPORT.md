저장 목록의 불완전한 항목이 검색·날짜 표시 과정에서 렌더 예외를 일으키는 문제를 새 메모리 D1과 실제 API·SavedPage로 재현했습니다. 화면 상태에 목록을 넣기 전에 표시·검색에 필요한 값을 검사하도록 최소 수정했고, 기존 오류 안내와 “다시 불러오기” 흐름으로 연결했습니다. 현재 비공개 작업 브랜치의 로컬·원격 HEAD는 `43e2d8dc6efe1654641e639397f37d0ea44f525a`로 일치합니다.

[커밋](https://github.com/ModernCrusader97/saju-project/commit/43e2d8dc6efe1654641e639397f37d0ea44f525a), [기존 작업 브랜치](https://github.com/ModernCrusader97/saju-project/tree/maint/guin-map-loading-20261009), [원격 readback과 종료 상태](final-state.json).

시작의 로컬·원격 HEAD는 `0dec3e47581437b01390fbb3e8343b20b4b00048`이었고, 검증 checkout과 원본 checkout 모두 clean이었습니다. 그 이후 다른 작업 변경은 없었습니다. 로컬 AGENTS.md/관련 .agents 지침은 발견하지 못했습니다. 원본 `/workspace/saju-project`는 `work` 브랜치의 `2e2d82b05f87b39ff8057ae914e8dfa01100a974`를 유지했습니다. [시작 상태](baseline.json).

이번에 선택한 하나의 결함은 “배열 여부만 확인하고 목록 항목을 렌더 가능한 응답으로 신뢰하는 처리”입니다. 실제 summary SQL은 JSON에서 필드를 추출하지만 필수 필드의 누락/null이나 저장 일자 형식을 보장하지 않습니다. 기존 클라이언트는 이름·제목·요약·일간에 `toLowerCase()`를 호출하고 기록 일자에 `toISOString()`을 호출하므로 불완전한 항목에서 예외가 발생합니다. 이때 목록의 지역 오류·재시도 상태에 도달하지 못합니다.

실데이터는 조사하지 않았습니다. 아래 재현은 모두 테스트에서 생성한 합성 기록을 새 메모리 DB 안에서만 변경한 fault injection입니다. 사용자 기록에 같은 상태가 실제로 존재하는지, 얼마나 자주 발생하는지는 확인하지 않았습니다.

| 수정 전 재현 | 실제 결과 |
|---|---|
| 정상 API로 합성 풀이 생성 후 `analysis.name`을 null로 변경, summary API 응답을 실제 페이지에 제공하고 검색 | HTTP 200 이후 `TypeError: Cannot read properties of null (reading 'toLowerCase')` |
| 합성 행의 `created_at`만 잘못된 문자열로 변경한 실제 summary 응답 | HTTP 200 이후 `RangeError: Invalid time value` |
| 목록 배열의 null 항목 | `TypeError`로 category 접근 실패 |
| 이전 category/dayMaster 필드가 빠진 합성 기록 | 기존 SQL의 `overall`/빈 문자열 기본값으로 정상 표시 |

수정 전 QA는 4개 중 1개 성공·3개 실패했습니다. [실패 로그](saved-response-red.log), [명령·시각·종료 코드](saved-response-red.result.json). React act가 실제 렌더 예외를 테스트 실패로 전달했으며, 기대값을 완화하지 않았습니다.

생산 코드 변경은 `app/saved/page.tsx`의 10줄 추가·1줄 교체뿐입니다. 항목 객체, 비어 있지 않은 문자열 ID, 문자열 필드, 변환 가능한 기록 일자를 확인하고, 잘못된 응답은 기존 `기록 목록을 확인할 수 없습니다.` 오류로 처리합니다. 기존에 허용하던 빈 일자 문자열은 유지합니다. category/dayMaster 누락에 대한 서버 기본값, 검색·분류·URL 상세 선택·캐시 동작도 유지합니다. QA `scripts/qa/saved-list-response-dom.mjs` 151줄을 추가했으며, 총 변화는 두 파일 161줄 추가·1줄 삭제입니다. API, SQL, schema, 인증, 데이터 저장 방법은 변경하지 않았습니다.

이는 기존 저장 목록 응답의 오류 처리를 보완하는 버그 수정입니다. 새 기능 또는 사라진 `2709bb7` 전체 복원으로 부르지 않습니다. 과거 같은 수정이 있었는지는 원본 commit/patch가 없어 확인하지 못했습니다. 앞서 수정한 지도 GET 경쟁 조건·채팅 저장 원자성·자정 갱신은 이번 수정 대상에서 제외했습니다.

최종 직접 실행 결과:

| 검사 | 결과 | 증거 |
|---|---|---|
| 새 실제 API/페이지 회귀 | 4/4 성공 | `saved-response-green-built.log` |
| 기존 저장 페이지 DOM | 6그룹 성공: 목록/상세 요청, 캐시, Back/Forward, 오류·재시도, 검색·빈 결과, unmount | `saved-archive-dom.log` |
| 기존 저장 API | 4그룹 성공, 합성 120건·정렬·소유자 격리·기존 인덱스 유지 | `saved-archive-api.log` |
| 전체 기존 통합 suite | 23/23 성공 | `integration-23.log` |
| TypeScript, noEmit/incremental false | 성공 | `typecheck.log` |
| 새 production build | 성공, 승인 모델·runtime 자산 checksum 검사 수행 | `build.log` |
| 전체 lint | 실패 유지, 기존과 동일한 43오류·37경고 | `lint.json`, `lint-comparison.json` |

새 QA는 잘못된 이름/일자에서 오류 안내와 재시도가 나타나는지, 합성 응답을 정상화한 뒤 복구하는지, 잘못된 항목을 빈 보관함으로 표시하지 않는지, 재시도 HTTP 실패를 보존하다 실제 빈 응답이 오면 빈 상태로 전환하는지, 과거 선택 필드의 기본값을 유지하는지 검사합니다. 목록 QA의 FortuneCard·Header·router는 경계 stub이며 실제 SavedPage와 응답 읽기 코드는 실행합니다. 실제 API는 production build Worker와 메모리 D1을 사용합니다. 실제 브라우저/시각 결과나 전체 FortuneCard 필드의 렌더를 검증한 것으로 해석하면 안 됩니다.

검사 실행 순서 오류 한 번도 숨기지 않고 기록했습니다. `saved-response-green-final`을 build와 동시에 실행해 dist 재생성 중 두 메모리 DB fixture가 `ENOENT`로 실패했습니다(2 성공·2 실패). 이는 제가 빌드 의존 검사를 동시에 실행한 오류이며 제품 결함으로 집계하지 않습니다. build 완료 후 최종 코드와 새 build로 `saved-response-green-built`를 실행해 동일한 4개 검사가 모두 통과했습니다. 시작 시각 `12:14:55 UTC`는 build 종료 `12:13:52 UTC` 이후입니다. 실패 로그도 그대로 보존했습니다. 초안 helper의 첫 성공 `saved-response-green` 이후 검증 함수를 SavedPage 안에 두어 기존 API/DB 모듈과 QA 의존성을 늘리지 않았습니다. 최종 검사 기준은 `saved-response-green-built`입니다.

lint는 직전 `0dec3e4`의 규칙·메시지·개수와 동일합니다. 저장 페이지와 새 QA 파일의 진단은 없고 규칙을 약화하지 않았습니다. 전체 lint 성공으로 보고하지 않습니다. 빌드의 기존 chunk 크기 및 vinext route 분류 경고도 남아 있습니다.

중요한 동작 한계는 불완전한 항목 하나가 있으면 해당 응답의 전체 목록을 오류로 표시한다는 점입니다. 잘못된 항목을 자동으로 고치거나 조용히 버리지 않습니다. 재시도는 GET을 다시 실행하며 실제 데이터를 수정하지 않습니다. 저장소에서 계속 같은 불완전한 응답이 반환되면 오류가 유지됩니다. 테스트에서 정상화한 것은 전부 새 메모리 DB의 합성 행이며, 사용자 DB 정정이나 데이터 복구 작업은 수행하지 않았습니다.

최종 Git 확인:

| 항목 | 결과 |
|---|---|
| 저장소 | 연결된 GitHub metadata에서 `ModernCrusader97/saju-project`, private·push 권한 확인 |
| 새 커밋 및 원격 SHA | `43e2d8dc6efe1654641e639397f37d0ea44f525a` |
| 직접 부모/이전 원격 HEAD | `0dec3e47581437b01390fbb3e8343b20b4b00048` |
| 원격 readback 시각 | 2026-10-09 12:18:42 UTC |
| main, push 전후 | `2e2d82b05f87b39ff8057ae914e8dfa01100a974`, 동일 |
| 원본·검증 checkout | 모두 clean |
| `40f0c9a..43e2d8d` 누적 변화 | 10개 파일, 670줄 추가·38줄 삭제 |

기존 작업 브랜치만 명시해 정상 fast-forward push했으며 force·tag·main 변경·PR·merge를 수행하지 않았습니다. 정확한 원격 복원 기준은 이제 `43e2d8d…`이며 `40f0c9a → a10d920 → 5829fc2 → 0dec3e4 → 43e2d8d`가 이어집니다. main만 checkout하면 이 누적 수정들은 포함되지 않습니다. 의존성·생성 모델·dist·DB는 새 checkout에서 별도로 준비해야 합니다.

원본·잠금파일·기존 검증 DB를 보존했습니다. 양쪽 잠금파일 SHA-256은 `ffb8ad533a7ea1d2f48ca306489d19884296f7902423fbbc00c48f3b8fd11d4e`로 같고 이전 값과 일치합니다. 기존 지속 합성 DB/캐시 파일의 크기·mtime은 시작과 종료에 동일하며 내용을 읽지 않았습니다. 이번 D1 검사는 모두 `d1Persist:false`의 새 메모리 DB였고 출력·registry는 별도 test view/evidence 경로를 사용했습니다. 실데이터·실제 키·비밀값은 읽거나 출력하지 않았습니다. 새 API/목록 회귀는 외부 요청 0건이며, 통합 suite의 AI 응답은 합성 fixture와 모의 응답만 사용합니다.

사이트 배포·공개 전환·클라우드 환경 설정 Publish·새 환경 생성·인증 변경은 실행하지 않았습니다. 클라우드 자동 복원과 실제 hosted 로그인은 여전히 미검증입니다. 최신 홈/10천간 Library 403은 재시도하거나 우회하지 않았으며 원본 bytes 확보 전에는 통합하지 않았습니다. 다음 원본 통합의 기준 SHA는 이번 `43e2d8d…`입니다. 초기 복원/데이터 재시작 근거는 [초기 보고](../saju-restore-evidence-20261009/REPORT.md), 직전 자정 재적용 결과는 [자정 갱신 보고](../saju-daily-rollover-evidence-20261009/REPORT.md)에 있습니다.

직접 증거는 `baseline.json`, 각 `.log`/`.result.json`, `lint-comparison.json`, `precommit.json`, `remote-before.json`, `final-state.json`에 있습니다. 소스/QA는 원격 커밋에 보존됐고 로컬 evidence 폴더는 그 커밋에 포함되지 않습니다.
