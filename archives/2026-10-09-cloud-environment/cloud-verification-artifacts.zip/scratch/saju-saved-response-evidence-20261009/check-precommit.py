import datetime
import hashlib
import json
from pathlib import Path
import subprocess

evidence = Path(__file__).resolve().parent
root = Path('/workspace/scratch/saju-restore-verify-20261009')
base = json.loads((evidence / 'baseline.json').read_text())
files = ('app/saved/page.tsx', 'scripts/qa/saved-list-response-dom.mjs')

def git(*args, cwd=root):
    return subprocess.run(['git', *args], cwd=cwd, text=True, capture_output=True, check=True).stdout.rstrip('\n')

results = {p.stem.removesuffix('.result'): json.loads(p.read_text()) for p in evidence.glob('*.result.json')}
required = ('saved-response-green-built', 'saved-archive-dom', 'saved-archive-api', 'integration-23', 'typecheck', 'build')
assert all(results[label]['exit_code'] == 0 for label in required)
assert results['saved-response-red']['exit_code'] == 1
assert results['saved-response-green-built']['started_utc'] > results['build']['ended_utc']
lint = json.loads((evidence / 'lint-comparison.json').read_text())
assert lint['before'] == lint['after'] == {'errors': 43, 'warnings': 37}
assert lint['all_rules_messages_equal_ignoring_shifted_line_numbers']
assert not lint['new_qa_diagnostics'] and not lint['saved_page_diagnostics']
assert git('rev-parse', 'HEAD') == base['head']
assert git('branch', '--show-current') == base['branch']
status = git('status', '--porcelain', '--untracked-files=all')
assert set(line[3:] for line in status.splitlines()) == set(files), status
assert git('status', '--porcelain', '--untracked-files=all', cwd='/workspace/saju-project') == ''
assert git('rev-parse', 'HEAD', cwd='/workspace/saju-project') == base['original_head']
locks = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in map(Path, base['lock_sha256'])}
assert locks == base['lock_sha256']
state = {str(p.relative_to(root)): {'size': p.stat().st_size, 'mtime_ns': p.stat().st_mtime_ns} for p in (root / '.wrangler/state').rglob('*') if p.is_file()}
assert state == base['persistent_state_metadata']
refs = {line.split('\t')[1]: line.split('\t')[0] for line in git('ls-remote', '--heads', 'origin', 'refs/heads/' + base['branch'], 'refs/heads/main').splitlines()}
assert refs['refs/heads/' + base['branch']] == base['head']
assert refs['refs/heads/main'] == base['original_head']
result = {
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'base_sha': base['head'],
    'branch': base['branch'], 'changed_files': files, 'source_sha256': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files},
    'passed_commands': required, 'lint': lint['after'], 'new_lint_diagnostics': False,
    'status': status, 'remote_refs': refs, 'original_repository_clean': True,
    'locks_preserved': True, 'synthetic_persistent_db_metadata_unchanged': True,
    'persistent_db_contents_read': False,
    'test_run_failure_preserved': {'label': 'saved-response-green-final', 'reason': 'Test was mistakenly run concurrently with build; two fixtures hit ENOENT while dist was recreated. Reran after build without changing assertions.'},
    'scope': 'Existing saved-list malformed-response error handling; no new feature or claim of restoring 2709bb7.'
}
with (evidence / 'precommit.json').open('x') as file:
    json.dump(result, file, ensure_ascii=False, indent=2)
    file.write('\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
