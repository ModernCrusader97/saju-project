import bpy, math, os, sys, json, random, struct
from mathutils import Vector
from math import sin,cos,pi
P=os.path.dirname(os.path.abspath(__file__)); SOURCE=os.path.dirname(P)+'/elemental_form_comparison/B_final.blend'
INDEX=int(sys.argv[sys.argv.index('--')+1]) if '--' in sys.argv else 0
NAMES=['01_Jia','02_Yi','03_Bing','04_Ding','05_Wu','06_Ji','07_Geng','08_Xin','09_Ren','10_Gui','11_Ji_Jade_OPTION']
bpy.ops.wm.open_mainfile(filepath=SOURCE)
body=bpy.data.objects['B | continuous soft body and small hands']; rnd=random.Random(730+INDEX)
def mat(name,col,rough=.45,metal=0,trans=0,em=0):
 m=bpy.data.materials.new(name);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*col,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal;p.inputs['Transmission Weight'].default_value=trans;p.inputs['IOR'].default_value=1.333;p.inputs['Coat Weight'].default_value=0 if rough>=.5 or metal else .18
 if em:p.inputs['Emission Color'].default_value=(*col,1);p.inputs['Emission Strength'].default_value=em
 return m
def setmat(o,m):o.data.materials.clear();o.data.materials.append(m)
def uv(name,loc,scale,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 for f in o.data.polygons:f.use_smooth=True
 return o
def line(name,pts,rad,m):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.bevel_depth=rad;c.bevel_resolution=2;s=c.splines.new('POLY');s.points.add(len(pts)-1)
 for b,p in zip(s.points,pts):b.co=(*p,1)
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);o.data.materials.append(m);return o
def radial(a,z,off=0):
 d=Vector((cos(a),sin(a),0));origin=Vector((d.x*2,d.y*2,z));inv=body.matrix_world.inverted();h,p,n,i=body.ray_cast(inv@origin,inv.to_3x3()@(-d))
 if h:return body.matrix_world@p+d*off
 return None
def front(x,z,off=.012):
 inv=body.matrix_world.inverted();h,p,n,i=body.ray_cast(inv@Vector((x,-2,z)),inv.to_3x3()@Vector((0,1,0)))
 if h:return body.matrix_world@p+Vector((0,-off,0))
 return None
def quiet(p):return p.y<-.15 and abs(p.x)<.44 and 1.43<p.z<2.13
def colbody(name,palette,rough,metal=0,trans=0,kind='plain'):
 m=mat(name,(1,1,1),rough,metal,trans);setmat(body,m);attr=body.data.color_attributes.new(name='Color',type='FLOAT_COLOR',domain='CORNER')
 for poly in body.data.polygons:
  for li in poly.loop_indices:
   v=body.matrix_world@body.data.vertices[body.data.loops[li].vertex_index].co;x,y,z=v
   if kind=='bark':t=.5+.2*sin(40*x+5*sin(z*4))+ .18*sin(83*x+12*sin(z*2))
   elif kind=='earth':t=.5+.25*sin(z*22+3*sin(x*5))+ .17*sin(z*61+x*9)
   elif kind=='charcoal':t=.32+.2*sin(x*28+sin(z*19))+ .12*sin(z*31)
   elif kind=='flame':t=max(0,min(1,(z-.1)/2.2+.12*sin(x*13+z*8)))
   elif kind=='water':t=.5+.20*sin(z*10+x*7)+.13*sin(z*16-x*12)
   elif kind=='jade':t=.5+.18*sin(x*7+sin(z*3)+y*4)+.13*sin(z*5+sin(x*5-y*4))
   else:t=.5
   if y<0:
    mask=math.exp(-((x/.43)**6+((z-1.78)/.39)**6));t=t*(1-mask)+(.52 if kind=='flame' else .5)*mask
   t=max(0,min(1,t));c=tuple(palette[0][j]*(1-t)+palette[1][j]*t for j in range(3));attr.data[li].color=(*c,1)
 vc=m.node_tree.nodes.new('ShaderNodeVertexColor');vc.layer_name='Color';m.node_tree.links.new(vc.outputs['Color'],m.node_tree.nodes.get('Principled BSDF').inputs['Base Color']);return m

def leaf(name,p,size,m,angle=0):
 o=uv(name,p,(size,.019,size*.44),m);o.rotation_euler.y=angle;return o

def flame(name,base,height,width,m,lean=.1):
 # tapered flowing 3D petal with asymmetrical bowed centre, never a candle stick
 verts=[];faces=[];rings=12;seg=12
 for j in range(rings):
  t=j/(rings-1);r=width*(sin(pi*t)**.7)*(.9-.45*t)+.003
  for k in range(seg):
   a=2*pi*k/seg;verts.append((base[0]+lean*t*t+r*cos(a),base[1]+.07*sin(pi*t)+r*.45*sin(a),base[2]+height*t))
 for j in range(rings-1):
  for k in range(seg):a=j*seg+k;b=j*seg+(k+1)%seg;faces.append((a,b,b+seg,a+seg))
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);o.data.materials.append(m)
 for f in mesh.polygons:f.use_smooth=True
 return o

if INDEX==0:
 colbody('Bark • warm longitudinal grain',[(.13,.047,.019),(.44,.22,.075)],.63,kind='bark')
 ridge=mat('Raised bark grain',(.28,.12,.042),.67);tip=mat('Fresh branch end',(.65,.39,.13),.6)
 for k in range(20):
  a=2*pi*k/20;pts=[]
  for j in range(45):
   z=.14+j*.049;p=radial(a+.025*sin(z*12+k),z,.004)
   if p is not None and not quiet(p):pts.append(p)
   elif len(pts)>2:line('Continuous bark seam',pts,.006,ridge);pts=[]
  if len(pts)>2:line('Continuous bark seam',pts,.006,ridge)
 for sign,z in [(-1,2.18),(1,2.15)]:
  pts=[(sign*.40,.04,z),(sign*.48,.03,z+.20),(sign*.43,.02,z+.35)];line('Forked living branch',pts,.037,ridge);line('Branch fork',[pts[1],(sign*.62,.04,z+.26)],.023,ridge)
  uv('Warm branch tip',pts[-1],(.036,.036,.019),tip)
elif INDEX==1:
 colbody('Vine underweave',[(.075,.13,.035),(.16,.25,.052)],.6)
 greens=[mat('Interwoven vine '+str(k),c,.52) for k,c in enumerate([(.05,.18,.021),(.12,.27,.039),(.20,.33,.064),(.08,.21,.033)])];lm=mat('Small living leaves',(.25,.48,.09),.42)
 for k in range(46):
  pts=[]
  for j in range(150):
   z=.035+2.33*j/149;a=2*pi*k/46+z*(3.5 if k%2 else -3.5)+.16*sin(z*6+k*.9)+.055*sin(z*11+k);p=radial(a,z,.015+.008*sin(z*13+k))
   if p is not None:
    # suppress protrusion near expression without changing quiet face placement
    if quiet(p):p=radial(a,z,-.019)
    pts.append(p)
  if len(pts)>4:line('Living intertwined vine %02d'%k,pts,.021 if k%3 else .026,greens[k%4])
 for k in range(12):
  x=(-.52 if k%2 else .48)+rnd.uniform(-.045,.045);z=.53+k*.135;p=front(x,z,.04)
  if p is not None:leaf('Small vine leaf',p,.105,lm,(-1 if k%2 else 1)*.5)
 for x in [-.2,.15]:
  p=front(x,2.22,.045)
  if p is not None:leaf('Crown leaf',p,.11,lm,-.3)
elif INDEX==2:
 colbody('Vigorous warm flame body',[(.75,.055,.004),(1,.48,.025)],.27,kind='flame')
 orange=mat('Luminous amber flame', (1,.18,.009),.26,em=.45);gold=mat('Yellow hot interior',(1,.64,.05),.24,em=.5);blue=mat('Rare blue-hot seam',(.03,.30,.8),.26,em=.5)
 for base,h,w,l in [((-.38,.03,1.97),.62,.15,-.16),((.06,.04,2.07),.56,.20,.13),((.45,.02,1.79),.51,.13,.14)]:flame('Sweeping warm flame',base,h,w,orange,l)
 flame('Central hot tongue',(-.12,-.13,2.07),.50,.10,gold,.14)
 for x,z in [(-.34,.38),(.37,.91)]:
  p=front(x,z,.025)
  if p is not None:flame('Blue-hot detail',p,.19,.035,blue,.028)
elif INDEX==3:
 colbody('Quiet charcoal mass',[(.025,.025,.022),(.095,.08,.066)],.8,kind='charcoal')
 ember=mat('Ember orange',(.95,.09,.008),.46,em=1.3);gold=mat('Small flame tips',(1,.37,.017),.34,em=.8)
 for k in range(13):
  x=rnd.uniform(-.43,.43);z=rnd.choice([rnd.uniform(.22,1.28),rnd.uniform(2.12,2.27)]);pts=[]
  for j in range(5):
   p=front(x+.027*sin(j*2+k),z+j*.025,.009)
   if p is not None:pts.append(p)
  if len(pts)>2:line('Narrow ember fracture',pts,.008,ember)
 for base,h,w,l in [((-.26,.015,2.22),.25,.066,-.06),((.14,.00,2.28),.27,.07,.07)]:flame('Small ember flame',base,h,w,gold,l)
elif INDEX==4:
 colbody('Earth and sediment strata',[(.22,.115,.054),(.62,.39,.17)],.78,kind='earth')
 stone=mat('Stone stratum edges',(.43,.26,.12),.84)
 for z in [.29,.55,.85,1.12,2.17]:
  pts=[]
  for k in range(65):
   a=2*pi*k/64;p=radial(a,z+.018*sin(a*5),.006)
   if p is not None:pts.append(p)
  if len(pts)>3:line('Readable sediment ledge',pts,.012,stone)
 # low faceted stones are an integrated shoulder/crown outcrop
 for x,y,z,s in [(-.37,.05,2.20,.14),(-.16,.08,2.31,.12),(.04,.13,2.28,.095)]:
  bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=s,location=(x,y,z));bpy.context.object.name='Small mineral outcrop';bpy.context.object.data.materials.append(stone)
elif INDEX==5:
 glass=colbody('Warm plum coloured solid glass',[(.29,.035,.18),(.68,.20,.40)],.10,trans=.64)
 pp=glass.node_tree.nodes.get('Principled BSDF');pp.inputs['IOR'].default_value=1.47;pp.inputs['Coat Weight'].default_value=.40
 edge=mat('Thick glass foot and rim',(.52,.09,.25),.095,trans=.55);edge.node_tree.nodes.get('Principled BSDF').inputs['IOR'].default_value=1.47
 pts=[radial(2*pi*j/64,.24,.008) for j in range(65)];line('Solid cast glass footing',[p for p in pts if p is not None],.026,edge)
 # restrained internal coloured inclusions evoke depth rather than floral patterns
 for x,z in [(-.24,.53),(.20,.89)]:
  uv('Soft glass depth inclusion',(x,.15,z),(.11,.12,.23),edge)
elif INDEX==6:
 colbody('Premium satin stainless steel',[(.48,.54,.57),(.71,.75,.76)],.31,1)
 steel=mat('Polished seam stainless',(.59,.66,.69),.20,1)
 # fine fabricated inset lines with changing orientation; no corrosion
 for z in [.27,.93,2.15]:
  pts=[radial(2*pi*j/64,z,.003) for j in range(65)];pts=[p for p in pts if p is not None]
  if len(pts)>3:line('Satin forming seam',pts,.005,steel)
 # Real material roughness texture with packed image and UVs, portable in GLB
 bpy.context.view_layer.objects.active=body;body.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.02);bpy.ops.object.mode_set(mode='OBJECT')
 import numpy as np
 n=512;y,x=np.mgrid[0:n,0:n];v=.31+.045*np.sin(y*2.8)+.025*np.sin(x*.21+y*.61);img=bpy.data.images.new('Stainless fine brush roughness',n,n);a=np.ones((n,n,4),dtype=np.float32);a[:,:,:3]=v[:,:,None];img.pixels.foreach_set(a.ravel());img.pack();img.colorspace_settings.name='Non-Color';m=body.data.materials[0];tex=m.node_tree.nodes.new('ShaderNodeTexImage');tex.image=img;m.node_tree.links.new(tex.outputs['Color'],m.node_tree.nodes.get('Principled BSDF').inputs['Roughness'])
elif INDEX==7:
 colbody('Refined mirror silver',[(.74,.79,.83),(.88,.91,.93)],.075,1)
 silver=mat('Silver geometric finishing edge',(.76,.84,.89),.10,1)
 pts=[radial(2*pi*j/64,.23,.008) for j in range(65)];line('Single silver finishing edge',[p for p in pts if p is not None],.009,silver)
elif INDEX==8:
 colbody('Coherent flowing blue water',[(.016,.18,.40),(.12,.52,.75)],.12,trans=.44,kind='water')
 flow=mat('Flowing water highlights',(.22,.66,.81),.14,trans=.32)
 for k in range(4):
  pts=[]
  for j in range(65):
   a=2*pi*j/64;z=.35+k*.22+.14*sin(a*1.4+k);p=radial(a,z,.010)
   if p is not None and not quiet(p):pts.append(p)
  if len(pts)>3:line('Continuous flowing current',pts,.015,flow)
 # one coherent curl, integrated with crown, not humanoid hair
 pts=[]
 for j in range(30):
  t=j/29;pts.append((-.28+.47*t,.02+.015*sin(t*pi),2.17+.20*sin(t*pi)))
 line('Single coherent crest',pts,.052,flow)
elif INDEX==9:
 colbody('Cool pearl condensed moisture',[(.58,.76,.80),(.85,.92,.91)],.17,trans=.3)
 dew=mat('Rounded dew droplets',(.69,.87,.93),.065,trans=.68)
 for k in range(42):
  a=rnd.uniform(0,2*pi);z=rnd.uniform(.15,2.26);p=radial(a,z,.017)
  if p is None or quiet(p):continue
  r=rnd.uniform(.021,.055);uv('Condensation bead',p,(r,r*.68,r*1.05),dew)
 for x,z,r in [(-.49,1.87,.038),(.48,2.02,.029),(-.20,2.25,.033)]:
  p=front(x,z,.021)
  if p is not None:uv('Dew highlight',p,(r,r*.66,r*1.15),dew)

elif INDEX==10:
 jade=colbody('OPTION • cloudy polished jade-like mineral',[(.20,.39,.23),(.39,.56,.31)],.29,trans=.16,kind='jade')
 pp=jade.node_tree.nodes.get('Principled BSDF');pp.inputs['IOR'].default_value=1.52;pp.inputs['Coat Weight'].default_value=.08

# Keep original face geometry and pose identical, change expression ink only for readability.
if INDEX in [3]:
 for o in bpy.context.scene.objects:
  if 'almond gaze' in o.name or 'expressive brow' in o.name or 'quiet smile' in o.name:
   setmat(o,mat('Warm ivory expression',(.88,.77,.52),.37))
# Shift face minimally above woven surface, preserving all x/z and expressions.
if INDEX==1:
 for o in bpy.context.scene.objects:
  if any(n in o.name for n in ['almond gaze','small eye glint']):o.location.y-=.035
  if any(n in o.name for n in ['expressive brow','quiet smile']):
   for sp in o.data.splines:
    for p in sp.bezier_points:p.co.y-=.035
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=80;s.cycles.use_denoising=False;s.render.threads_mode='FIXED';s.render.threads=2;s.render.resolution_x=480;s.render.resolution_y=480;s.render.resolution_percentage=100;s.render.filepath=P+'/'+NAMES[INDEX]+'.png'
# Standard glTF-compatible PBR or explicit color attributes only. Exclude studio from export.
bpy.ops.object.select_all(action='DESELECT')
for o in bpy.context.scene.objects:
 if o.type in ['MESH','CURVE','EMPTY'] and o.name!='Plane':o.select_set(True)
bpy.ops.export_scene.gltf(filepath=P+'/'+NAMES[INDEX]+'.glb',export_format='GLB',use_selection=True,export_apply=True,export_attributes=True)
bpy.ops.wm.save_as_mainfile(filepath=P+'/'+NAMES[INDEX]+'.blend')
with open(P+'/'+NAMES[INDEX]+'.glb','rb') as f:d=f.read();n=struct.unpack_from('<I',d,12)[0];g=json.loads(d[20:20+n])
audit={'name':NAMES[INDEX],'bytes':len(d),'meshes':len(g.get('meshes',[])),'triangles':sum(g['accessors'][p['indices']]['count']//3 for m in g['meshes'] for p in m['primitives']),'vertices':sum(g['accessors'][p['attributes']['POSITION']]['count'] for m in g['meshes'] for p in m['primitives']),'extensions':g.get('extensionsUsed',[]),'vertex_color_primitives':sum('COLOR_0' in p['attributes'] for m in g['meshes'] for p in m['primitives']),'images':len(g.get('images',[])),'body_reference_preserved':True}
with open(P+'/'+NAMES[INDEX]+'_audit.json','w') as f:json.dump(audit,f,indent=2)
print('AUDIT',audit,flush=True)
if os.environ.get('NO_RENDER')!='1':bpy.ops.render.render(write_still=True)
