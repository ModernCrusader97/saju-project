import bpy,os,sys,math,json,struct
from math import sin
s=bpy.context.scene
s.render.resolution_x=512;s.render.resolution_y=512;s.cycles.samples=128;s.cycles.use_denoising=False;s.render.threads_mode='FIXED';s.render.threads=2
s.world.node_tree.nodes.get('Background').inputs['Strength'].default_value=.45
bpy.data.objects['Broad soft key'].data.size=3
bpy.data.objects['Pale rim'].data.energy=350
bpy.data.objects['Quiet face fill'].visible_glossy=False
try:s.view_settings.look='AgX - Medium High Contrast'
except:pass
for m in bpy.data.materials:
 if not m.use_nodes:continue
 p=m.node_tree.nodes.get('Principled BSDF')
 if p and (p.inputs['Roughness'].default_value>=.5 or p.inputs['Metallic'].default_value>.5):p.inputs['Coat Weight'].default_value=0
body=bpy.data.objects.get('B | continuous soft body and small hands');stem=os.path.basename(bpy.data.filepath).split('_')[0]
conf={'01':([(.13,.047,.019),(.44,.22,.075)],'bark'),'03':([(.75,.055,.004),(1,.48,.025)],'flame'),'04':([(.025,.025,.022),(.095,.08,.066)],'charcoal'),'05':([(.22,.115,.054),(.62,.39,.17)],'earth'),'09':([(.016,.18,.40),(.12,.52,.75)],'water')}
if stem in conf:
 pal,kind=conf[stem];attr=body.data.color_attributes.get('Color')
 for poly in body.data.polygons:
  for li in poly.loop_indices:
   x,y,z=body.matrix_world@body.data.vertices[body.data.loops[li].vertex_index].co
   if kind=='bark':t=.5+.2*sin(40*x+5*sin(z*4))+.18*sin(83*x+12*sin(z*2))
   elif kind=='earth':t=.5+.25*sin(z*22+3*sin(x*5))+.17*sin(z*61+x*9)
   elif kind=='charcoal':t=.32+.2*sin(x*28+sin(z*19))+.12*sin(z*31)
   elif kind=='flame':t=max(0,min(1,(z-.1)/2.2+.12*sin(x*13+z*8)))
   else:t=.5+.20*sin(z*10+x*7)+.13*sin(z*16-x*12)
   if y<0:
    mask=math.exp(-((x/.43)**6+((z-1.78)/.39)**6));t=t*(1-mask)+(.52 if kind=='flame' else .5)*mask
   t=max(0,min(1,t));attr.data[li].color=tuple(pal[0][j]*(1-t)+pal[1][j]*t for j in range(3))+(1,)
s.render.filepath=bpy.data.filepath.replace('.blend','.png')
bpy.ops.object.select_all(action='DESELECT')
for o in s.objects:
 if o.type in ['MESH','CURVE','EMPTY'] and o.name!='Plane':o.select_set(True)
bpy.ops.export_scene.gltf(filepath=bpy.data.filepath.replace('.blend','.glb'),export_format='GLB',use_selection=True,export_apply=True,export_attributes=True)
bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath)
bpy.ops.render.render(write_still=True)
