from PIL import Image,ImageDraw,ImageFont
import os,glob,json,struct
P=os.path.dirname(os.path.abspath(__file__))
font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
names=['01_Jia','02_Yi','03_Bing','04_Ding','05_Wu','06_Ji','07_Geng','08_Xin','09_Ren','10_Gui']
labels=['甲 갑 | Bark & branches','乙 을 | Living vines','丙 병 | Warm flame','丁 정 | Charcoal & embers','戊 무 | Earth strata','己 기 | Coloured glass','庚 경 | Satin stainless','辛 신 | Mirror silver','壬 임 | Flowing water','癸 계 | Condensation']
order=[0,2,4,6,8,1,3,5,7,9]
def make(size,path,labels_on=True):
 margin=24 if size>200 else 10;head=86 if size>200 else 34;labelh=50 if size>200 else 30
 w=5*size+margin*2;h=2*(size+labelh)+head+margin
 sheet=Image.new('RGB',(w,h),'#eff2ef');d=ImageDraw.Draw(sheet)
 title=ImageFont.truetype(font,32 if size>200 else 16);small=ImageFont.truetype(font,19 if size>200 else 9)
 d.text((margin,12),'B형 · 10천간 재질 비교' if size>200 else 'B · 10 stems · 128px check',fill='#22383b',font=title)
 if size>200:d.text((margin,53),'Shared B body / pose / camera / lighting · Actual 3D renders · Columns are the five pairs',fill='#526266',font=small)
 for cell,idx in enumerate(order):
  row,col=divmod(cell,5);x=margin+col*size;y=head+row*(size+labelh)
  im=Image.open(P+'/'+names[idx]+'.png').convert('RGB').resize((size,size),Image.Resampling.LANCZOS);sheet.paste(im,(x,y));d.text((x+8,y+size+8),labels[idx],fill='#22383b',font=small)
 sheet.save(P+'/'+path)
make(384,'B_ten_stems_comparison.png');make(128,'B_ten_stems_128px.png')
audit=[]
for n in names:
 with open(P+'/'+n+'.glb','rb') as f:b=f.read();ln=struct.unpack_from('<I',b,12)[0];g=json.loads(b[20:20+ln])
 a={'name':n,'bytes':len(b),'meshes':len(g['meshes']),'triangles':sum(g['accessors'][p['indices']]['count']//3 for m in g['meshes'] for p in m['primitives']),'vertices':sum(g['accessors'][p['attributes']['POSITION']]['count'] for m in g['meshes'] for p in m['primitives']),'extensions':g.get('extensionsUsed',[]),'images':len(g.get('images',[]))}
 json.dump(a,open(P+'/'+n+'_audit.json','w'),indent=2);audit.append(a)
json.dump({'variants':audit,'total_triangles':sum(a['triangles'] for a in audit),'main_blend_count':10,'main_glb_count':10,'alternate_blend_count':1,'alternate_glb_count':1,'alternate_name':'11_Ji_Jade_OPTION','render_count':11,'layout':'Top row Jia Bing Wu Geng Ren; bottom row Yi Ding Ji Xin Gui','render':'Cycles CPU 2 threads, 512px 128 samples no denoiser; common B camera/pose, shared corrected studio: world0.45,key450-size3,rim350,facefill90-no-glossy,AgX Medium High Contrast','limitations':['Material studies are interpretive designs, not scientific saju assignments.','KHR_materials_transmission/ior/clearcoat require compatible viewer. Refraction/transparency/reflections can vary by viewer/environment.','Procedural appearance is explicit exported vertex colours or packed roughness image; unsupported nodes are not relied on.','Unrigged static comparison meshes; gesture prototypes are a separate deliverable.','Reconstructed B source matches original topology, not bit-identical original file.','No external assets, paid tools, generated imagery, Site edits or publishing.']},open(P+'/delivery_audit.json','w'),indent=2)

# Separate optional material-choice comparison.
trio=Image.new('RGB',(1536,600),'#eff2ef');d=ImageDraw.Draw(trio);f=ImageFont.truetype(font,24)
d.text((20,12),'戊 사암 / 己 유색 유리 / 己 옥 느낌 대안',font=f,fill='#22383b')
for i,(n,label) in enumerate([('05_Wu','戊 · rough sandstone'),('06_Ji','己 · coloured glass (current)'),('11_Ji_Jade_OPTION','己 · jade-like mineral (option)')]):
 im=Image.open(P+'/'+n+'.png').convert('RGB');trio.paste(im,(i*512,50));d.text((i*512+15,565),label,font=ImageFont.truetype(font,19),fill='#22383b')
trio.save(P+'/B_earth_glass_jade_options.png')
