import bpy,glob,os,json,math
from mathutils import Vector
P=os.path.dirname(os.path.abspath(__file__));out=[]
for f in sorted(glob.glob(P+'/*.glb')):
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=f)
 meshes=[o for o in bpy.context.scene.objects if o.type=='MESH'];pts=[o.matrix_world@Vector(c) for o in meshes for c in o.bound_box]
 lo=[min(p[i] for p in pts) for i in range(3)];hi=[max(p[i] for p in pts) for i in range(3)]
 out.append({'file':os.path.basename(f),'import_success':True,'mesh_objects':len(meshes),'bounds_min':lo,'bounds_max':hi,'finite_bounds':all(math.isfinite(v) for v in lo+hi),'color_attribute_meshes':sum(bool(o.data.color_attributes) for o in meshes)})
json.dump({'roundtrip':'Blender 4.3.2 glTF importer, all eleven files','variants':out,'all_imported_finite':all(x['finite_bounds'] for x in out)},open(P+'/glb_roundtrip_verification.json','w'),indent=2)
