import bpy
bpy.ops.wm.open_mainfile(filepath='/workspace/scratch/c9f1a9454187/b_ten_stems_v1/08_Xin.blend')
o=bpy.data.objects['Quiet face fill'];print('VISIBLE_GLOSSY',hasattr(o,'visible_glossy'));print('LIGHT_SPECULAR',hasattr(o.data,'specular_factor'))
