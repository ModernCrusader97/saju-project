import os,json,glob,struct,zipfile
P=os.path.dirname(os.path.abspath(__file__))
# Only deliver final named assets; exclude draft renders, backups and build logs.
files=[]
for n in ['01_Jia','02_Yi','03_Bing','04_Ding','05_Wu','06_Ji','07_Geng','08_Xin','09_Ren','10_Gui','11_Ji_Jade_OPTION']:
 for ext in ['blend','glb','png']:
  path=P+'/'+n+'.'+ext
  assert os.path.getsize(path)>1000,path
  files.append(path)
files += [P+'/'+n for n in ['B_ten_stems_comparison.png','B_ten_stems_128px.png','B_earth_glass_jade_options.png','README_ko.txt','delivery_audit.json','native_geometry_verification.json','glb_roundtrip_verification.json']]
with zipfile.ZipFile(P+'/B_ten_stems_v1_delivery.zip','w',zipfile.ZIP_DEFLATED,6) as z:
 for f in files:z.write(f,os.path.basename(f))
print('ZIP_BYTES',os.path.getsize(P+'/B_ten_stems_v1_delivery.zip'),'FILE_COUNT',len(files))
