import bpy,os,glob,json,hashlib,struct
P=os.path.dirname(os.path.abspath(__file__))
def sig():
 o=bpy.data.objects['B | continuous soft body and small hands'];b=bytearray()
 for v in o.data.vertices:b.extend(struct.pack('<3f',*v.co))
 for p in o.data.polygons:
  for i in p.vertices:b.extend(struct.pack('<I',i))
 return {'sha256':hashlib.sha256(b).hexdigest(),'vertices':len(o.data.vertices),'polygons':len(o.data.polygons),'matrix':[list(r) for r in o.matrix_world]}
bpy.ops.wm.open_mainfile(filepath=os.path.dirname(P)+'/elemental_form_comparison/B_final.blend');ref=sig();out=[]
for path in sorted(glob.glob(P+'/*.blend')):
 bpy.ops.wm.open_mainfile(filepath=path);bpy.data.objects['Quiet face fill'].visible_glossy=False;bpy.ops.wm.save_as_mainfile(filepath=path);s=sig();out.append({'file':os.path.basename(path),'body_geometry_identical':s==ref,'body':s,'camera':list(bpy.context.scene.camera.location),'ortho':bpy.context.scene.camera.data.ortho_scale})
json.dump({'reference':ref,'variants':out},open(P+'/native_geometry_verification.json','w'),indent=2);print('ALL_MATCH',all(x['body_geometry_identical'] for x in out))
