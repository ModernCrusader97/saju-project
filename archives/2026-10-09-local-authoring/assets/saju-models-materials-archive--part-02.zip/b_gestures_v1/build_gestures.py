import bpy, math, os, json, struct
from mathutils import Vector
P=os.path.dirname(os.path.abspath(__file__))
source=P+'/source/B_final.blend'
if not os.path.exists(source):source=os.path.dirname(P)+'/elemental_form_comparison/B_final.blend'
bpy.ops.wm.open_mainfile(filepath=source)
s=bpy.context.scene
# Convert face curves, preserving the recovered B art exactly at rest.
for o in list(s.objects):
 if o.type=='CURVE':
  bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.convert(target='MESH')
body=bpy.data.objects['B | continuous soft body and small hands']
face=[o for o in s.objects if o.name.startswith('B |') and o!=body and o.type=='MESH']
bpy.ops.object.armature_add();rig=bpy.context.object;rig.name='B_shared_gesture_rig';rig.show_in_front=True
bpy.ops.object.mode_set(mode='EDIT');eb=rig.data.edit_bones;eb.remove(eb[0])
def bone(n,h,t,parent=None):
 b=eb.new(n);b.head=h;b.tail=t
 if parent:b.parent=eb[parent]
 return b
bone('root',(0,0,0),(0,0,.2));bone('body',(0,0,.2),(0,0,1.25),'root');bone('head',(0,0,1.28),(0,0,2.15),'body')
bone('paddle_L',(-.36,0,.95),(-.53,0,.55),'body');bone('paddle_R',(.43,0,1.13),(.73,0,1.53),'body')
for side in [-1,1]:
 x=side*.235;bone('eye_'+str(side),(x,-.5,1.76),(x,-.5,1.87),'head');bone('brow_'+str(side),(x,-.5,1.96),(x,-.5,2.08),'head')
bone('smile',(0,-.47,1.565),(0,-.47,1.665),'head');bone('surprise_mouth',(0,-.47,1.565),(0,-.47,1.665),'head')
bpy.ops.object.mode_set(mode='OBJECT')
def bind(o,weights):
 o.parent=rig
 mod=o.modifiers.new('Shared spirit skin','ARMATURE');mod.object=rig
 groups={n:o.vertex_groups.new(name=n) for n in weights}
 for v in o.data.vertices:
  co=o.matrix_world@v.co
  vals={n:(w(co) if callable(w) else w) for n,w in weights.items()};total=sum(vals.values())
  for n,w in vals.items():
   if w>0:groups[n].add([v.index],w/total,'REPLACE')
def smooth(a,b,x):
 t=max(0,min(1,(x-a)/(b-a)));return t*t*(3-2*t)
def arm(c,side):return smooth(.38,.65,c.x*side)*(1-smooth(1.48,1.65,c.z))
def headw(c):return smooth(1.05,1.60,c.z)
bind(body,{'head':lambda c:headw(c)*(1-arm(c,1)-arm(c,-1)),'body':lambda c:(1-headw(c))*(1-arm(c,1)-arm(c,-1)),'paddle_L':lambda c:arm(c,-1),'paddle_R':lambda c:arm(c,1)})
for o in face:
 n='head'
 if 'almond gaze' in o.name or 'eye glint' in o.name:n='eye_'+o.name.split()[-1]
 elif 'expressive brow' in o.name:n='brow_'+o.name.split()[-1]
 elif 'quiet smile' in o.name:n='smile'
 bind(o,{n:1})
# Small graphic O mouth, controlled by a dedicated bone. Original smile remains at rest.
curve=bpy.data.curves.new('Surprise O graphic','CURVE');curve.dimensions='3D';curve.bevel_depth=.013;curve.bevel_resolution=2
sp=curve.splines.new('POLY');sp.points.add(31)
for i,p in enumerate(sp.points):
 a=2*math.pi*i/32;p.co=(.044*math.cos(a),-.48,1.565+.059*math.sin(a),1)
sp.use_cyclic_u=True
o=bpy.data.objects.new('B | surprise O mouth',curve);s.collection.objects.link(o);o.data.materials.append(bpy.data.materials['Deep teal expression']);bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.convert(target='MESH');bind(o,{'surprise_mouth':1})
# Socket retained and follows the head. Matrix-preserving bone attachment.
socket=bpy.data.objects.get('B | accessory socket');mw=socket.matrix_world.copy();socket.parent=rig;socket.parent_type='BONE';socket.parent_bone='head';socket.matrix_world=mw
for p in rig.pose.bones:p.rotation_mode='XYZ'
def reset():
 for p in rig.pose.bones:p.location=(0,0,0);p.rotation_euler=(0,0,0);p.scale=(1,1,1)
 rig.pose.bones['surprise_mouth'].scale=(.001,.001,.001)
def key(frame,**kw):
 reset()
 for path,val in kw.items():
  n,prop=path.split('__');setattr(rig.pose.bones[n],prop,val)
 for p in rig.pose.bones:
  for prop in ['location','rotation_euler','scale']:p.keyframe_insert(data_path=prop,frame=frame,group=p.name)
def r(deg):return math.radians(deg)
clips=[]
def start(name):
 rig.animation_data_create();rig.animation_data.action=bpy.data.actions.new(name);return rig.animation_data.action
act=start('wave_hello')
key(1);key(5,body__scale=(1.025,.97,1.025),head__rotation_euler=(0,r(-4),0),paddle_R__rotation_euler=(0,0,r(-9)))
for f,a,h in [(10,-34,-5),(15,18,3),(20,-28,-3),(25,14,2),(30,-12,-1)]:
 key(f,paddle_R__rotation_euler=(0,r(a*.2),r(a)),head__rotation_euler=(0,r(h),0),root__location=(0,.035,0),**{'eye_-1__scale':(1,.88,1),'eye_1__scale':(1,.88,1)})
key(36);clips.append(act)
act=start('curious_lean');key(1);key(6,head__rotation_euler=(0,r(-4),0),body__rotation_euler=(0,0,r(-2)))
for f,amount in [(13,1),(23,1),(29,.35)]:
 key(f,body__rotation_euler=(0,0,r(8*amount)),head__rotation_euler=(r(4*amount),0,r(12*amount)),paddle_L__rotation_euler=(0,0,r(-10*amount)),paddle_R__rotation_euler=(0,0,r(8*amount)),**{'brow_1__location':(0,.055*amount,0),'eye_-1__scale':(1,.86,1),'eye_1__scale':(1,1.12,1)})
key(36);clips.append(act)
act=start('startled_recovery');key(1);key(6,body__scale=(1.055,.92,1.055),head__rotation_euler=(r(3),0,0))
key(10,body__scale=(.92,1.13,.92),root__location=(0,.13,0),paddle_L__rotation_euler=(0,0,r(-30)),paddle_R__rotation_euler=(0,0,r(-36)),smile__scale=(.001,.001,.001),surprise_mouth__scale=(1,1,1),**{'eye_-1__scale':(.9,1.8,1),'eye_1__scale':(.9,1.8,1),'brow_-1__location':(0,.09,0),'brow_1__location':(0,.09,0)})
key(16,body__scale=(1.15,.78,1.15),paddle_L__rotation_euler=(0,0,r(-13)),paddle_R__rotation_euler=(0,0,r(15)),smile__scale=(.001,.001,.001),surprise_mouth__scale=(.8,.8,.8),**{'eye_-1__scale':(1.05,.68,1),'eye_1__scale':(1.05,.68,1)})
key(22,body__scale=(.97,1.045,.97),head__rotation_euler=(r(-3),0,0));key(29,body__scale=(1.015,.98,1.015));key(36);clips.append(act)
for act in clips:
 for fc in act.fcurves:
  for kp in fc.keyframe_points:kp.interpolation='BEZIER';kp.handle_left_type='AUTO_CLAMPED';kp.handle_right_type='AUTO_CLAMPED'
 act.use_fake_user=True
rig.animation_data.action=clips[0];s.frame_start=1;s.frame_end=36;s.render.fps=12;s.frame_set(1)
# Export one portable skin and three named actions; no studio geometry.
bpy.ops.object.select_all(action='DESELECT')
for o in s.objects:
 if o==rig or o.parent==rig:o.select_set(True)
bpy.context.view_layer.objects.active=rig
bpy.ops.export_scene.gltf(filepath=P+'/B_gesture_rig.glb',export_format='GLB',use_selection=True,export_animations=True,export_animation_mode='ACTIONS',export_force_sampling=True,export_apply=False)
s.render.threads_mode='FIXED';s.render.threads=2;s.cycles.samples=32;s.cycles.use_denoising=False;s.cycles.max_bounces=6;s.cycles.transmission_bounces=4;s.render.resolution_x=320;s.render.resolution_y=320;s.render.resolution_percentage=100
s.camera.data.ortho_scale=3.25
bpy.ops.wm.save_as_mainfile(filepath=P+'/B_gesture_rig.blend')
raw=open(P+'/B_gesture_rig.glb','rb').read();j=json.loads(raw[20:20+struct.unpack_from('<I',raw,12)[0]])
audit={'source':'Recovered B_final.blend','animations':[a['name'] for a in j.get('animations',[])],'skins':len(j.get('skins',[])),'joints':[j['nodes'][n]['name'] for n in j['skins'][0]['joints']],'bytes':len(raw),'frames':36,'fps':12,'renderer':'Cycles CPU 2 threads','browser_validated':False}
json.dump(audit,open(P+'/audit.json','w'),indent=2);print('GESTURE_AUDIT',audit,flush=True)
