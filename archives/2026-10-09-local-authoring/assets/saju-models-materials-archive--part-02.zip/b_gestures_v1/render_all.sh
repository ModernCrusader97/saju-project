#!/bin/bash
set -e
cd /workspace/scratch/c9f1a9454187
for frame in 1 10 16 22 28 36 4 7 13 19 25 31 34; do
 for clip in wave_hello curious_lean startled_recovery; do
  [ -f b_gestures_v1/frames/$clip/$(printf '%03d' $frame).png ] || flock /tmp/b_form_render.lock blender -b -t 2 --python b_gestures_v1/render_proof.py -- $clip $frame >> b_gestures_v1/proof_render.log 2>&1
 done
done
