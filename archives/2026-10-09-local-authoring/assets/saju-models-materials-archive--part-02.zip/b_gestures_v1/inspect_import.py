import bpy
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath='/workspace/scratch/c9f1a9454187/b_gestures_v1/B_gesture_rig.glb')
s=bpy.context.scene;s.frame_set(1);dg=bpy.context.evaluated_depsgraph_get()
for o in s.objects:
 if o.type=='MESH' and o.name!='Plane':
  ev=o.evaluated_get(dg);m=ev.to_mesh();vs=[ev.matrix_world@v.co for v in m.vertices];print(o.name, 'loc',list(o.location),'bounds', [(min(v[i] for v in vs),max(v[i] for v in vs)) for i in range(3)]);ev.to_mesh_clear()
