# B elemental-spirit gesture prototype

A bounded animation prototype built from the recovered B_final.blend. Original continuous soft upright blob, short paddle hands and graphic face are retained. This is not a humanoid or fluid-simulation rig.

## Deliverables
- B_gesture_rig.blend: editable skeleton, weights, 3 actions, original studio.
- B_gesture_rig.glb: portable single skin, 11 joints, 3 named animation clips.
- Gesture proof imagery: rendered directly from these actions in Blender, not a browser screenshot.
- audit.json / roundtrip_validation.json: actual export/import and evaluated-frame checks.

## Motion
All actions cover frames 1–36 at 12 fps (approximately 3 seconds), return to the same neutral pose, and can be blended by the engine.
- wave_hello: slight anticipation, repeated short-paddle wristless wave, diminishing follow-through, friendly eye compression.
- curious_lean: counter-motion, body and head tilt with asymmetrical brows, held curiosity, settle.
- startled_recovery: anticipation, upward recoil with widened eyes and O mouth, squash on landing, elastic recovery and settle.

## Common controls
root: translation; body: whole-form lean/squash; head: gaze and crown; paddle_L / paddle_R: local paddle gesture. eye_-1 / eye_1 and brow_-1 / brow_1 are graphic expression controls; smile and surprise_mouth select the graphic mouth. Blender bone-local Y is the bone's length/vertical axis. Nonuniform body Y scaling is inherited by the head and facial components.

## Elemental variant integration
B body vertices retain recovered source order/topology. Copy the body vertex groups by vertex index to the five-element variant core when topology has not changed; preserve its vertex colors and materials. Face is rigidly weighted to the corresponding facial bones. New crowns, branch leaves, flames or the original accessory socket can be bone-parented to head with world matrix preserved. Surface-spanning vine, bark, or seam geometry must receive the same body deformation, not a rigid head attachment. Convert curves to mesh first; derive normalized weights from world coordinates using the weight functions in build_gestures.py, or transfer from the nearest body surface. Tiny accent beads should receive nearest-surface weights when they cross moving body regions. Yi's shifted face position should be preserved while binding.

## Reproduction
Run Blender 4.3.2 with build_gestures.py. CPU rendering must use /tmp/b_form_render.lock and 2 threads. render_proof.py takes a clip name and frame list after --. This Blender build does not include OpenImageDenoise, so denoising is disabled.

## Scope and limits
The original surface is an expressive stylized prototype, not production retopology. No fingers, detailed human anatomy, fluid simulation, gameplay controller or engine/browser integration was added. GLB was re-imported and evaluated in Blender; this is not browser validation. No element/stem variant was overwritten or published.
