from PIL import Image,ImageDraw,ImageFont
import os,subprocess,json
P=os.path.dirname(os.path.abspath(__file__))
clips=['wave_hello','curious_lean','startled_recovery'];labels=['WAVE HELLO','CURIOUS LEAN','STARTLED + RECOVERY']
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';f=ImageFont.truetype(font,16);small=ImageFont.truetype(font,13)
frames=[1,10,16,22,28,36]
sheet=Image.new('RGB',(6*260,3*304+86),'#edf2f3');d=ImageDraw.Draw(sheet);d.text((18,15),'B SPIRIT / SHARED GESTURE PROTOTYPE',font=ImageFont.truetype(font,23),fill='#193c46');d.text((18,45),'Actual skinned 3D poses. Three reusable clips; same continuous B body.',font=small,fill='#45606a')
for row,(clip,label) in enumerate(zip(clips,labels)):
 d.text((14,70+row*304),label,font=f,fill='#193c46')
 for col,n in enumerate(frames):
  im=Image.open(f'{P}/frames/{clip}/{n:03d}.png').convert('RGB').resize((256,256));x=col*260;y=95+row*304;sheet.paste(im,(x,y));d.text((x+8,y+259),f'frame {n:02d}',font=small,fill='#45606a')
sheet.save(P+'/B_gesture_contact_sheet.jpg',quality=94)
for clip in clips:
 files=sorted(os.listdir(P+'/frames/'+clip));files=[p for p in files if p.endswith('.png') and p!='018.png'];ims=[Image.open(P+'/frames/'+clip+'/'+p).convert('RGB') for p in files];nums=[int(p[:-4]) for p in files];durations=[round((nums[i+1]-nums[i])/12*1000) for i in range(len(nums)-1)]+[250]
 ims[0].save(P+'/'+clip+'.gif',save_all=True,append_images=ims[1:],duration=durations,loop=0)
 concat=P+'/'+clip+'_concat.txt';open(concat,'w').write(''.join("file 'frames/"+clip+'/'+p+"'\nduration "+str(d/1000)+'\n' for p,d in zip(files,durations))+"file 'frames/"+clip+'/'+files[-1]+"'\n")
 subprocess.run(['ffmpeg','-y','-threads','2','-f','concat','-safe','0','-i',concat,'-vf','fps=12','-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',P+'/'+clip+'.mp4'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
print('PROOF_ASSEMBLED')
filters=[]
for i,label in enumerate(['wave','curious','startled']):filters.append(f"[{i}:v]pad=iw:ih+38:0:38:color=0xedf2f3,drawtext=fontfile={font}:text='{label}':x=10:y=10:fontsize=15:fontcolor=0x193c46[v{i}]")
filters.append('[v0][v1][v2]hstack=inputs=3[out]')
args=['ffmpeg','-y','-threads','2']
for clip in clips:args+=['-i',P+'/'+clip+'.mp4']
args+=['-filter_complex',';'.join(filters),'-map','[out]','-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',P+'/B_gestures_preview.mp4']
subprocess.run(args,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
