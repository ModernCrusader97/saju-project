import bpy,os,json,math
P=os.path.dirname(os.path.abspath(__file__));bpy.ops.wm.read_factory_settings(use_empty=True);bpy.context.scene.render.fps=12;bpy.ops.import_scene.gltf(filepath=P+'/B_gesture_rig.glb')
rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');s=bpy.context.scene;s.render.fps=12;out=[]
for track in rig.animation_data.nla_tracks:track.mute=True
for a in bpy.data.actions:
 rig.animation_data.action=a
 bounds=[]
 for frame in [1,6,10,16,22,29,36]:
  s.frame_set(frame);dg=bpy.context.evaluated_depsgraph_get();coords=[]
  for o in s.objects:
   if o.type=='MESH' and o.name.startswith('B |'):
    ev=o.evaluated_get(dg);m=ev.to_mesh();coords.extend([ev.matrix_world@v.co for v in m.vertices]);ev.to_mesh_clear()
  assert all(math.isfinite(c) for v in coords for c in v)
  bounds.append({'frame':frame,'min':[min(v[i] for v in coords) for i in range(3)],'max':[max(v[i] for v in coords) for i in range(3)]})
 out.append({'action':a.name,'bounds':bounds})
json.dump({'roundtrip':'Blender 4.3.2 GLB import and evaluated 7 frames per action','actions':out,'browser_validated':False},open(P+'/roundtrip_validation.json','w'),indent=2)
print('ROUNDTRIP_OK',len(out))
