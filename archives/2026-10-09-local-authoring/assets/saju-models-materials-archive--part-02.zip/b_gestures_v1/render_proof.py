import bpy,os,sys
P=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=P+'/B_gesture_rig.blend');s=bpy.context.scene;rig=bpy.data.objects['B_shared_gesture_rig']
s.cycles.use_denoising=False;s.cycles.samples=32
clip=sys.argv[sys.argv.index('--')+1];rig.animation_data.action=bpy.data.actions[clip]
frames=[int(x) for x in sys.argv[sys.argv.index('--')+2:]] or list(range(1,37))
os.makedirs(P+'/frames/'+clip,exist_ok=True)
for f in frames:
 s.frame_set(f);s.render.filepath=P+'/frames/'+clip+'/'+str(f).zfill(3)+'.png'
 if os.path.exists(s.render.filepath):continue
 bpy.ops.render.render(write_still=True)
