import bpy,os
P=os.path.dirname(os.path.abspath(__file__));bpy.ops.wm.open_mainfile(filepath=P+'/B_gesture_rig.blend');s=bpy.context.scene;s.cycles.use_denoising=False;s.cycles.samples=32;bpy.ops.wm.save_as_mainfile(filepath=P+'/B_gesture_delivery.blend');os.replace(P+'/B_gesture_delivery.blend',P+'/B_gesture_rig.blend')
