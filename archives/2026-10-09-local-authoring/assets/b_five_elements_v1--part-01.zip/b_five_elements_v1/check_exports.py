import bpy, json, os
from mathutils import Vector
P=os.path.dirname(os.path.abspath(__file__));out=[]
for k in ['wood','fire','earth','metal','water']:
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=P+'/'+k+'.glb')
 meshes=[o for o in bpy.context.scene.objects if o.type=='MESH'];points=[o.matrix_world@Vector(c) for o in meshes for c in o.bound_box]
 out.append({'element':k,'reimport_ok':True,'meshes':len(meshes),'bounds_min':[min(p[i] for p in points) for i in range(3)],'bounds_max':[max(p[i] for p in points) for i in range(3)],'materials':len(bpy.data.materials),'missing_images':[im.name for im in bpy.data.images if not im.has_data]})
json.dump(out,open(P+'/roundtrip.json','w'),indent=2)
