import bpy, math, os, json, struct
from mathutils import Vector
P=os.path.dirname(os.path.abspath(__file__)); SRC='/workspace/scratch/c9f1a9454187/elemental_form_comparison/B_final.blend'
PALETTES={'wood':(.23,.46,.055),'fire':(1,.32,.065),'earth':(.43,.22,.09),'metal':(.72,.80,.84),'water':(.06,.48,.67)}
def material(n,c,r=.3,metal=0,trans=0):
 m=bpy.data.materials.new(n);m.use_nodes=True;m.diffuse_color=(*c,1);p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=r;p.inputs['Metallic'].default_value=metal;p.inputs['Transmission Weight'].default_value=trans;p.inputs['IOR'].default_value=1.333;p.inputs['Coat Weight'].default_value=.18;return m
def uv(n,loc,scale,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=16,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 for f in o.data.polygons:f.use_smooth=True
 return o
def line(n,points,r,m):
 c=bpy.data.curves.new(n,'CURVE');c.dimensions='3D';c.bevel_depth=r;c.bevel_resolution=3;s=c.splines.new('BEZIER');s.bezier_points.add(len(points)-1)
 for b,p in zip(s.bezier_points,points):b.co=p;b.handle_left_type='AUTO';b.handle_right_type='AUTO'
 o=bpy.data.objects.new(n,c);bpy.context.collection.objects.link(o);o.data.materials.append(m);return o
AUD=[]
for kind in PALETTES:
 if os.environ.get('ELEMENT_ONLY') and kind!=os.environ['ELEMENT_ONLY']:continue
 bpy.ops.wm.open_mainfile(filepath=SRC)
 s=bpy.context.scene;s.cycles.samples=128;s.cycles.use_denoising=False;s.render.resolution_x=s.render.resolution_y=512;s.render.threads=2;s.world.node_tree.nodes.get('Background').inputs[1].default_value=.45;s.view_settings.look='AgX - Medium High Contrast';bpy.data.lights['Broad soft key'].size=3;bpy.data.lights['Pale rim'].energy=350;bpy.data.objects['Quiet face fill'].visible_glossy=False
 body=bpy.data.objects['B | continuous soft body and small hands'];body.name='B '+kind+' | soft continuous body and paddle hands'
 m=material(kind+' body',PALETTES[kind],{'wood':.55,'fire':.31,'earth':.90,'metal':.25,'water':.08}[kind],.78 if kind=='metal' else 0,.68 if kind=='water' else .0)
 body.data.materials.clear();body.data.materials.append(m)
 if kind in {'wood','earth'}:m.node_tree.nodes.get('Principled BSDF').inputs['Coat Weight'].default_value=0
 # Coordinate edits retain the original B face area and paddle-hand anatomy.
 for v in body.data.vertices:
  p=body.matrix_world@v.co;x,y,z=p
  if kind=='wood':
   if z<1.30:x*=1+.07*max(0,1-abs(z-.7)/.7)
  elif kind=='fire':
   t=max(0,min(1,(z-1.97)/.34));z+=t*t*(.29*math.exp(-((x-.15)/.17)**2)+.20*math.exp(-((x+.34)/.10)**2));x+=.065*t*t
   if z<1.1:x*=.97
  elif kind=='earth':
   if z<1.25:x*=1+.16*max(0,1-z/1.25)
   if z>2.10:z=2.10+(z-2.10)*.70
  elif kind=='metal':
   if z>2.03:
    t=max(0,min(1,(z-2.03)/.32));z=2.03+(z-2.03)*.72;x*=1+.16*t
   if z<1.28:x*=1.03
  elif kind=='water':
   t=max(0,min(1,(z-2.03)/.33));z+=.14*t*t;x-=.14*t*t
  v.co=body.matrix_world.inverted()@Vector((x,y,z))
 if kind=='wood':
  leaf=material('wood | fresh leaf',(.19,.40,.065),.38)
  line('wood | little living stem',[(0,.04,2.32),(.02,.045,2.49)],.024,leaf)
  a=uv('wood | left seed leaf',(-.11,.04,2.48),(.17,.060,.07),leaf);a.rotation_euler.y=.45
  a=uv('wood | right seed leaf',(.13,.04,2.53),(.16,.055,.065),leaf);a.rotation_euler.y=-.42
 if kind=='fire':
  # Broad warm gradient, encoded as vertex colors for portable glTF.
  ca=body.data.color_attributes.new(name='ElementGradient',type='FLOAT_COLOR',domain='POINT')
  low=(.80,.018,.003);high=(1,.40,.022)
  for i,v in enumerate(body.data.vertices):
   z=(body.matrix_world@v.co).z;t=max(0,min(1,(z-.15)/2.3));ca.data[i].color=(*(low[k]*(1-t)+high[k]*t for k in range(3)),1)
  nt=m.node_tree;p=nt.nodes.get('Principled BSDF');vc=nt.nodes.new('ShaderNodeVertexColor');vc.layer_name=ca.name;nt.links.new(vc.outputs['Color'],p.inputs['Base Color']);nt.links.new(vc.outputs['Color'],p.inputs['Emission Color']);p.inputs['Emission Strength'].default_value=.16
 if kind=='earth':
  from mathutils import noise
  ca=body.data.color_attributes.new(name='SandstoneStrata',type='FLOAT_COLOR',domain='POINT')
  for i,v in enumerate(body.data.vertices):
   w=body.matrix_world@v.co;grain=noise.noise_vector(w*65).x;strata=math.sin(w.z*36+math.sin(w.x*5)*.35)
   q=1+.06*grain+.035*strata;ca.data[i].color=(.43*q,.22*q,.09*q,1)
   v.co+=v.normal*(.0025*grain)
  nt=m.node_tree;p=nt.nodes.get('Principled BSDF');vc=nt.nodes.new('ShaderNodeVertexColor');vc.layer_name=ca.name;nt.links.new(vc.outputs['Color'],p.inputs['Base Color'])
 # Apply element material to core only; graphic eyes/brows/smile stay exact.
 bpy.context.view_layer.update();bpy.ops.object.select_all(action='DESELECT')
 for o in s.objects:
  if o.type in {'MESH','CURVE','EMPTY'} and o.name!='Plane':o.hide_set(False);o.select_set(True)
 out=P+'/'+kind;bpy.ops.export_scene.gltf(filepath=out+'.glb',export_format='GLB',use_selection=True,export_apply=True)
 s.render.filepath=out+'.png';bpy.ops.wm.save_as_mainfile(filepath=out+'.blend')
 data=open(out+'.glb','rb').read();n=struct.unpack_from('<I',data,12)[0];j=json.loads(data[20:20+n]);tris=sum(j['accessors'][p['indices']]['count']//3 for mm in j['meshes'] for p in mm['primitives']);verts=sum(j['accessors'][p['attributes']['POSITION']]['count'] for mm in j['meshes'] for p in mm['primitives'])
 AUD.append({'element':kind,'triangles':tris,'vertices':verts,'meshes':len(j['meshes']),'bytes':len(data),'glb_version':struct.unpack_from('<I',data,4)[0],'external_uris':[x['uri'] for x in j.get('buffers',[]) if 'uri' in x],'camera_ortho':s.camera.data.ortho_scale,'resolution':512,'samples':128,'rendered':False})
 bpy.ops.render.render(write_still=True);AUD[-1]['rendered']=True
 with open(P+'/'+kind+'_audit.json','w') as f:json.dump(AUD,f,indent=2)
 print('COMPLETED',kind,flush=True)
