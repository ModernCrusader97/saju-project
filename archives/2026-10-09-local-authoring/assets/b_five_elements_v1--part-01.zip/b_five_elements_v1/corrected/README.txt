B FORM / FIVE ELEMENTS — bounded corrected design comparison

Files:
wood, fire, earth, metal, water: each .blend, .glb, and 512px PNG.
five_up.png: matched 5-up proof.
five_up_128.png: true 128px-per-character readability check.
audit.json and roundtrip.json: exported geometry and GLB reimport checks.

The five objects retain B's soft upright continuous body, joined paddle hands,
graphic eyebrows, oval eyes with glints, and quiet smile. There are no fingers,
full human legs, human skin details, or anatomical joints. The Earth version is
warm dry sandstone-like clay, not porcelain. Wood has one sprout, Fire has an
asymmetric two-tip warm gradient crown, Metal has a flatter silver dome, and
Water has a curved pale-aqua liquid peak. These are original design studies,
not final art approval or claims of traditional symbolism accuracy.

All previews use the recovered B source camera/pose. The bounded correction
uses a shared neutral contrast studio coordinated with the ten-stem set:
world strength .45, key450/size3, rim350, fill90, AgX Medium High Contrast.
The fill is hidden in glossy rays to avoid a bright silver-face reflection.
Blender 4.3.2 / CPU / 2 threads / 128 samples / 512 square; no denoiser.

Source B was reconstructed by its original author from retained generation
code; topology matches the original recorded counts, not binary identity.
The source and all first-proof files were preserved. No Site changes, asset
publishing, saju calculations, external assets, or image generation were used.

These element files are static design assets, not rigged animation deliveries.
The separate gesture prototype can reuse the same core topology and original
coordinates. Wood sprout objects attach to its head bone. No animation readiness
claim beyond retained deformation-compatible core topology is made here.
