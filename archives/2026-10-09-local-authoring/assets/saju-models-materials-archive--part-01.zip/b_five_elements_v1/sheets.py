from PIL import Image,ImageDraw,ImageFont
import os
P=os.path.dirname(os.path.abspath(__file__))
ks=['wood','fire','earth','metal','water'];labels=['목 · Wood','화 · Fire','토 · Earth','금 · Metal','수 · Water'];subs=['자라나는 새싹','연속된 따뜻한 불빛','넓고 안정적인 점토','둥근 은빛 금속','휘어진 맑은 물결']
font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
for size in [320,128]:
 margin=24 if size==320 else 12;head=70 if size==320 else 46;foot=74 if size==320 else 30
 im=Image.new('RGB',(size*5+margin*2,head+size+foot),(245,246,244));d=ImageDraw.Draw(im);f=ImageFont.truetype(font,22 if size==320 else 16);sm=ImageFont.truetype(font,15 if size==320 else 11)
 d.text((margin,14), 'B형 · 오행 형태 / 재질 비교' if size==320 else 'B형 · 오행 128px 확인',font=f,fill=(30,55,61))
 for i,k in enumerate(ks):
  a=Image.open(P+'/'+k+'.png').convert('RGB').resize((size,size),Image.Resampling.LANCZOS);x=margin+i*size;im.paste(a,(x,head));d.text((x+size/2,head+size+6),labels[i],font=f,anchor='mt',fill=(30,55,61))
  if size==320:d.text((x+size/2,head+size+39),subs[i],font=sm,anchor='mt',fill=(76,94,96))
 im.save(P+('/five_up.png' if size==320 else '/five_up_128.png'))
