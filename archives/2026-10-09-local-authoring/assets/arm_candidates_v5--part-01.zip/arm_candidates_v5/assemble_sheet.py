from PIL import Image,ImageDraw,ImageFont
import os
P=os.path.dirname(os.path.abspath(__file__));reg='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';bold='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc';font=lambda n,b=False:ImageFont.truetype(bold if b else reg,n,index=1)
W=1800;H=970;can=Image.new('RGB',(W,H),'#edf2f3');d=ImageDraw.Draw(can);ink='#173d47';muted='#4d6971'
d.text((22,12),'B 팔 후보 5가지',font=font(34,True),fill=ink);d.text((22,62),'같은 몸·얼굴·발·재질·카메라  ·  모두 몸에 붙는 형태  ·  최종안 선택 전 비교용',font=font(20),fill=muted)
labels=['1  두툼한 캡슐','2  유연한 소프트 튜브','3  짧고 넓은 지느러미','4  물방울 테이퍼','5  도톰한 둥근 손끝']
notes=['짧고 포근한 덩어리','관절 없이 흐르는 곡선','납작하고 넓은 패들','넓은 어깨에서 둥근 끝으로','잘록한 손목 없이 이어짐']
for i,(label,note) in enumerate(zip(labels,notes)):
 x=i*360+14;d.text((x,104),label,font=font(23,True),fill=ink);d.text((x,139),note,font=font(18),fill=muted)
d.text((20,174),'기본 자세',font=font(19,True),fill=ink)
for i in range(1,6):can.paste(Image.open(P+f'/candidate_{i}_neutral.png').convert('RGB').resize((352,352)),((i-1)*360+4,205))
d.text((20,566),'팔을 든 자세',font=font(19,True),fill=ink)
for i in range(1,6):can.paste(Image.open(P+f'/candidate_{i}_raised.png').convert('RGB').resize((352,352)),((i-1)*360+4,597))
can.save(P+'/B_arm_candidates_v5_sheet.jpg',quality=96)
print('SHEET_READY',can.size)
