import bpy,math,os,json,sys
from mathutils import Vector
P=os.path.dirname(os.path.abspath(__file__))
source=P+'/source/B_clean_core_source.blend'
if not os.path.exists(source):source=os.path.dirname(P)+'/b_gestures_v3/B_separate_arms_v3.blend'
R=(.34,-.08,1.17)
styles={
 1:{'name':'Thick capsule','neutral':[R,(.59,-.10,1.10),(.71,-.12,.91),(.73,-.14,.72)],'raised':[R,(.59,-.11,1.13),(.95,-.22,1.29),(.92,-.29,1.57)]},
 2:{'name':'Flexible soft tube','neutral':[R,(.75,-.10,1.18),(.53,-.14,.69),(.87,-.18,.72)],'raised':[R,(.70,-.10,1.04),(1.04,-.22,1.40),(.85,-.30,1.64)]},
 3:{'name':'Seal flipper','neutral':[R,(.58,-.10,1.06),(.64,-.12,.91),(.72,-.15,.80)],'raised':[R,(.62,-.12,1.13),(.96,-.24,1.33),(.98,-.30,1.55)]},
 4:{'name':'Tapered droplet','neutral':[R,(.57,-.11,1.08),(.70,-.13,.86),(.80,-.15,.70)],'raised':[R,(.62,-.12,1.14),(.91,-.23,1.31),(.96,-.29,1.56)]},
 5:{'name':'Soft mitten end','neutral':[R,(.58,-.11,1.08),(.68,-.15,.92),(.75,-.19,.71)],'raised':[R,(.59,-.12,1.12),(.94,-.22,1.30),(.94,-.29,1.60)]}
}
def ease(t):return t*t*(3-2*t)
def cap(t):
 if t<.16:return math.sqrt(max(0,1-((.16-t)/.16)**2))
 if t>.76:return math.sqrt(max(0,1-((t-.76)/.24)**2))
 return 1
def radius(style,t):
 if style==1:return .157*cap(t),.145*cap(t)
 if style==2:return .117*cap(t),.110*cap(t)
 if style==3:
  w=(.105+.105*math.sin(math.pi*t*.95)**1.2)*cap(t);return w,.073*cap(t)
 if style==4:
  c=math.sqrt(max(0,1-((t-.84)/.16)**2)) if t>.84 else cap(min(t,.76))
  w=(.195*(1-t)+.082*t)*c;return w,(.165*(1-t)+.075*t)*c
 if style==5:
  w=(.122+.068*ease(min(1,t/.73)))*cap(t);return w,(.12+.033*ease(min(1,t/.73)))*cap(t)
def loft(style,pose,side):
 ps=[Vector((x*side,y,z)) for x,y,z in styles[style][pose]]
 def point(t):return (1-t)**3*ps[0]+3*(1-t)**2*t*ps[1]+3*(1-t)*t*t*ps[2]+t**3*ps[3]
 def tangent(t):return (3*(1-t)**2*(ps[1]-ps[0])+6*(1-t)*t*(ps[2]-ps[1])+3*t*t*(ps[3]-ps[2])).normalized()
 verts=[point(0)];rings=48;sides=32
 for i in range(1,rings):
  t=i/rings;c=point(t);tan=tangent(t);wide=Vector((tan.z,0,-tan.x)).normalized();depth=tan.cross(wide).normalized();w,d=radius(style,t)
  for j in range(sides):
   a=2*math.pi*j/sides;verts.append(c+wide*(w*math.cos(a))+depth*(d*math.sin(a)))
 end=len(verts);verts.append(point(1));faces=[]
 for j in range(sides):faces.append((0,1+(j+1)%sides,1+j))
 for i in range(rings-2):
  a=1+i*sides;b=a+sides
  for j in range(sides):faces.append((a+j,a+(j+1)%sides,b+(j+1)%sides,b+j))
 base=1+(rings-2)*sides
 for j in range(sides):faces.append((base+j,base+(j+1)%sides,end))
 return verts,faces
for style in ([int(sys.argv[sys.argv.index('--')+1])] if '--' in sys.argv else range(1,6)):
 bpy.ops.wm.open_mainfile(filepath=source);s=bpy.context.scene;rig=bpy.data.objects['B_shared_gesture_rig'];body=bpy.data.objects['B | continuous core without fused paddles'];rig.animation_data_clear()
 for a in list(bpy.data.actions):bpy.data.actions.remove(a)
 for o in list(s.objects):
  if o.name.startswith('B | separate soft arm'):bpy.data.objects.remove(o,do_unlink=True)
 for pb in rig.pose.bones:pb.location=(0,0,0);pb.rotation_euler=(0,0,0);pb.scale=(1,1,1)
 rig.pose.bones['surprise_mouth'].scale=(.001,.001,.001)
 arms=[]
 for side in [-1,1]:
  vs,fs=loft(style,'neutral',side);mesh=bpy.data.meshes.new('Continuous soft arm surface');mesh.from_pydata(vs,[],fs);mesh.update();o=bpy.data.objects.new('Candidate '+str(style)+' attached arm '+('L' if side<0 else 'R'),mesh);s.collection.objects.link(o);o.data.materials.append(body.data.materials[0]);o.parent=rig
  for p in o.data.polygons:p.use_smooth=True
  o.shape_key_add(name='Neutral')
  key=o.shape_key_add(name='Raised pose study');raised,_=loft(style,'raised',side)
  for v,co in zip(key.data,raised if side==1 else vs):v.co=co
  key.value=0;key.keyframe_insert(data_path='value',frame=1);key.value=1;key.keyframe_insert(data_path='value',frame=2);key.value=0;arms.append(o)
 s.frame_start=1;s.frame_end=2;s.render.fps=12;s.frame_set(1);s.cycles.samples=48;s.cycles.use_denoising=False;s.render.threads_mode='FIXED';s.render.threads=2;s.render.resolution_x=400;s.render.resolution_y=400
 s['candidate_only']=True;s['arm_concept']=styles[style]['name'];s['pose_note']='Two endpoint pose morphs for visual comparison, not a finished production arm rig.'
 path=P+'/candidate_'+str(style);bpy.ops.wm.save_as_mainfile(filepath=path+'.blend')
 bpy.ops.object.select_all(action='DESELECT')
 for o in s.objects:
  if o==rig or o.parent==rig:o.select_set(True)
 bpy.context.view_layer.objects.active=rig;bpy.ops.export_scene.gltf(filepath=path+'.glb',export_format='GLB',use_selection=True,export_animations=False,export_morph=True,export_apply=False)
 print('CANDIDATE_BUILT',style,styles[style]['name'],flush=True)
json.dump({'candidates':styles,'same_body_source':source,'scope':'5 neutral + raised endpoint studies; no design selected; no production gesture clips','browser_validated':False},open(P+'/candidate_manifest.json','w'),indent=2)
