# B arm candidates — exploratory comparison only

Five actual 3D arm-form studies on the same B body, face, feet, camera, lighting and aqua material. No candidate has been selected for production, and the ten-character family has not been rebuilt.

## Contact sheet
B_arm_candidates_v5_sheet.jpg contains five columns and two rows: neutral and raised-arm poses. Korean labels are embedded in the image.

1. Thick capsule — cozy, compact volume; subtle bends stay hidden inside a soft mass.
2. Flexible soft tube — flowing curved gestures with no elbow landmark; less distinct hand identity.
3. Short broad seal-flipper paddle — the clearest nonhuman silhouette, with a broad readable gesture; less suited to fine hand-like actions.
4. Tapered droplet — a broad shoulder flowing into a narrower rounded tip; light, elemental silhouette with less hand volume.
5. Modestly larger rounded mitten end — stronger hand presence for greeting or gathering gestures; no fingers or pinched wrist, though it reads more hand-like than the others.

## Actual sources
candidate_1.blend through candidate_5.blend contain the editable models. Frame 1 shows the neutral pose; frame 2 shows the raised pose. The arm meshes have two endpoint shape-key states. These are pose studies, not completed joint rigs or validated animation interpolation.

Matching candidate_1.glb through candidate_5.glb contain the neutral model plus arm morph targets, without exported animation clips. A capable viewer can expose the raised-pose morph. Blender sources are the authoritative editable comparison files.

The individual candidate_N_neutral.png and candidate_N_raised.png images are actual Blender renders. Body, facial graphics and feet remain shared. All five arms are attached by intentional shoulder overlap, with no floating gap or visible two-segment elbow hinge.

## Checks and limits
Both endpoint poses of all five candidates were rendered and visually inspected. Automated checks confirmed intentional arm/body contact, no sampled face-vertex ray occlusion and no arm-to-arm surface overlap. The overlap at the shoulder is intentional; this is not a comprehensive production skinning or continuous-motion collision test. No browser or game-engine validation is claimed.

To reproduce the endpoint checks with Blender 4.3.2:

    blender -b -t 2 --python-exit-code 1 --python validate_candidates.py

This prints CANDIDATE_ENDPOINT_CHECKS_PASS and writes endpoint_checks.json. build_candidates.py generates all five studies; supplying `-- 4`, for example, builds only candidate 4. render_candidate.py accepts a candidate number after `--`. Rendering was limited to two CPU threads under the shared render lock.

No Site edits, publishing, upload or production-design selection was performed.
