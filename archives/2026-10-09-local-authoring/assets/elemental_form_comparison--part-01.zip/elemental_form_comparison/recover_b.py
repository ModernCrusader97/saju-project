"""Recovery of authored B_final construction from the worker's retained tool-call text.
Not a bit-identical binary restore: excludes unavailable hidden A/C comparison objects.
Original body/face/polish geometry, material, camera, lights and renderer preserved.
"""
import bpy, math, os, json, struct
from mathutils import Vector
P=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.read_factory_settings(use_empty=True)
def mat(n,c,rough=.22,trans=0):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=rough;p.inputs['IOR'].default_value=1.333;p.inputs['Transmission Weight'].default_value=trans;return m
water=mat('Shared pale azure jelly | dielectric',(.44,.80,.91),.19,.64)
p=water.node_tree.nodes.get('Principled BSDF');p.inputs['Coat Weight'].default_value=.2;p.inputs['Coat Roughness'].default_value=.12
ink=mat('Deep teal expression',(.012,.10,.14),.32)
white=mat('Soft glint',(.86,.97,1),.23)
ground=mat('Ivory studio',(.78,.83,.84),.62)
def uv(n,loc,scale,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=32,ring_count=20,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 for f in o.data.polygons:f.use_smooth=True
 return o
def line(n,points,rad,m):
 c=bpy.data.curves.new(n,'CURVE');c.dimensions='3D';c.bevel_depth=rad;c.bevel_resolution=3;s=c.splines.new('BEZIER');s.bezier_points.add(len(points)-1)
 for b,co in zip(s.bezier_points,points):b.co=co;b.handle_left_type='AUTO';b.handle_right_type='AUTO'
 o=bpy.data.objects.new(n,c);bpy.context.collection.objects.link(o);o.data.materials.append(m);return o
# Verbatim original B construction.
parts=[uv('B volume',(0,0,1.65),(.66,.48,.73),water),uv('B trunk',(0,.035,.79),(.44,.37,.73),water),uv('B base',(0,.035,.22),(.46,.36,.24),water),uv('B lowered paddle',(-.49,.0,.8),(.20,.24,.37),water),uv('B lifted paddle',(.53,-.03,1.17),(.28,.23,.18),water),uv('B waving tip',(.69,-.02,1.35),(.16,.19,.26),water)]
bpy.ops.object.select_all(action='DESELECT')
for q in parts:q.select_set(True)
bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join();b=parts[0];b.name='B | continuous soft body and small hands';r=b.modifiers.new('Connected fluid skin','REMESH');r.mode='VOXEL';r.voxel_size=.042;bpy.ops.object.modifier_apply(modifier=r.name);sm=b.modifiers.new('Soft flow','SMOOTH');sm.factor=.7;sm.iterations=5;bpy.ops.object.modifier_apply(modifier=sm.name)
for f in b.data.polygons:f.use_smooth=True
variants={'B':[b]}
def face(key,z,y,width):
 arr=variants[key]
 for sign in [-1,1]:
  x=sign*width
  eye=uv(key+' | almond gaze '+str(sign),(x,y,z),(.13,.037,.068),ink)
  for v in eye.data.vertices:v.co.z*=max(.38,1-abs(v.co.x)/.18)
  eye.rotation_euler.y=sign*-.10;arr.append(eye)
  arr.append(uv(key+' | small eye glint '+str(sign),(x-.025,y-.034,z+.018),(.017,.008,.018),white))
  arr.append(line(key+' | expressive brow '+str(sign),[(x-.12,y+.015,z+.17),(x,y-.014,z+.195+(sign==1)*.025),(x+.11,y+.015,z+.18)],.016,ink))
 arr.append(line(key+' | quiet smile',[(-.12,y-.007,z-.18),(0,y-.026,z-.205),(.13,y-.009,z-.17)],.014,ink))
 e=bpy.data.objects.new(key+' | accessory socket',None);bpy.context.collection.objects.link(e);e.location=(.41,.02,2.06);arr.append(e)
face('B',1.76,-.474,.235)
# Original studio conditions.
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.015));bpy.context.object.data.materials.append(ground)
world=bpy.data.worlds.new('Pale open studio');bpy.context.scene.world=world;world.use_nodes=True;world.node_tree.nodes.get('Background').inputs[0].default_value=(.79,.86,.9,1);world.node_tree.nodes.get('Background').inputs[1].default_value=.75
def area(n,loc,power,size):
 d=bpy.data.lights.new(n,'AREA');d.energy=power;d.shape='DISK';d.size=size;o=bpy.data.objects.new(n,d);bpy.context.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector((0,0,1.2))-o.location).to_track_quat('-Z','Y').to_euler()
area('Broad soft key',(-3,-4,6),450,4);area('Pale rim',(3,2,4),550,3);area('Quiet face fill',(0,-5,2),90,3)
d=bpy.data.cameras.new('Shared comparison camera');cam=bpy.data.objects.new('Shared comparison camera',d);bpy.context.collection.objects.link(cam);cam.location=(.30,-8,3.25);cam.rotation_euler=(Vector((0,0,1.2))-cam.location).to_track_quat('-Z','Y').to_euler();d.type='ORTHO';d.ortho_scale=3.15
s=bpy.context.scene;s.camera=cam;s.render.engine='CYCLES';s.cycles.device='CPU';s.render.threads_mode='FIXED';s.render.threads=2;s.cycles.samples=128;s.cycles.use_denoising=False;s.cycles.max_bounces=10;s.cycles.transmission_bounces=8;s.render.resolution_x=640;s.render.resolution_y=640;s.render.resolution_percentage=100;s.view_settings.view_transform='AgX'
bpy.context.view_layer.update()
# Verbatim original bounded polish applied to B.
key='B';body=bpy.data.objects.get('B | continuous soft body and small hands')
def surface(x,z):
 inv=body.matrix_world.inverted();hit,p,n,i=body.ray_cast(inv@Vector((x,-3,z)),inv.to_3x3()@Vector((0,1,0)))
 return (body.matrix_world@p).y if hit else -.6
for o in list(bpy.context.scene.objects):
 if o.name.startswith(key+' | almond gaze'):
  loc=o.location.copy();name=o.name;rot=o.rotation_euler.copy();m=o.data.materials[0];bpy.data.objects.remove(o,do_unlink=True)
  bpy.ops.mesh.primitive_uv_sphere_add(segments=32,ring_count=20,location=loc);o=bpy.context.object;o.name=name;o.scale=(.118,.029,.057);o.rotation_euler=rot;o.location.y=surface(loc.x,loc.z)-.016;o.data.materials.append(m)
  for f in o.data.polygons:f.use_smooth=True
 elif o.name.startswith(key+' | small eye glint'):
  o.location.y=surface(o.location.x+.025,o.location.z-.018)-.043
 elif o.name.startswith(key+' | quiet smile'):
  for sp in o.data.splines:
   for b in sp.bezier_points:b.co.y=surface(b.co.x,b.co.z)-.010
  o.data.bevel_depth=.012
bpy.ops.object.select_all(action='DESELECT')
for o in bpy.context.scene.objects:
 if not o.hide_render and o.type in ['MESH','CURVE','EMPTY'] and o.name!='Plane':o.hide_set(False);o.select_set(True)
bpy.ops.export_scene.gltf(filepath=P+'/B_final.glb',export_format='GLB',use_selection=True,export_apply=True)
s.render.filepath=P+'/B_final.png';bpy.ops.wm.save_as_mainfile(filepath=P+'/B_final.blend')
with open(P+'/B_final.glb','rb') as f:
 data=f.read();n=struct.unpack_from('<I',data,12)[0];j=json.loads(data[20:20+n])
triangles=sum(j['accessors'][prim['indices']]['count']//3 for m in j['meshes'] for prim in m['primitives']);vertices=sum(j['accessors'][prim['attributes']['POSITION']]['count'] for m in j['meshes'] for prim in m['primitives'])
audit={'recovery_basis':'Actual original authored generator and polish retained in worker conversation; standalone B scene reconstructed','bit_identical_claim':False,'hidden_A_C_reference_objects_recovered':False,'blender_version':bpy.app.version_string,'glb_bytes':len(data),'exported_triangles':triangles,'exported_vertices':vertices,'meshes':len(j['meshes']),'extensions':j.get('extensionsUsed',[]),'original_retained_audit':{'glb_bytes':393428,'exported_triangles':19548,'exported_vertices':10213,'meshes':8},'topology_count_match':triangles==19548 and vertices==10213 and len(j['meshes'])==8}
with open(P+'/recovery_audit.json','w') as f:json.dump(audit,f,indent=2)
print('RECOVERY_AUDIT',json.dumps(audit),flush=True)
bpy.ops.render.render(write_still=True)
