# B source recovery

Recovered 2026-10-03 from the original author's retained tool-call code, after the workspace artifacts were lost. `recover_b.py` extracts the originally authored B construction and the originally authored bounded face polish. It is not a new design inferred from an image.

Files:
- B_final.blend: standalone native B scene with the original comparison camera, lights, material, ground and render settings.
- B_final.glb: selected B geometry and accessory socket.
- B_final.png: newly rendered proof from the recovered native scene.
- recover_b.py: executable deterministic reconstruction source.
- recovery_audit.json: retained-original-count comparison.

Verified recovered topology matches the retained original audit: 19,548 exported triangles, 10,213 exported vertices, eight meshes. Same standard glTF clearcoat, transmission and IOR extensions. Recovered GLB is 393,424 bytes; the retained original audit was 393,428 bytes. No original binary is available for hashing or byte comparison, so bit-identical recovery is not claimed.

The original comparison .blend also contained hidden A/C objects. Those unavailable reference objects are intentionally not included in this standalone recovery. The prior Library comparison could not be accessed due to a scope restriction; no alternate access route was attempted. The new proof is visually inspected against the author's retained prior observations, not presented as a fresh pixel regression against an accessible old file.

Body: combined remeshed head/trunk/base/two paddle-hand shape, no legs or fingers. Face: shallow rounded eyes, small glints, separate brows, body-projected smile. One upper-right named accessory socket. No animation, mobile benchmark, production-ready rig, Site integration or publishing is claimed.
