#!/bin/bash
set -e
cd /workspace/scratch/c9f1a9454187
for frames in '1 4 7 10 13 16' '19 22 25 28 31 34 36'; do
 for clip in wave_hello open_arms hands_gathered; do
  PROOF_SIZE=320 PROOF_SAMPLES=48 flock /tmp/b_form_render.lock blender -b -t 2 --python b_gestures_v4/render_v4.py -- "$clip" $frames >> b_gestures_v4/motion_render.log 2>&1
 done
done
