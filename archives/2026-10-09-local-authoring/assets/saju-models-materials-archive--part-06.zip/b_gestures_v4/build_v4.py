import bpy,os,math,json
from mathutils import Vector,Matrix
P=os.path.dirname(os.path.abspath(__file__))
source=P+'/source/B_separate_arms_v3.blend'
if not os.path.exists(source):source=os.path.dirname(P)+'/b_gestures_v3/B_separate_arms_v3.blend'
bpy.ops.wm.open_mainfile(filepath=source)
s=bpy.context.scene;rig=bpy.data.objects['B_shared_gesture_rig'];body=bpy.data.objects['B | continuous core without fused paddles'];rig.animation_data_clear()
for a in list(bpy.data.actions):bpy.data.actions.remove(a)
for o in list(s.objects):
 if o.name.startswith('B | separate soft arm'):bpy.data.objects.remove(o,do_unlink=True)
for p in rig.pose.bones:p.location=(0,0,0);p.rotation_euler=(0,0,0);p.scale=(1,1,1)
rig.pose.bones['surprise_mouth'].scale=(.001,.001,.001)
points={}
for side,letter in [(-1,'L'),(1,'R')]:points[letter]=(Vector((side*.425,-.10,1.16)),Vector((side*.65,-.10,.99)),Vector((side*.69,-.14,.74)))
bpy.context.view_layer.objects.active=rig;bpy.ops.object.mode_set(mode='EDIT')
for side,letter in [(-1,'L'),(1,'R')]:
 S,E,H=points[letter];u=rig.data.edit_bones.new('upper_arm_'+letter);u.head=S;u.tail=E;u.parent=rig.data.edit_bones['body'];lo=rig.data.edit_bones['paddle_'+letter];lo.head=E;lo.tail=H;lo.parent=u;lo.use_connect=True;lo.roll=0
bpy.ops.object.mode_set(mode='OBJECT');water=body.data.materials[0]
def sphere(n,loc,scale):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=16,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return o
def link(n,a,b,r):
 mid=(a+b)/2;o=sphere(n,mid,(r,r,(b-a).length/2+r*.4));o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();bpy.ops.object.transform_apply(location=False,rotation=True,scale=False);return o
for side,letter in [(-1,'L'),(1,'R')]:
 S,E,H=points[letter];parts=[sphere('soft shoulder',S,(.125,.125,.125)),link('upper',S,E,.105),sphere('soft elbow',E,(.122,.122,.122)),link('forearm',E,H,.108),sphere('round hand',H,(.131,.125,.138))]
 bpy.ops.object.select_all(action='DESELECT')
 for o in parts:o.select_set(True)
 bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join();o=parts[0];o.name='B | attached soft arm '+letter
 rem=o.modifiers.new('One soft arm surface','REMESH');rem.mode='VOXEL';rem.voxel_size=.015;bpy.ops.object.modifier_apply(modifier=rem.name);sm=o.modifiers.new('Gentle joint blend','SMOOTH');sm.factor=.55;sm.iterations=6;bpy.ops.object.modifier_apply(modifier=sm.name)
 for p in o.data.polygons:p.use_smooth=True
 o.data.materials.append(water);o.parent=rig;up=o.vertex_groups.new(name='upper_arm_'+letter);lo=o.vertex_groups.new(name='paddle_'+letter)
 upperdir=(E-S).normalized();lowerdir=(H-E).normalized();axis=(upperdir+lowerdir).normalized()
 for v in o.data.vertices:
  co=o.matrix_world@v.co;t=(co-E).dot(axis);w=max(0,min(1,(t+.065)/.13));w=w*w*(3-2*w);up.add([v.index],1-w,'REPLACE');lo.add([v.index],w,'REPLACE')
 m=o.modifiers.new('Shoulder and elbow skin','ARMATURE');m.object=rig
# Analytic two-segment shoulder/elbow solve; spherical caps remain attached at fixed roots.
rest={n:rig.data.bones[n].matrix_local.copy() for n in ['upper_arm_L','upper_arm_R','paddle_L','paddle_R']}
def place(n,head,tail):
 b=rig.data.bones[n];direction=(tail-head).normalized();delta=(b.tail_local-b.head_local).normalized().rotation_difference(direction);rot=delta.to_matrix()@rest[n].to_3x3();m=rot.to_4x4();m.translation=head;rig.pose.bones[n].matrix=m;bpy.context.view_layer.update()
def solve(letter,H,pole):
 S,E0,H0=points[letter];a=(E0-S).length;b=(H0-E0).length;v=H-S;d=min(max(v.length,.025),a+b-.003);D=v.normalized();H=S+D*d;x=(a*a-b*b+d*d)/(2*d);height=math.sqrt(max(0,a*a-x*x));perp=pole-S-D*(pole-S).dot(D)
 if perp.length<1e-5:perp=Vector((0,-1,0))-D*D.dot(Vector((0,-1,0)))
 E=S+D*x+perp.normalized()*height;place('upper_arm_'+letter,S,E);place('paddle_'+letter,E,H)
def interp(keys,f):
 for i in range(len(keys)-1):
  a,av=keys[i];b,bv=keys[i+1]
  if a<=f<=b:
   t=(f-a)/(b-a);t=t*t*(3-2*t);return Vector(av).lerp(Vector(bv),t)
 return Vector(keys[-1][1])
def mirrored(v,side):return Vector((v[0]*side,v[1],v[2]))
neutral=(.69,-.14,.74)
wave=[(1,neutral),(5,(.73,-.14,.72)),(11,(.83,-.28,1.40)),(16,(.76,-.36,1.46)),(21,(.83,-.28,1.40)),(26,(.76,-.36,1.46)),(31,(.77,-.28,1.28)),(36,neutral)]
opened=[(1,neutral),(6,(.68,-.18,.70)),(13,(.92,-.16,1.09)),(25,(.92,-.16,1.09)),(30,(.82,-.18,.96)),(36,neutral)]
gather=[(1,neutral),(6,(.65,-.33,.81)),(10,(.55,-.49,.95)),(15,(.17,-.51,1.10)),(25,(.17,-.51,1.10)),(31,(.55,-.49,.95)),(36,neutral)]
for clip in ['wave_hello','open_arms','hands_gathered']:
 rig.animation_data_create();act=bpy.data.actions.new(clip);rig.animation_data.action=act
 for frame in range(1,37):
  for p in rig.pose.bones:p.rotation_mode='QUATERNION';p.location=(0,0,0);p.rotation_quaternion=(1,0,0,0);p.scale=(1,1,1)
  rig.pose.bones['surprise_mouth'].scale=(.001,.001,.001)
  for side,letter in [(-1,'L'),(1,'R')]:
   keys=wave if clip=='wave_hello' and side==1 else opened if clip=='open_arms' else gather if clip=='hands_gathered' else [(1,neutral),(36,neutral)]
   target=mirrored(interp(keys,frame),side)
   pole=Vector((side*.72,-.19,1.02)) if clip=='wave_hello' else Vector((side*.68,-.12,.85)) if clip=='open_arms' else Vector((side*.65,-.42,.90))
   # Match the exact neutral bend at start/end for seamless clip blending.
   amount=min(1,max(0,(frame-1)/5),max(0,(36-frame)/5));pole=points[letter][1].lerp(pole,amount)
   solve(letter,target,pole)
  friendly=math.sin(math.pi*(frame-1)/35)**2
  for side in [-1,1]:rig.pose.bones['eye_'+str(side)].scale.y=1-.08*friendly;rig.pose.bones['brow_'+str(side)].location.y=.02*friendly
  for p in rig.pose.bones:
   for prop in ['location','rotation_quaternion','scale']:p.keyframe_insert(data_path=prop,frame=frame,group=p.name)
 for fc in act.fcurves:
  for kp in fc.keyframe_points:kp.interpolation='LINEAR'
 act.use_fake_user=True
rig.animation_data.action=bpy.data.actions['wave_hello'];s.frame_start=1;s.frame_end=36;s.render.fps=12;s.frame_set(1);s.cycles.samples=48;s.cycles.use_denoising=False;s.render.threads_mode='FIXED';s.render.threads=2;s.render.resolution_x=320;s.render.resolution_y=320
bpy.ops.wm.save_as_mainfile(filepath=P+'/B_attached_arms_v4.blend')
bpy.ops.object.select_all(action='DESELECT')
for o in s.objects:
 if o==rig or o.parent==rig:o.select_set(True)
bpy.context.view_layer.objects.active=rig;bpy.ops.export_scene.gltf(filepath=P+'/B_attached_arms_v4.glb',export_format='GLB',use_selection=True,export_animations=True,export_animation_mode='ACTIONS',export_force_sampling=True,export_apply=False)
json.dump({'source':'B_separate_arms_v3.blend (clean core, same v2 face/feet)','arm_design':'Attached continuous rounded arm meshes, soft shoulder/elbow/hand, no fingers','shoulders':{k:list(v[0]) for k,v in points.items()},'joints':len(rig.data.bones),'clips':[a.name for a in bpy.data.actions],'browser_validated':False},open(P+'/build_audit.json','w'),indent=2)
