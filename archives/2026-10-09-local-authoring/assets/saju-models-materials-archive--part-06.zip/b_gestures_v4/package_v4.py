import zipfile,os,json,struct
P=os.path.dirname(os.path.abspath(__file__));raw=open(P+'/B_attached_arms_v4.glb','rb').read();j=json.loads(raw[20:20+struct.unpack_from('<I',raw,12)[0]])
a=json.load(open(P+'/build_audit.json'));a.update(glb_bytes=len(raw),skins=len(j['skins']),joints=len(j['skins'][0]['joints']),glb_animations=[v['name'] for v in j['animations']],material_extensions=j.get('extensionsUsed'));json.dump(a,open(P+'/build_audit.json','w'),indent=2)
files=['B_attached_arms_v4.blend','B_attached_arms_v4.glb','README.md','build_audit.json','deformation_clearance_audit.json','mesh_integrity_audit.json','glb_roundtrip_audit.json','build_v4.py','render_v4.py','validate_v4.py','validate_glb_v4.py','check_mesh.py','assemble_v4.py','B_v4_attached_arm_poses.jpg','B_v4_neutral.png','B_attached_arms_v4_preview.mp4','wave_hello.mp4','open_arms.mp4','hands_gathered.mp4','validation.log','glb_validation.log','mesh_validation.log']
with zipfile.ZipFile(P+'/B_attached_arms_v4_native_bundle.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(P+'/'+f,'B_attached_arms_v4/'+f)
 z.write(os.path.dirname(P)+'/b_gestures_v3/B_separate_arms_v3.blend','B_attached_arms_v4/source/B_separate_arms_v3.blend')
with zipfile.ZipFile(P+'/B_attached_arms_v4_native_bundle.zip') as z:print('ZIP_TEST',z.testzip(),'FILES',len(z.namelist()))
print('ZIP_BYTES',os.path.getsize(P+'/B_attached_arms_v4_native_bundle.zip'))
