from PIL import Image,ImageDraw,ImageFont
import os,subprocess
P=os.path.dirname(os.path.abspath(__file__));font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';f=ImageFont.truetype(font,23);small=ImageFont.truetype(font,17)
can=Image.new('RGB',(1280,396),'#edf2f3');d=ImageDraw.Draw(can);d.text((18,14),'Bv4 / ATTACHED SOFT ARMS',font=f,fill='#193c46')
for i,(clip,frame,label) in enumerate([('wave_hello',1,'neutral'),('wave_hello',16,'wave'),('open_arms',16,'open arms'),('hands_gathered',16,'hands near chest')]):
 im=Image.open(f'{P}/frames/{clip}/{frame:03d}.png').convert('RGB').resize((320,320));can.paste(im,(i*320,48));d.text((i*320+14,373),label,font=small,fill='#193c46')
can.save(P+'/B_v4_attached_arm_poses.jpg',quality=96)
clips=['wave_hello','open_arms','hands_gathered'];frames=[1,4,7,10,13,16,19,22,25,28,31,34,36]
for clip in clips:
 concat=P+'/'+clip+'_concat.txt';files=[f'frames/{clip}/{n:03d}.png' for n in frames];dur=[(frames[i+1]-frames[i])/12 for i in range(len(frames)-1)]+[.25];open(concat,'w').write(''.join("file '"+p+"'\nduration "+str(t)+'\n' for p,t in zip(files,dur))+"file '"+files[-1]+"'\n")
 subprocess.run(['ffmpeg','-y','-threads','2','-f','concat','-safe','0','-i',concat,'-vf','scale=320:320,fps=12','-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',P+'/'+clip+'.mp4'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
filters=[]
for i,label in enumerate(['wave','open','gathered']):filters.append(f"[{i}:v]pad=iw:ih+38:0:38:color=0xedf2f3,drawtext=fontfile={font}:text='{label}':x=10:y=10:fontsize=15:fontcolor=0x193c46[v{i}]")
filters.append('[v0][v1][v2]hstack=inputs=3[out]');args=['ffmpeg','-y','-threads','2']
for clip in clips:args+=['-i',P+'/'+clip+'.mp4']
args+=['-filter_complex',';'.join(filters),'-map','[out]','-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',P+'/B_attached_arms_v4_preview.mp4'];subprocess.run(args,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);print('V4_PROOF_ASSEMBLED')
