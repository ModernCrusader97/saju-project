import bpy,os,json
P=os.path.dirname(os.path.abspath(__file__));clips=['wave_hello','open_arms','hands_gathered'];frames=[1,6,10,16,22,29,36];names=['B | continuous core without fused paddles','B | attached soft arm L','B | attached soft arm R']
def bounds(o):
 ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh();v=[ev.matrix_world@p.co for p in m.vertices];ev.to_mesh_clear();return [c for i in range(3) for c in [min(p[i] for p in v),max(p[i] for p in v)]]
bpy.ops.wm.open_mainfile(filepath=P+'/B_attached_arms_v4.blend');rig=bpy.data.objects['B_shared_gesture_rig'];expected={}
for clip in clips:
 rig.animation_data.action=bpy.data.actions[clip]
 for frame in frames:
  bpy.context.scene.frame_set(frame)
  for name in names:expected[(clip,frame,name)]=bounds(bpy.data.objects[name])
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.context.scene.render.fps=12;bpy.ops.import_scene.gltf(filepath=P+'/B_attached_arms_v4.glb');rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE')
for track in rig.animation_data.nla_tracks:track.mute=True
records=[]
for clip in clips:
 action=next(a for a in bpy.data.actions if a.name==clip or a.name.startswith(clip+'_'));rig.animation_data.action=action
 for frame in frames:
  bpy.context.scene.frame_set(frame)
  for name in names:
   got=bounds(bpy.data.objects[name]);error=max(abs(a-b) for a,b in zip(got,expected[(clip,frame,name)]));assert error<.0001,(clip,frame,name,error);records.append({'clip':clip,'frame':frame,'mesh':name,'max_bounds_error':error})
audit={'result':'PASS','records':records,'max_error':max(v['max_bounds_error'] for v in records),'browser_validated':False};json.dump(audit,open(P+'/glb_roundtrip_audit.json','w'),indent=2);print('GLB_ROUNDTRIP_MATCH_PASS',len(records),'mesh-pose comparisons; max bounds error',audit['max_error'])
