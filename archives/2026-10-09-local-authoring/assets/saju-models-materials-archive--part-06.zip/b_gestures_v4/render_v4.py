import bpy,os,sys,shutil
P=os.path.dirname(os.path.abspath(__file__));args=sys.argv[sys.argv.index('--')+1:];clip=args[0];frames=list(map(int,args[1:]))
bpy.ops.wm.open_mainfile(filepath=P+'/B_attached_arms_v4.blend');s=bpy.context.scene;rig=bpy.data.objects['B_shared_gesture_rig'];rig.animation_data.action=bpy.data.actions[clip];s.cycles.samples=int(os.environ.get('PROOF_SAMPLES','48'));s.cycles.use_denoising=False;s.render.resolution_x=int(os.environ.get('PROOF_SIZE','320'));s.render.resolution_y=s.render.resolution_x;s.render.threads_mode='FIXED';s.render.threads=2
os.makedirs(P+'/frames/'+clip,exist_ok=True)
for f in frames:
 s.frame_set(f);s.render.filepath=P+'/frames/'+clip+'/'+str(f).zfill(3)+'.png';bpy.ops.render.render(write_still=True)
 if s.render.resolution_x==512 and f in [1,16]:shutil.copyfile(s.render.filepath,P+'/'+clip+'_'+str(f)+'.png')
