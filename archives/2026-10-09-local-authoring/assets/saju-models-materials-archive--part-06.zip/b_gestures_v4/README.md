# Bv4 — attached, softly articulated arms

This implements the clarified direction: arms attached to the body, freely posed through shoulder and elbow joints. The established B face, core proportions, short feet and aqua material are retained. There is no floating gap, no duplicate fused paddle, and no exposed mechanical joint or finger anatomy.

Each side uses one continuous rounded arm mesh, with a soft overlapping shoulder cap, upper arm, blended elbow, forearm and rounded hand. The shoulder origin stays fixed on the body while the two arm bones articulate. The elbow surface received a small smoothing pass without changing the arm proportions.

## Deliverables
- B_attached_arms_v4.blend: editable source and three actions.
- B_attached_arms_v4.glb: portable skinned model with 13 joints and the same three clips.
- B_v4_attached_arm_poses.jpg: neutral, wave, open arms and hands-near-chest poses, same camera.
- B_attached_arms_v4_preview.mp4: compact labeled three-gesture motion study, no audio.
- Individual wave_hello / open_arms / hands_gathered MP4s.
- Validation scripts, JSON audits and source-generation script.

The gestures span frames 1–36 at 12 fps. The portable GLB retains the full sampled animation. The small video proof samples approximately four rendered poses per second and encodes them at 12 fps.

## Rig
The core is `B | continuous core without fused paddles`. The arms are `B | attached soft arm L` and `B | attached soft arm R`.

`upper_arm_L` and `upper_arm_R` provide shoulder motion. The existing `paddle_L` and `paddle_R` bones now control the forearms. The body/head/root and graphic facial controls remain. Soft arm skin weights blend across the elbow; all four arm bones use standard portable linear skinning. The generator solves two-segment arm poses and bakes their transforms, so runtime IK is not required.

## Reproducible verification
Run from a terminal with Blender 4.3.2 available:

    blender -b -t 2 --python-exit-code 1 --python validate_v4.py
    blender -b -t 2 --python-exit-code 1 --python validate_glb_v4.py
    blender -b -t 2 --python-exit-code 1 --python check_mesh.py

The scripts locate assets beside themselves. The first prints ATTACHMENT_AND_CLEARANCE_PASS and writes deformation_clearance_audit.json. The second prints GLB_ROUNDTRIP_MATCH_PASS and writes glb_roundtrip_audit.json. The third writes mesh_integrity_audit.json.

Attachment is checked separately from unwanted clipping. A .23-unit radius around each fixed shoulder marks the intentional attachment patch; mesh faces crossing that patch boundary remain part of the attachment. Every sampled pose must retain shoulder vertices inside the core. Vertices and faces wholly beyond the patch must not penetrate the body. Arms must not intersect each other, and sampled face-vertex rays from the camera must remain unobstructed.

All 213 frame/half-frame samples passed those checks. The closest non-attachment arm/core vertex distance is approximately .00523 scene units; nearest arm/arm distance is approximately .07247. Every clip returns exactly to neutral, and the core remains grounded at z=-.014. GLB re-import matched 63 evaluated mesh-pose bounding boxes to the blend source within 3.73e-7.

## Limits
These are reproducible geometric and sampled visibility checks plus rendered visual inspection, not a production cloth/skin solver or proof for every continuous subframe. The shoulder uses intentional overlapping surfaces rather than a welded body/arm mesh. No browser or game-engine validation is claimed. The material uses glTF transmission, IOR and clearcoat extensions. No ten-character rebuild or Site publishing was performed.
