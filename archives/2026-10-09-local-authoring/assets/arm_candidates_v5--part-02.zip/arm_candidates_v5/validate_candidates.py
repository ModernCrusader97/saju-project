import bpy,bmesh,os,json,math
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=os.path.dirname(os.path.abspath(__file__))
def evaluated(o,dg):
 ev=o.evaluated_get(dg);m=ev.to_mesh();vs=[ev.matrix_world@v.co for v in m.vertices];fs=[tuple(p.vertices) for p in m.polygons];ev.to_mesh_clear();return vs,fs
out=[]
for i in range(1,6):
 bpy.ops.wm.open_mainfile(filepath=P+'/candidate_'+str(i)+'.blend');s=bpy.context.scene;arms=[o for o in s.objects if o.name.startswith('Candidate '+str(i)+' attached arm')];body=bpy.data.objects['B | continuous core without fused paddles'];poses=[]
 for frame in [1,2]:
  s.frame_set(frame);dg=bpy.context.evaluated_depsgraph_get();cv,cf=evaluated(body,dg);core=BVHTree.FromPolygons(cv,cf);record={'frame':frame,'arms':[]};bvhs=[]
  for o in arms:
   vs,fs=evaluated(o,dg);bvh=BVHTree.FromPolygons(vs,fs);bvhs.append(bvh);inside=0;occlusion=0
   for v in vs:
    hit,n,idx,dist=core.find_nearest(v)
    if (v-hit).dot(n)<-.0005:inside+=1
   direction=s.camera.matrix_world.to_3x3()@Vector((0,0,-1))
   for face in s.objects:
    if face.type=='MESH' and any(q in face.name for q in ['almond gaze','eye glint','expressive brow','quiet smile']):
     fv,ff=evaluated(face,dg)
     for v in fv[::8]:
      if bvh.ray_cast(v-direction*10,direction,9.999)[0] is not None:occlusion+=1
   assert inside>0,(i,frame,'detached arm');assert occlusion==0,(i,frame,'face occlusion');assert all(math.isfinite(q) for v in vs for q in v)
   record['arms'].append({'name':o.name,'attachment_overlap_vertices':inside,'sampled_face_ray_occlusions':occlusion,'vertices':len(vs)})
  record['arm_arm_overlaps']=len(bvhs[0].overlap(bvhs[1]));assert record['arm_arm_overlaps']==0;poses.append(record)
 out.append({'candidate':i,'poses':poses})
json.dump({'result':'PASS','scope':'Two endpoint poses per candidate; attachment overlap and face-ray visibility checked; intentional shoulder/core overlap allowed; not a production motion/interpolation test','candidates':out,'browser_validated':False},open(P+'/endpoint_checks.json','w'),indent=2);print('CANDIDATE_ENDPOINT_CHECKS_PASS',len(out),'candidates x2poses; attached contact, no sampled face occlusion or arm-arm intersection')
