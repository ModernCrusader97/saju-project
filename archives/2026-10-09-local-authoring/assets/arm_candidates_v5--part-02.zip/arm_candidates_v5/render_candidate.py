import bpy,os,sys
P=os.path.dirname(os.path.abspath(__file__));i=int(sys.argv[sys.argv.index('--')+1]);bpy.ops.wm.open_mainfile(filepath=P+'/candidate_'+str(i)+'.blend');s=bpy.context.scene
for frame,label in [(1,'neutral'),(2,'raised')]:
 s.frame_set(frame);s.render.filepath=P+'/candidate_'+str(i)+'_'+label+'.png';bpy.ops.render.render(write_still=True)
