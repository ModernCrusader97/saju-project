import bpy,bmesh,os,json
P=os.path.dirname(os.path.abspath(__file__));bpy.ops.wm.open_mainfile(filepath=P+'/B_separate_arms_v3.blend');out=[]
for name in ['B | continuous core without fused paddles','B | separate soft arm L','B | separate soft arm R']:
 o=bpy.data.objects[name];bm=bmesh.new();bm.from_mesh(o.data);out.append({'name':name,'vertices':len(bm.verts),'faces':len(bm.faces),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'near_zero_area_faces':sum(f.calc_area()<1e-12 for f in bm.faces),'max_weight_sum_error':max(abs(sum(g.weight for g in v.groups)-1) for v in o.data.vertices)});bm.free()
json.dump(out,open(P+'/mesh_integrity_audit.json','w'),indent=2);print('MESH_INTEGRITY',out)
