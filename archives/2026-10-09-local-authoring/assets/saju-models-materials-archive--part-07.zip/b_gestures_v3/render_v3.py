import bpy,os,sys,shutil
P=os.path.dirname(os.path.abspath(__file__));args=sys.argv[sys.argv.index('--')+1:];version,clip=args[:2];frames=list(map(int,args[2:]))
source=P+'/B_separate_arms_v3.blend' if version=='after' else os.path.dirname(P)+'/b_gestures_v2/B_gesture_rig_v2.blend'
if version=='before' and os.path.exists(P+'/source/B_gesture_rig_v2.blend'):source=P+'/source/B_gesture_rig_v2.blend'
bpy.ops.wm.open_mainfile(filepath=source);s=bpy.context.scene;rig=bpy.data.objects['B_shared_gesture_rig'];rig.animation_data.action=bpy.data.actions[clip]
s.cycles.samples=int(os.environ.get('PROOF_SAMPLES','48'));s.cycles.use_denoising=False;s.render.resolution_x=int(os.environ.get('PROOF_SIZE','320'));s.render.resolution_y=s.render.resolution_x;s.render.threads_mode='FIXED';s.render.threads=2
os.makedirs(P+'/frames/'+version+'/'+clip,exist_ok=True)
for f in frames:
 s.frame_set(f);s.render.filepath=P+'/frames/'+version+'/'+clip+'/'+str(f).zfill(3)+'.png';bpy.ops.render.render(write_still=True)
 if s.render.resolution_x==512 and clip=='wave_hello' and f==1:shutil.copyfile(s.render.filepath,P+'/B_v3_'+version+'.png')
