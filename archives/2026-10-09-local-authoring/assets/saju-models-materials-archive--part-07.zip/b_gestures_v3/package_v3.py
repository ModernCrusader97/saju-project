import zipfile,os,json,struct
P=os.path.dirname(os.path.abspath(__file__));raw=open(P+'/B_separate_arms_v3.glb','rb').read();j=json.loads(raw[20:20+struct.unpack_from('<I',raw,12)[0]])
a=json.load(open(P+'/build_audit.json'));a.update(glb_bytes=len(raw),skins=len(j['skins']),joints=len(j['skins'][0]['joints']),glb_animations=[v['name'] for v in j['animations']],material_extensions=j.get('extensionsUsed'));json.dump(a,open(P+'/build_audit.json','w'),indent=2)
files=['B_separate_arms_v3.blend','B_separate_arms_v3.glb','README.md','build_audit.json','deformation_clearance_audit.json','mesh_integrity_audit.json','roundtrip_validation.json','build_v3.py','render_v3.py','validate_v3.py','validate_glb.py','check_mesh.py','assemble_v3.py','B_v3_before_after.jpg','B_v3_before.png','B_v3_after.png','B_gestures_v3_preview.mp4','wave_hello.mp4','open_arms.mp4','hands_gathered.mp4']
with zipfile.ZipFile(P+'/B_separate_arms_v3_native_bundle.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(P+'/'+f,'B_separate_arms_v3/'+f)
 z.write(os.path.dirname(P)+'/b_gestures_v2/B_gesture_rig_v2.blend','B_separate_arms_v3/source/B_gesture_rig_v2.blend')
with zipfile.ZipFile(P+'/B_separate_arms_v3_native_bundle.zip') as z:print('ZIP_TEST',z.testzip(),'FILES',len(z.namelist()))
print('ZIP_BYTES',os.path.getsize(P+'/B_separate_arms_v3_native_bundle.zip'))
