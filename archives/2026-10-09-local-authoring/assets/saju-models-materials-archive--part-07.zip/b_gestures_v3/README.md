# Bv3 — separate soft-arm gesture study

A bounded, reviewable interpretation of the request to separate B's arms for freer gestures. The two rounded arm/hand forms have a small intentional floating gap. This does not commit the whole character family to levitating hands; v2 remains available unchanged.

## Design and scope
- Retains Bv2's established face, head height, short foot lobes, aqua material and camera.
- Removes the old fused paddle bulges from the core instead of adding duplicate arms. The former joins are smoothed into a continuous core, without sockets or shoulder anatomy.
- Adds two independent short, soft rounded arm meshes. No fingers, elbows, realistic joints or new costume details.
- Shows wave hello, open arms and hands gathered near the chest. The gathered gesture approaches from the front so it avoids passing through the body; it stays below the face.
- No ten-material rebuild, Site changes or publishing was performed.

## Deliverables
- B_separate_arms_v3.blend: editable source and three actions.
- B_separate_arms_v3.glb: one skinned rig, independent arm meshes and three named clips.
- B_v3_before_after.jpg: neutral before/after with the same camera, lighting, material and pose.
- B_gestures_v3_preview.mp4: compact labeled three-gesture proof, no audio.
- wave_hello.mp4, open_arms.mp4, hands_gathered.mp4: individual previews.
- JSON audits and validation scripts: actual geometry, deformation, clearance and GLB-import checks.

## Rig contract
The body is `B | continuous core without fused paddles`. The new meshes are `B | separate soft arm L` and `B | separate soft arm R`. The existing `paddle_L` and `paddle_R` controls now independently position those meshes. Their old body weights were redistributed smoothly to body/head. The core still has 6,624 vertices in the original order; each arm has 610 vertices. Face controls and root/body/head remain shared.

The three actions are wave_hello, open_arms and hands_gathered. Each spans frames 1–36 at 12 fps and returns to the same neutral pose. The source contains the full sampled GLB animation, whereas the compact rendered proof samples poses at approximately four frames per second and encodes them at 12 fps.

## Actual checks and limits
All 36 frames of all three actions were evaluated in Blender 4.3.2. Checks found zero arm/core surface overlaps, zero arm/arm surface overlaps, no arm vertices inside the core, and zero occlusions of sampled facial vertices from the orthographic camera. The smallest measured arm/core vertex clearance is approximately .0444 scene units; closest arm/arm separation is approximately .0867. All clips return exactly to neutral. Core and arms are closed manifold meshes, with no near-zero-area faces; skin weights sum to one within 7e-8.

GLB was re-imported into Blender and evaluated at seven frames per action. Actual rendered poses and the decoded combined video were visually inspected. This is not browser or game-engine validation, and the checks sample animation frames rather than every continuous subframe. Materials use KHR_materials_transmission, KHR_materials_ior and KHR_materials_clearcoat.

Rendering uses two CPU threads. The proof is intentionally a small, bounded review deliverable rather than a final production animation or full family rollout.
