import bpy,os,json,math
from mathutils.bvhtree import BVHTree
from mathutils import Vector
P=os.path.dirname(os.path.abspath(__file__));bpy.ops.wm.open_mainfile(filepath=P+'/B_separate_arms_v3.blend');s=bpy.context.scene;rig=bpy.data.objects['B_shared_gesture_rig'];core=bpy.data.objects['B | continuous core without fused paddles'];arms=[bpy.data.objects['B | separate soft arm '+side] for side in ['L','R']]
def mesh(o,dg):
 ev=o.evaluated_get(dg);m=ev.to_mesh();v=[ev.matrix_world@p.co for p in m.vertices];f=[tuple(p.vertices) for p in m.polygons];ev.to_mesh_clear();return v,f
out=[]
for clip in ['wave_hello','open_arms','hands_gathered']:
 rig.animation_data.action=bpy.data.actions[clip];records=[];neutral=[]
 for frame in range(1,37):
  s.frame_set(frame);dg=bpy.context.evaluated_depsgraph_get();v,f=mesh(core,dg);bvh=BVHTree.FromPolygons(v,f);rec={'frame':frame,'core_bottom_z':min(p.z for p in v),'arms':[]};allarms=[]
  for arm in arms:
   av,af=mesh(arm,dg);signed=[]
   for p in av:
    loc,n,idx,d=bvh.find_nearest(p);signed.append(d if (p-loc).dot(n)>=0 else -d)
   arm_bvh=BVHTree.FromPolygons(av,af)
   overlaps=len(bvh.overlap(arm_bvh))
   face_occlusions=0;camera_dir=s.camera.matrix_world.to_3x3()@Vector((0,0,-1))
   for face in s.objects:
    if face.type=='MESH' and any(t in face.name for t in ['almond gaze','small eye glint','expressive brow','quiet smile']):
     fv,ff=mesh(face,dg)
     for point in fv[::8]:
      hit=arm_bvh.ray_cast(point-camera_dir*10,camera_dir,9.999)
      if hit[0] is not None:face_occlusions+=1
   rec['arms'].append({'name':arm.name,'core_surface_triangle_overlaps':overlaps,'sampled_face_vertex_ray_occlusions':face_occlusions,'min_signed_core_distance':min(signed),'vertices_inside_core':sum(d<-.0005 for d in signed),'bounds':[[min(p[i] for p in av),max(p[i] for p in av)] for i in range(3)]});allarms.append((av,af))
  av,af=allarms[0];bv,bf=allarms[1];other=BVHTree.FromPolygons(bv,bf);rec['arm_arm_surface_overlaps']=len(BVHTree.FromPolygons(av,af).overlap(other));rec['arm_arm_vertex_min_distance']=min(other.find_nearest(p)[3] for p in av)
  assert all(math.isfinite(c) for p in v for c in p);records.append(rec)
  if frame in [1,36]:neutral.append(v+allarms[0][0]+allarms[1][0])
 out.append({'clip':clip,'frames':records,'neutral_return_vertex_error':max((a-b).length for a,b in zip(*neutral))})
json.dump({'checks':'All36 frames per clip; evaluated mesh vertices; signed nearest-core distances and arm separation','clips':out,'browser_validated':False},open(P+'/deformation_clearance_audit.json','w'),indent=2)
print('CLEARANCE_SUMMARY',[(a['clip'],min(b['min_signed_core_distance'] for f in a['frames'] for b in f['arms']),max(b['vertices_inside_core'] for f in a['frames'] for b in f['arms']),min(f['arm_arm_vertex_min_distance'] for f in a['frames'])) for a in out])
