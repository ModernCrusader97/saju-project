import bpy,os,math,json
from mathutils import Vector
P=os.path.dirname(os.path.abspath(__file__))
source=P+'/source/B_gesture_rig_v2.blend'
if not os.path.exists(source):source=os.path.dirname(P)+'/b_gestures_v2/B_gesture_rig_v2.blend'
bpy.ops.wm.open_mainfile(filepath=source)
s=bpy.context.scene;rig=bpy.data.objects['B_shared_gesture_rig'];body=bpy.data.objects['B | continuous soft body and small hands'];s.frame_set(1)
rig.animation_data_clear()
for a in list(bpy.data.actions):bpy.data.actions.remove(a)
for pb in rig.pose.bones:pb.location=(0,0,0);pb.rotation_euler=(0,0,0);pb.scale=(1,1,1)
rig.pose.bones['surprise_mouth'].scale=(.001,.001,.001)
# Shrink only protruding fused paddles back onto the continuous B core envelope.
# Lower feet and the established head/face are untouched.
def smooth(a,b,x):
 t=max(0,min(1,(x-a)/(b-a)));return t*t*(3-2*t)
original=[v.co.copy() for v in body.data.vertices];inv=body.matrix_world.inverted();changed=0
for v in body.data.vertices:
 c=body.matrix_world@v.co;x,y,z=c
 if .48<z<1.77 and abs(x)>.30:
  rhead=.66*math.sqrt(max(0,1-((z-1.65)/.73)**2))
  rtrunk=.44*math.sqrt(max(0,1-((z-.79)/.73)**2))
  # Slight smooth union preserves v2's gentle neck fill.
  rx=(rhead+rtrunk+math.sqrt((rhead-rtrunk)**2+.05**2))/2+.006*math.exp(-((z-1.10)/.24)**2)
  ry=max(.48*math.sqrt(max(0,1-((z-1.65)/.73)**2)),.37*math.sqrt(max(0,1-((z-.79)/.73)**2)))
  cy=.035*(1-smooth(1.10,1.50,z));q=math.sqrt((x/rx)**2+((y-cy)/ry)**2)
  if q>.001:
   blend=smooth(.48,.61,z)*(1-smooth(1.65,1.77,z))*smooth(.30,.43,abs(x))
   f=1+blend*(1/q-1);c.x*=f;c.y=cy+(y-cy)*f;v.co=inv@c;changed+=1
# Remove all paddle influence from the core; preserve head/body/root deformation.
for v in body.data.vertices:
 donated=0
 for name in ['paddle_L','paddle_R']:
  group=body.vertex_groups.get(name)
  if group:
   try:donated+=group.weight(v.index);group.remove([v.index])
   except RuntimeError:pass
 if donated:
  z=(body.matrix_world@v.co).z;headpart=smooth(1.05,1.60,z)
  for target,part in [('body',1-headpart),('head',headpart)]:
   dest=body.vertex_groups[target]
   try:w=dest.weight(v.index)
   except RuntimeError:w=0
   dest.add([v.index],w+donated*part,'REPLACE')
body.data.update();body.name='B | continuous core without fused paddles'
# Repurpose the existing two paddle controls as independently positioned soft arms.
bpy.context.view_layer.objects.active=rig;bpy.ops.object.mode_set(mode='EDIT')
for side,name in [(-1,'paddle_L'),(1,'paddle_R')]:
 b=rig.data.edit_bones[name];b.head=(side*.70,-.035,.98);b.tail=(side*.70,-.035,1.28);b.roll=0;b.parent=rig.data.edit_bones['body']
bpy.ops.object.mode_set(mode='OBJECT')
water=body.data.materials[0]
for side,name in [(-1,'paddle_L'),(1,'paddle_R')]:
 bpy.ops.mesh.primitive_uv_sphere_add(segments=32,ring_count=20,location=(side*.70,-.035,.98));o=bpy.context.object;o.name='B | separate soft arm '+('L' if side<0 else 'R');o.scale=(.145,.145,.25);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 for v in o.data.vertices:v.co.x*=.90+.10*smooth(-.20,.12,v.co.z)
 for f in o.data.polygons:f.use_smooth=True
 o.data.materials.append(water);o.parent=rig;vg=o.vertex_groups.new(name=name);vg.add(list(range(len(o.data.vertices))),1,'REPLACE');m=o.modifiers.new('Independent soft arm skin','ARMATURE');m.object=rig
# Same friendly face; only gesture-specific graphic compression is animated.
for pb in rig.pose.bones:pb.rotation_mode='XYZ'
def reset():
 for p in rig.pose.bones:p.location=(0,0,0);p.rotation_euler=(0,0,0);p.scale=(1,1,1)
 rig.pose.bones['surprise_mouth'].scale=(.001,.001,.001)
def key(f,**changes):
 reset()
 for path,val in changes.items():
  n,prop=path.split('__');setattr(rig.pose.bones[n],prop,val)
 for p in rig.pose.bones:
  for prop in ['location','rotation_euler','scale']:p.keyframe_insert(data_path=prop,frame=f,group=p.name)
def rad(x):return math.radians(x)
def start(n):rig.animation_data_create();rig.animation_data.action=bpy.data.actions.new(n)
start('wave_hello');key(1);key(5,paddle_R__location=(.025,-.045,0),paddle_R__rotation_euler=(0,0,rad(7)))
for f,a in [(11,-22),(16,18),(21,-18),(26,14),(30,-7)]:
 key(f,paddle_R__location=(.25,.48,-.025),paddle_R__rotation_euler=(0,0,rad(a)),head__rotation_euler=(0,rad(-2),rad(-2)),**{'eye_-1__scale':(1,.88,1),'eye_1__scale':(1,.88,1)})
key(36)
start('open_arms');key(1);key(6,paddle_L__location=(.045,.015,.025),paddle_R__location=(-.045,.015,.025),body__scale=(1.015,.985,1.015))
for f,amt in [(13,1),(24,1),(30,.40)]:
 key(f,paddle_L__location=(-.18*amt,.10*amt,.015*amt),paddle_R__location=(.18*amt,.10*amt,.015*amt),paddle_L__rotation_euler=(0,0,rad(62*amt)),paddle_R__rotation_euler=(0,0,rad(-62*amt)),**{'brow_-1__location':(0,.025*amt,0),'brow_1__location':(0,.025*amt,0)})
key(36)
start('hands_gathered');key(1);key(6,paddle_L__location=(-.035,.025,.15),paddle_R__location=(.035,.025,.15));key(9,paddle_L__location=(.025,.09,.57),paddle_R__location=(-.025,.09,.57))
for f,amt in [(14,1),(25,1),(29,.92)]:
 key(f,paddle_L__location=(.51*amt,.13*amt,.61*amt),paddle_R__location=(-.51*amt,.13*amt,.61*amt),paddle_L__rotation_euler=(0,0,rad(-8*amt)),paddle_R__rotation_euler=(0,0,rad(8*amt)),head__rotation_euler=(rad(3*amt),0,0),**{'eye_-1__scale':(1,.94,1),'eye_1__scale':(1,.94,1)})
key(33,paddle_L__location=(.025,.09,.57),paddle_R__location=(-.025,.09,.57));key(36)
for act in bpy.data.actions:
 act.use_fake_user=True
 for fc in act.fcurves:
  for p in fc.keyframe_points:p.interpolation='BEZIER';p.handle_left_type='AUTO_CLAMPED';p.handle_right_type='AUTO_CLAMPED'
rig.animation_data.action=bpy.data.actions['wave_hello'];s.frame_start=1;s.frame_end=36;s.render.fps=12;s.frame_set(1)
s.cycles.samples=48;s.cycles.use_denoising=False;s.render.threads_mode='FIXED';s.render.threads=2;s.render.resolution_x=320;s.render.resolution_y=320
bpy.ops.wm.save_as_mainfile(filepath=P+'/B_separate_arms_v3.blend')
bpy.ops.object.select_all(action='DESELECT')
for o in s.objects:
 if o==rig or o.parent==rig:o.select_set(True)
bpy.context.view_layer.objects.active=rig;bpy.ops.export_scene.gltf(filepath=P+'/B_separate_arms_v3.glb',export_format='GLB',use_selection=True,export_animations=True,export_animation_mode='ACTIONS',export_force_sampling=True,export_apply=False)
json.dump({'source':'B_gesture_rig_v2.blend','body_topology_preserved':True,'core_vertices':len(body.data.vertices),'core_vertices_changed':changed,'max_core_vertex_change':max((v.co-original[i]).length for i,v in enumerate(body.data.vertices)),'arms':'Two separate rounded meshes, each rigid-skinned to its own paddle bone','clips':[a.name for a in bpy.data.actions],'browser_validated':False},open(P+'/build_audit.json','w'),indent=2)
