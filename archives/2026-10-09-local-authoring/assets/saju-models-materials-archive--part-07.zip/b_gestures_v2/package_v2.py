import zipfile,os,json,subprocess
P=os.path.dirname(os.path.abspath(__file__))
files=['B_gesture_rig_v2.blend','B_gesture_rig_v2.glb','README.md','geometry_audit.json','deformation_ground_audit.json','roundtrip_validation.json','refine_geometry.py','render_v2.py','validate_v2.py','validate_glb.py','assemble_v2.py','B_v2_before_after.jpg','B_v2_before.png','B_v2_after.png','B_gestures_v2_preview.mp4','wave_hello.mp4','curious_lean.mp4','startled_recovery.mp4']
with zipfile.ZipFile(P+'/B_gesture_v2_native_bundle.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(P+'/'+f,'B_gestures_v2/'+f)
 z.write(os.path.dirname(P)+'/b_gestures_v1/B_gesture_rig.blend','B_gestures_v2/source/B_gesture_rig_v1.blend')
with zipfile.ZipFile(P+'/B_gesture_v2_native_bundle.zip') as z:print('ZIP_TEST',z.testzip(),'FILES',len(z.namelist()))
print('ZIP_BYTES',os.path.getsize(P+'/B_gesture_v2_native_bundle.zip'))
