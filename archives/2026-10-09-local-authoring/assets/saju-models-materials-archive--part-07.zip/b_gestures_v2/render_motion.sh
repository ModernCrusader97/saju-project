#!/bin/bash
set -e
cd /workspace/scratch/c9f1a9454187
# Short locked batches, two render threads; comparison renders retain their own PNGs.
for frames in '1 4 7 10 13 16' '19 22 25 28 31 34 36'; do
 for clip in wave_hello curious_lean startled_recovery; do
  PROOF_SIZE=320 PROOF_SAMPLES=48 flock /tmp/b_form_render.lock blender -b -t 2 --python b_gestures_v2/render_v2.py -- after "$clip" $frames >> b_gestures_v2/motion_render.log 2>&1
 done
done
