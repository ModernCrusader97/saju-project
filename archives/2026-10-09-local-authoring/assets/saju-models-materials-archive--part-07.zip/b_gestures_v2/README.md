# B spirit v2 — conservative shape and material refinement

This keeps the approved B character, face, height and three existing gesture timings. It is a single refinement, not a new design or a humanoid conversion.

## Changed
- Smoothed the short paddle-to-body transitions and shortened the lowered paddle slightly; no fingers or anatomical joints.
- Filled the neck dent gently so the form reads as one soft bean.
- Replaced the horizontal pedestal/ring profile with two low, connected foot lobes and a shallow central gap.
- Kept the feet grounded during waving and curiosity. The startled clip retains one intentional lift, squash and recovery.
- Reduced the milky coating through a coordinated aqua material: roughness .22, transmission .38, IOR 1.333 and restrained coat .025. No fluid simulation.
- Moved more of the curious lean into the whole body while preserving clip timing and facial identity.

## Files
- B_gesture_rig_v2.blend: editable canonical source, 11-joint rig and three actions.
- B_gesture_rig_v2.glb: portable skinned model and named clips.
- B_v2_before_after.jpg: same camera, lighting, pose and view transform for both versions.
- B_gestures_v2_preview.mp4: compact labeled motion proof, no audio.
- Individual wave_hello / curious_lean / startled_recovery MP4s.
- geometry_audit.json, deformation_ground_audit.json, roundtrip_validation.json: actual geometry, animation and import checks.

## Shared variant contract
The body object remains `B | continuous soft body and small hands`, with all 6,624 vertex indices and mesh topology preserved. Its object transform remains unchanged. Variant materials can be retained while replacing the body mesh with this exact canonical source. Existing source facial meshes are unchanged. The eleven shared bones and three clip names are unchanged.

Foot skinning now includes the root group. Transfer ALL normalized skin groups to surface accents, including root; otherwise accents near the feet may slide during squash. Curves must be converted to meshes before nearest-body weight transfer. Rigid crown/leaf accents may follow the head bone with their world transforms preserved. Full-body vines or flowing surface graphics should deform with the skin. Element-specific upper caps must not fork the common arm/foot silhouette.

## Verification
All 36 frames of each action were evaluated in Blender 4.3.2. Wave and curiosity keep the bottom at z=-.014 within 6e-8; both feet retain equal contact height. The startle has a deliberate .13-unit lift. Every clip returns exactly to its starting body vertex positions. GLB was re-imported and sampled at seven frames per action. Before/after and actual rendered pose proofs were visually inspected. Browser or game-engine validation has not been performed.

CPU renders use two threads and the shared render lock. OpenImageDenoise is unavailable in this Blender build, so the proof is rendered without denoising. Native assets are not restricted to the proof's 320-pixel motion resolution.

The GLB material uses KHR_materials_transmission, KHR_materials_ior and KHR_materials_clearcoat. A target viewer needs those extensions to reproduce the intended watery surface accurately.
