from PIL import Image,ImageDraw,ImageFont
import os,subprocess,json
P=os.path.dirname(os.path.abspath(__file__));font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';f=ImageFont.truetype(font,22);small=ImageFont.truetype(font,16)
can=Image.new('RGB',(1024,636),'#edf2f3');d=ImageDraw.Draw(can);d.text((20,15),'B / BEFORE',font=f,fill='#193c46');d.text((532,15),'B / REFINED',font=f,fill='#193c46')
for x,n in [(0,'before'),(512,'after')]:can.paste(Image.open(P+'/B_v2_'+n+'.png').convert('RGB'),(x,56))
d.text((20,580),'Same camera, lighting and pose.',font=small,fill='#45606a');d.text((532,580),'Softer paddle joins. Low joined foot lobes.',font=small,fill='#45606a');d.text((532,605),'Gentle neck fill and clearer watery material.',font=small,fill='#45606a');can.save(P+'/B_v2_before_after.jpg',quality=96)
clips=['wave_hello','curious_lean','startled_recovery'];frames=[1,4,7,10,13,16,19,22,25,28,31,34,36]
for clip in clips:
 concat=P+'/'+clip+'_concat.txt';files=[f'frames/after/{clip}/{n:03d}.png' for n in frames];dur=[(frames[i+1]-frames[i])/12 for i in range(len(frames)-1)]+[.25]
 open(concat,'w').write(''.join("file '"+p+"'\nduration "+str(t)+'\n' for p,t in zip(files,dur))+"file '"+files[-1]+"'\n")
 subprocess.run(['ffmpeg','-y','-threads','2','-f','concat','-safe','0','-i',concat,'-vf','scale=320:320,fps=12','-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',P+'/'+clip+'.mp4'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
filters=[]
for i,label in enumerate(['wave','curious','startled']):filters.append(f"[{i}:v]pad=iw:ih+38:0:38:color=0xedf2f3,drawtext=fontfile={font}:text='{label}':x=10:y=10:fontsize=15:fontcolor=0x193c46[v{i}]")
filters.append('[v0][v1][v2]hstack=inputs=3[out]');args=['ffmpeg','-y','-threads','2']
for clip in clips:args+=['-i',P+'/'+clip+'.mp4']
args+=['-filter_complex',';'.join(filters),'-map','[out]','-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',P+'/B_gestures_v2_preview.mp4'];subprocess.run(args,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
print('V2_PROOF_ASSEMBLED')
