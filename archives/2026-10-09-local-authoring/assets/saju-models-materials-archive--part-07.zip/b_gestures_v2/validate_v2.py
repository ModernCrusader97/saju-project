import bpy,os,json,math
P=os.path.dirname(os.path.abspath(__file__));bpy.ops.wm.open_mainfile(filepath=P+'/B_gesture_rig_v2.blend');s=bpy.context.scene;rig=bpy.data.objects['B_shared_gesture_rig'];body=bpy.data.objects['B | continuous soft body and small hands'];out=[]
for clip in ['wave_hello','curious_lean','startled_recovery']:
 rig.animation_data.action=bpy.data.actions[clip];frames=[];neutral=[]
 for frame in range(1,37):
  s.frame_set(frame);dg=bpy.context.evaluated_depsgraph_get();ev=body.evaluated_get(dg);m=ev.to_mesh();vs=[ev.matrix_world@v.co for v in m.vertices];ev.to_mesh_clear();assert all(math.isfinite(c) for v in vs for c in v)
  low=min(v.z for v in vs);frames.append({'frame':frame,'bottom_z':low,'left_bottom_z':min(v.z for v in vs if v.x<-.08),'right_bottom_z':min(v.z for v in vs if v.x>.08)})
  if frame in [1,36]:neutral.append(vs)
 out.append({'clip':clip,'frames':frames,'neutral_return_max_vertex_error':max((a-b).length for a,b in zip(*neutral))})
weights=[sum(e.weight for e in v.groups) for v in body.data.vertices]
json.dump({'all_36_frames_evaluated':True,'max_weight_sum_error':max(abs(v-1) for v in weights),'clips':out,'browser_validated':False},open(P+'/deformation_ground_audit.json','w'),indent=2)
print('DEFORMATION_VALIDATED',[(v['clip'],v['neutral_return_max_vertex_error'],min(f['bottom_z'] for f in v['frames']),max(f['bottom_z'] for f in v['frames'])) for v in out])
