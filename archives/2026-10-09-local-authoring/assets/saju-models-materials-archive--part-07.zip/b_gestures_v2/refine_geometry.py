import bpy,math,os,json
from mathutils import Vector
P=os.path.dirname(os.path.abspath(__file__))
source=P+'/source/B_gesture_rig_v1.blend'
if not os.path.exists(source):source=os.path.dirname(P)+'/b_gestures_v1/B_gesture_rig.blend'
bpy.ops.wm.open_mainfile(filepath=source)
s=bpy.context.scene;rig=bpy.data.objects['B_shared_gesture_rig'];s.frame_set(1)
body=bpy.data.objects['B | continuous soft body and small hands'];original=[v.co.copy() for v in body.data.vertices]
def smooth(a,b,x):
 t=max(0,min(1,(x-a)/(b-a)));return t*t*(3-2*t)
def g(x,c,w):return math.exp(-((x-c)/w)**2)
inv=body.matrix_world.inverted()
for v in body.data.vertices:
 c=body.matrix_world@v.co;x,y,z=c;cy=y-.035
 # Small neck fill keeps B one soft bean, without changing face/head proportions.
 neck=g(z,1.15,.22)*(1-smooth(.40,.60,abs(x)))
 x*=1+.075*neck;y*=1+.040*neck;cy=y-.035
 if z<.67:
  blend=1-smooth(.52,.67,z)
  rho=math.sqrt((x/.425)**2+(cy/.335)**2)
  if rho>.015:
   cap=math.sqrt(max(0,1-((.30-z)/.32)**2)) if z<.30 else 1
   target=.99*cap
   fac=1+blend*(target/max(rho,.015)-1)
   x*=fac;cy*=fac;y=cy+.035
  low=1-smooth(.20,.47,z)
  z+=low*(.16*g(x,0,.105)-.072*(g(x,-.23,.13)+g(x,.23,.13)))
  # Soft front cleft separates two foot lobes without a shoe, toe, or leg joint.
  y+=.090*g(x,0,.10)*(1-smooth(.23,.40,z))*smooth(.02,.22,-cy)
 # Keep the lowered paddle short and avoid its bulbous bottom.
 if x<-.36 and .40<z<1.22:
  w=smooth(.36,.64,-x)*(1-smooth(1.02,1.22,z))
  x+=.035*w;z+=.035*w*(1-smooth(.67,.90,z))
 if x>.47 and .90<z<1.58:
  w=smooth(.47,.80,x)*(1-smooth(1.45,1.58,z));x+=.025*w
 v.co=inv@Vector((x,y,z))
# Local surface relaxation at paddle-body joins only; no broad smoothing of head/face.
neighbors=[set() for _ in body.data.vertices]
for e in body.data.edges:
 a,b=e.vertices;neighbors[a].add(b);neighbors[b].add(a)
for iteration in range(5):
 old=[v.co.copy() for v in body.data.vertices]
 for i,v in enumerate(body.data.vertices):
  c=body.matrix_world@old[i];w=max(g(c.x,-.39,.16)*g(c.z,.84,.27),g(c.x,.46,.15)*g(c.z,1.18,.21))
  if neighbors[i] and w>.005:
   mean=sum((old[n] for n in neighbors[i]),Vector())/len(neighbors[i]);v.co=old[i].lerp(mean,.38*w)
# Same grounded neutral bottom as v1. Adjustment fades out before the abdomen.
lowest=min((body.matrix_world@v.co).z for v in body.data.vertices);floor=-.014
for v in body.data.vertices:
 c=body.matrix_world@v.co;c.z+=(floor-lowest)*(1-smooth(.25,.58,c.z));v.co=inv@c
body.data.update()
# Existing paddle/head weights are kept; foot weights are anchored to root for stable contact.
rootgroup=body.vertex_groups.get('root') or body.vertex_groups.new(name='root')
for v in body.data.vertices:
 c=body.matrix_world@v.co;anchor=1-smooth(.08,.42,c.z)
 if anchor>0:
  saved=[(body.vertex_groups[e.group],e.weight) for e in v.groups]
  for vg,w in saved:vg.add([v.index],w*(1-anchor),'REPLACE')
  rootgroup.add([v.index],anchor,'REPLACE')
# Curiosity bends the bean as a whole rather than swiveling a separate head.
for fc in bpy.data.actions['curious_lean'].fcurves:
 if fc.data_path=='pose.bones["body"].rotation_euler' and fc.array_index==2:
  for kp in fc.keyframe_points:kp.co.y*=1.5;kp.handle_left.y*=1.5;kp.handle_right.y*=1.5
 if fc.data_path=='pose.bones["head"].rotation_euler' and fc.array_index==2:
  for kp in fc.keyframe_points:kp.co.y*=.5;kp.handle_left.y*=.5;kp.handle_right.y*=.5
# Ground the non-jump gestures and explicitly preserve the startle flight.
for act in bpy.data.actions:
 if act.name not in ['wave_hello','curious_lean','startled_recovery']:continue
 rig.animation_data.action=act
 for frame in range(1,37):
  s.frame_set(frame);dg=bpy.context.evaluated_depsgraph_get();ev=body.evaluated_get(dg);m=ev.to_mesh();low=min((ev.matrix_world@v.co).z for v in m.vertices);ev.to_mesh_clear()
  # root local Y is world Z; neutral contact maintained, existing flight retained.
  if act.name=='startled_recovery':
   jump=.13*math.exp(-((frame-10)/3.0)**2) if 6<frame<16 else 0
  else:jump=0
  pb=rig.pose.bones['root'];pb.location.y+=floor+jump-low;pb.keyframe_insert(data_path='location',frame=frame,group='root')
rig.animation_data.action=bpy.data.actions['wave_hello'];s.frame_set(1)
# Shared pale-aqua polish, coordinated with the material worker.
water=body.data.materials[0];p=water.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.12,.40,.52,1);p.inputs['Roughness'].default_value=.22;p.inputs['Transmission Weight'].default_value=.38;p.inputs['IOR'].default_value=1.333;p.inputs['Coat Weight'].default_value=.025;p.inputs['Subsurface Weight'].default_value=0;water.diffuse_color=(.12,.40,.52,1)
s.world.node_tree.nodes.get('Background').inputs[1].default_value=.45
bpy.data.objects['Broad soft key'].data.energy=450;bpy.data.objects['Broad soft key'].data.size=3
bpy.data.objects['Pale rim'].data.energy=350;bpy.data.objects['Pale rim'].data.size=3
bpy.data.objects['Quiet face fill'].data.energy=90;bpy.data.objects['Quiet face fill'].visible_glossy=False
s.view_settings.look='AgX - Medium High Contrast'
s.cycles.samples=48;s.cycles.use_denoising=False;s.render.threads_mode='FIXED';s.render.threads=2;s.render.resolution_x=512;s.render.resolution_y=512
bpy.ops.wm.save_as_mainfile(filepath=P+'/B_gesture_rig_v2.blend')
bpy.ops.object.select_all(action='DESELECT')
for o in s.objects:
 if o==rig or o.parent==rig:o.select_set(True)
bpy.context.view_layer.objects.active=rig
bpy.ops.export_scene.gltf(filepath=P+'/B_gesture_rig_v2.glb',export_format='GLB',use_selection=True,export_animations=True,export_animation_mode='ACTIONS',export_force_sampling=True,export_apply=False)
audit={'source':'b_gestures_v1/B_gesture_rig.blend','body_object':body.name,'vertices':len(body.data.vertices),'topology_preserved':True,'max_vertex_displacement':max((v.co-original[i]).length for i,v in enumerate(body.data.vertices)),'face_unchanged':True,'new_foot_root_weights':True,'neutral_ground_z':floor,'browser_validated':False}
json.dump(audit,open(P+'/geometry_audit.json','w'),indent=2);print('V2_GEOMETRY',audit)
