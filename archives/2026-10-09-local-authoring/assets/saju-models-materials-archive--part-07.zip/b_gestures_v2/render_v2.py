import bpy,os,sys,shutil
P=os.path.dirname(os.path.abspath(__file__));args=sys.argv[sys.argv.index('--')+1:]
version=args[0];clip=args[1];frames=[int(f) for f in args[2:]]
source=P+'/B_gesture_rig_v2.blend' if version=='after' else os.path.dirname(P)+'/b_gestures_v1/B_gesture_rig.blend'
if version=='before' and os.path.exists(P+'/source/B_gesture_rig_v1.blend'):source=P+'/source/B_gesture_rig_v1.blend'
bpy.ops.wm.open_mainfile(filepath=source);s=bpy.context.scene;rig=bpy.data.objects['B_shared_gesture_rig'];rig.animation_data.action=bpy.data.actions[clip]
# Identical studio, camera and view transform on before and after.
s.world.node_tree.nodes.get('Background').inputs[1].default_value=.45
bpy.data.objects['Broad soft key'].data.energy=450;bpy.data.objects['Broad soft key'].data.size=3
bpy.data.objects['Pale rim'].data.energy=350;bpy.data.objects['Pale rim'].data.size=3
bpy.data.objects['Quiet face fill'].data.energy=90;bpy.data.objects['Quiet face fill'].visible_glossy=False
s.view_settings.look='AgX - Medium High Contrast'
s.cycles.samples=int(os.environ.get('PROOF_SAMPLES','48'));s.cycles.use_denoising=False;s.render.resolution_x=int(os.environ.get('PROOF_SIZE','512'));s.render.resolution_y=s.render.resolution_x;s.render.threads_mode='FIXED';s.render.threads=2
os.makedirs(P+'/frames/'+version+'/'+clip,exist_ok=True)
for f in frames:
 s.frame_set(f);s.render.filepath=P+'/frames/'+version+'/'+clip+'/'+str(f).zfill(3)+'.png';bpy.ops.render.render(write_still=True)
 if s.render.resolution_x==512 and clip=='wave_hello' and f==1:shutil.copyfile(s.render.filepath,P+'/B_v2_'+version+'.png')
