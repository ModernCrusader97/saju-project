from PIL import Image,ImageDraw,ImageFont
import os,json,struct
P=os.path.dirname(os.path.abspath(__file__));OLD=os.path.dirname(P)+'/b_ten_stems_v1';font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
names=['01_Jia','02_Yi','03_Bing','04_Ding','05_Wu','06_Ji','07_Geng','08_Xin','09_Ren','10_Gui'];labels=['甲 갑 · Bark','乙 을 · Woven vines','丙 병 · Flowing flame','丁 정 · Charcoal / embers','戊 무 · Earth strata','己 기 · Coloured glass','庚 경 · Satin steel','辛 신 · Mirror silver','壬 임 · Water flow','癸 계 · Condensation'];order=[0,2,4,6,8,1,3,5,7,9]
def grid(size,out):
 margin=24 if size>200 else 10;head=80 if size>200 else 34;labelh=48 if size>200 else 30
 im=Image.new('RGB',(size*5+margin*2,head+2*(size+labelh)+margin),'#edf2f0');d=ImageDraw.Draw(im)
 d.text((margin,10),'B v2 · 10천간 | 팔·발 연결과 재질 정리',font=ImageFont.truetype(font,29 if size>200 else 13),fill='#233a3c')
 if size>200:d.text((margin,50),'Shared B v2 body, pose, camera and lighting · Actual 3D renders · One pair per column',font=ImageFont.truetype(font,18),fill='#566366')
 for cell,idx in enumerate(order):
  row,col=divmod(cell,5);x=margin+col*size;y=head+row*(size+labelh);tile=Image.open(P+'/'+names[idx]+'.png').convert('RGB').resize((size,size),Image.Resampling.LANCZOS);im.paste(tile,(x,y));d.text((x+6,y+size+6),labels[idx],font=ImageFont.truetype(font,18 if size>200 else 9),fill='#233a3c')
 im.save(P+'/'+out)
grid(384,'B_v2_ten_stems_comparison.png');grid(128,'B_v2_ten_stems_128px.png')
size=400;head=70;rowh=440;im=Image.new('RGB',(1200,head+rowh*2),'#edf2f0');d=ImageDraw.Draw(im);d.text((16,10),'B v1 → v2 · 덩굴 / 불 / 물',font=ImageFont.truetype(font,28),fill='#233a3c');d.text((16,45),'Top: v1   Bottom: v2 · Same camera and studio lighting',font=ImageFont.truetype(font,17),fill='#566366')
for row,folder in enumerate([OLD,P]):
 for col,idx in enumerate([1,2,8]):
  tile=Image.open(folder+'/'+names[idx]+'.png').convert('RGB').resize((size,size),Image.Resampling.LANCZOS);y=head+row*rowh;im.paste(tile,(col*size,y));d.text((col*size+12,y+size+6),('v1' if row==0 else 'v2')+' · '+labels[idx],font=ImageFont.truetype(font,18),fill='#233a3c')
im.save(P+'/B_v1_v2_priority_comparison.png')
