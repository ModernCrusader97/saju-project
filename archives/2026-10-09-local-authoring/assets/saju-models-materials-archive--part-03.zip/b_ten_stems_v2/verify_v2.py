import bpy,os,glob,json,math,hashlib
from mathutils import Vector
P=os.path.dirname(os.path.abspath(__file__));source=os.path.dirname(P)+'/b_gestures_v2/B_gesture_rig_v2.blend';bodyname='B | continuous soft body and small hands'
bpy.ops.wm.open_mainfile(filepath=source);ref=bpy.data.objects[bodyname];refco=[v.co.copy() for v in ref.data.vertices];locked=[v.index for v in ref.data.vertices if (ref.matrix_world@v.co).z<=2.0]
out=[]
for f in sorted(glob.glob(P+'/*.blend')):
 bpy.ops.wm.open_mainfile(filepath=f);body=bpy.data.objects[bodyname];rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');s=bpy.context.scene
 delta=max((body.data.vertices[i].co-refco[i]).length for i in locked);actions=[a for a in bpy.data.actions if a.name in ['wave_hello','curious_lean','startled_recovery']]
 clips=[]
 for a in actions:
  rig.animation_data.action=a;zs=[];finite=True
  for frame in [1,6,10,16,23,29,36]:
   s.frame_set(frame);dg=bpy.context.evaluated_depsgraph_get();dg.update();points=[]
   for o in s.objects:
    if o.type=='MESH' and o.name!='Plane':
     e=o.evaluated_get(dg);points.extend(e.matrix_world@Vector(c) for c in e.bound_box)
   vals=[c for p in points for c in p];finite=finite and all(math.isfinite(c) for c in vals);zs.append([frame,min(p.z for p in points),max(p.z for p in points)])
  clips.append({'name':a.name,'frames_tested':[1,6,10,16,23,29,36],'finite':finite,'z_bounds':zs})
 out.append({'file':os.path.basename(f),'body_vertices':len(body.data.vertices),'shared_body_below_z2_max_delta':delta,'lower_body_exact':delta<1e-7,'clips':clips})
json.dump({'source':'B_gesture_rig_v2.blend','native_validation':out,'all_lower_body_exact':all(v['lower_body_exact'] for v in out),'all_animation_samples_finite':all(c['finite'] for v in out for c in v['clips'])},open(P+'/native_v2_verification.json','w'),indent=2)
# Independently import every exported glTF, verify three clips and sampled deformed bounds.
imports=[]
for f in sorted(glob.glob(P+'/*.glb')):
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=f);s=bpy.context.scene;rig=next((o for o in s.objects if o.type=='ARMATURE'),None);clips=[]
 if rig:
  # glTF importer may place one action in NLA; evaluate each action explicitly.
  if rig.animation_data:
   for tr in rig.animation_data.nla_tracks:tr.mute=True
  for a in bpy.data.actions:
   rig.animation_data.action=a;frames=[int(a.frame_range[0]),int(sum(a.frame_range)/2),int(a.frame_range[1])];finite=True
   for fr in frames:
    s.frame_set(fr);dg=bpy.context.evaluated_depsgraph_get();dg.update()
    for o in s.objects:
     if o.type=='MESH':
      e=o.evaluated_get(dg);finite=finite and all(math.isfinite(v) for p in e.bound_box for v in e.matrix_world@Vector(p))
   clips.append({'name':a.name,'finite':finite})
 imports.append({'file':os.path.basename(f),'armature':rig is not None,'action_count':len(clips),'clips':clips})
json.dump({'glb_roundtrip':imports,'all_one_rig_three_actions':all(v['armature'] and v['action_count']==3 for v in imports),'all_animation_samples_finite':all(c['finite'] for v in imports for c in v['clips'])},open(P+'/glb_v2_verification.json','w'),indent=2)
print('VALIDATION_FINISHED',len(out),len(imports),flush=True)
