import os,json,glob,struct,zipfile
P=os.path.dirname(os.path.abspath(__file__));names=['01_Jia','02_Yi','03_Bing','04_Ding','05_Wu','06_Ji','07_Geng','08_Xin','09_Ren','10_Gui'];aud=[]
for n in names:
 b=open(P+'/'+n+'.glb','rb').read();d=json.loads(b[20:20+struct.unpack_from('<I',b,12)[0]])
 aud.append({'name':n,'bytes':len(b),'triangles':sum(d['accessors'][p['indices']]['count']//3 for m in d['meshes'] for p in m['primitives']),'exported_vertices':sum(d['accessors'][p['attributes']['POSITION']]['count'] for m in d['meshes'] for p in m['primitives']),'skins':len(d.get('skins',[])),'animations':[a['name'] for a in d.get('animations',[])],'images':len(d.get('images',[])),'extensions':d.get('extensionsUsed',[])})
audit={'main_blend_count':10,'main_glb_count':10,'main_render_count':10,'optional_jade_included':False,'variants':aud,'total_triangles':sum(a['triangles'] for a in aud),'total_exported_vertices':sum(a['exported_vertices'] for a in aud),'renderer':'Cycles CPU 2 threads, 512x512, 128 samples, same B v1 comparison camera and corrected studio','pose_checks':'GLB reimported Yi curious_lean and Bing wave_hello rendered at400x400/48spp','rigging':'Canonical B v2 body/face rig, source root weights retained; nearest4-body-vertex interpolated and top4-normalized accent weights','limits':['Comparison camera is for stills; high startled flame/branch poses need wider animation framing','No engine/browser runtime performance validation','No all-transition/collision validation','Vine geometry high-detail and not LOD optimized','Transparency/reflections depend on glTF extensions/environment','Artistic elemental themes, not scientific saju claims']}
json.dump(audit,open(P+'/delivery_v2_audit.json','w'),indent=2)
files=[P+'/'+n+'.'+ext for n in names for ext in ['blend','glb','png']]
files += [P+'/'+n for n in ['B_v2_ten_stems_comparison.png','B_v2_ten_stems_128px.png','B_v1_v2_priority_comparison.png','02_Yi_GLB_curious_lean.png','03_Bing_GLB_wave_hello.png','README_ko.txt','native_v2_verification.json','glb_v2_verification.json','delivery_v2_audit.json']]
with zipfile.ZipFile(P+'/B_v2_ten_stems_delivery.zip','w',zipfile.ZIP_DEFLATED,6) as z:
 for f in files:assert os.path.isfile(f),f;z.write(f,os.path.basename(f))
with zipfile.ZipFile(P+'/B_v2_ten_stems_delivery.zip') as z:assert z.testzip() is None
print('DELIVERY',len(files),os.path.getsize(P+'/B_v2_ten_stems_delivery.zip'),audit['total_triangles'],flush=True)
