import bpy,os
s=bpy.context.scene;s.frame_set(1)
s.render.resolution_x=s.render.resolution_y=int(os.environ.get('SIZE','512'));s.cycles.samples=int(os.environ.get('SAMPLES','128'));s.cycles.use_denoising=False;s.render.threads_mode='FIXED';s.render.threads=2
s.world.node_tree.nodes.get('Background').inputs['Strength'].default_value=.45
bpy.data.objects['Broad soft key'].data.size=3;bpy.data.objects['Pale rim'].data.energy=350;bpy.data.objects['Quiet face fill'].visible_glossy=False
s.view_settings.look='AgX - Medium High Contrast';s.camera.data.ortho_scale=3.15
# Bake the sole unsupported varying emission input into an explicit glTF texture.
# Vertex colour remains the supported base-colour source; emission gets its own UV image.
body=bpy.data.objects.get('B | continuous soft body and small hands')
if os.path.basename(bpy.data.filepath).startswith('03_Bing'):
 m=body.data.materials[0];nt=m.node_tree;pp=nt.nodes.get('Principled BSDF')
 if pp.inputs['Emission Color'].is_linked and pp.inputs['Emission Color'].links[0].from_node.type=='VERTEX_COLOR':
  vc=pp.inputs['Emission Color'].links[0].from_node
  bpy.ops.object.select_all(action='DESELECT');body.select_set(True);bpy.context.view_layer.objects.active=body
  bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.02);bpy.ops.object.mode_set(mode='OBJECT')
  im=bpy.data.images.new('Bing flowing emission baked',512,512);tex=nt.nodes.new('ShaderNodeTexImage');tex.image=im;nt.nodes.active=tex
  out=next(n for n in nt.nodes if n.type=='OUTPUT_MATERIAL');em=nt.nodes.new('ShaderNodeEmission');nt.links.new(vc.outputs['Color'],em.inputs['Color']);nt.links.new(em.outputs[0],out.inputs['Surface'])
  bpy.ops.object.bake(type='EMIT',margin=8);im.pack();nt.links.new(pp.outputs['BSDF'],out.inputs['Surface']);nt.nodes.remove(em);nt.links.new(tex.outputs['Color'],pp.inputs['Emission Color'])
  bpy.ops.object.select_all(action='DESELECT')
  for o in s.objects:
   if o.type in ['MESH','EMPTY','ARMATURE'] and o.name!='Plane':o.select_set(True)
  bpy.ops.export_scene.gltf(filepath=bpy.data.filepath.replace('.blend','.glb'),export_format='GLB',use_selection=True,export_apply=False,export_attributes=True,export_animations=True,export_animation_mode='ACTIONS',export_force_sampling=True)
s.render.filepath=bpy.data.filepath.replace('.blend','.png')
bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath);bpy.ops.render.render(write_still=True)
