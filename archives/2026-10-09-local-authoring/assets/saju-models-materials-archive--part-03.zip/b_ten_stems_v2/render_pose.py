import bpy,os,sys
P=os.path.dirname(os.path.abspath(__file__));args=sys.argv[sys.argv.index('--')+1:];name,clip,frame=args[0],args[1],float(args[2])
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=P+'/'+name+'.glb');s=bpy.context.scene;rig=next(o for o in s.objects if o.type=='ARMATURE')
for tr in rig.animation_data.nla_tracks:tr.mute=True
act=next(a for a in bpy.data.actions if clip in a.name);rig.animation_data.action=act
lo,hi=act.frame_range;s.frame_set(round(lo+(frame-1)/35*(hi-lo)))
with bpy.data.libraries.load(P+'/'+name+'.blend',link=False) as (src,dst):
 dst.objects=[n for n in src.objects if n in ['Plane','Broad soft key','Pale rim','Quiet face fill','Shared comparison camera']];dst.worlds=[src.worlds[0]]
for o in dst.objects:
 if o:o.animation_data_clear();s.collection.objects.link(o)
s.world=dst.worlds[0];s.camera=bpy.data.objects['Shared comparison camera'];s.camera.data.ortho_scale=3.15;s.render.engine='CYCLES';s.cycles.samples=48;s.cycles.use_denoising=False;s.render.threads_mode='FIXED';s.render.threads=2;s.render.resolution_x=s.render.resolution_y=400;s.render.resolution_percentage=100;s.view_settings.view_transform='AgX';s.view_settings.look='AgX - Medium High Contrast';s.render.filepath=P+'/'+name+'_GLB_'+clip+'.png';bpy.ops.render.render(write_still=True)
