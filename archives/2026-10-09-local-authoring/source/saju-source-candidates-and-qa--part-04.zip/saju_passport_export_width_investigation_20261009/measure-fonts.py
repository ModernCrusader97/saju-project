"""Independent, offline FreeType/Pillow checks of the fonts used by reproduce.mjs."""
from pathlib import Path
from hashlib import sha256
import json
import PIL
from PIL import ImageFont, features
from fontTools.ttLib import TTCollection
here = Path(__file__).resolve().parent
results = json.loads((here / 'evidence/results.json').read_text())
output = {'engine': f'Pillow {PIL.__version__}', 'freeType': features.version_module('freetype2'),
          'purpose': 'Independent advance metrics and glyph coverage; not browser font resolution', 'fonts': []}
for font_record in results['fonts']:
    p = Path(font_record['path'])
    assert sha256(p.read_bytes()).hexdigest() == font_record['sha256']
    collection = TTCollection(str(p), lazy=True)
    candidates = [(i, f) for i, f in enumerate(collection.fonts) if f['name'].getDebugName(1) == font_record['family']]
    assert len(candidates) == 1, candidates
    index, face = candidates[0]
    font = ImageFont.truetype(str(p), size=72, index=index)
    cmap = face.getBestCmap()
    data = {'family': font_record['family'], 'path': str(p), 'sha256': font_record['sha256'], 'collectionIndex': index,
            'unitsPerEm': face['head'].unitsPerEm, 'samples': []}
    for row in results['results']:
        text = row['commands']['title']['args'][0]
        missing = sorted({c for c in text if ord(c) not in cmap})
        assert not missing, (font_record['family'], row['id'], missing)
        width = font.getlength(text)
        cpu_width = next(m['width'] for m in row['measured'] if font_record['family'] in m['font'])
        data['samples'].append({'id': row['id'], 'text': text, 'pillowAdvance': width,
                                'cpuCanvasAdvance': cpu_width, 'absoluteDifferencePx': abs(width-cpu_width),
                                'missingGlyphs': missing})
    output['fonts'].append(data)
output['maxAdvanceDifferencePx'] = max(s['absoluteDifferencePx'] for f in output['fonts'] for s in f['samples'])
assert output['maxAdvanceDifferencePx'] < 1, 'Investigate differing shaping/registration before trusting metrics'
(here / 'evidence/independent-font-metrics.json').write_text(json.dumps(output, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'engine': output['engine'], 'fontFamilies': [f['family'] for f in output['fonts']],
                  'samplesChecked': sum(len(f['samples']) for f in output['fonts']),
                  'missingGlyphs': 0, 'maxAdvanceDifferencePx': output['maxAdvanceDifferencePx']}, indent=2))
