  const handleDownloadStoryCard = async () => {
    setDownloading(true);
    try {
      const canvas = document.createElement("canvas");
      canvas.width = 1080;
      canvas.height = 1920;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      // 1. 우주 배경 그라데이션
      const bgGrad = ctx.createLinearGradient(0, 0, 0, 1920);
      bgGrad.addColorStop(0, "#020617");
      bgGrad.addColorStop(0.3, "#0F172A");
      bgGrad.addColorStop(0.7, "#1E1B4B");
      bgGrad.addColorStop(1, "#020617");
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, 1080, 1920);

      // 별빛 파티클
      ctx.fillStyle = "rgba(255, 255, 255, 0.7)";
      for (let i = 0; i < 180; i++) {
        const x = Math.random() * 1080;
        const y = Math.random() * 1920;
        const r = Math.random() * 2.2 + 0.5;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
      }

      // 2. 상단 헤더
      ctx.fillStyle = "#E6C875";
      ctx.font = "bold 34px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("COSMIC SAJU PASSPORT · 우주 여권", 540, 150);

      ctx.fillStyle = "#94A3B8";
      ctx.font = "24px monospace";
      ctx.fillText("HYPER3D GALAXY EXPLORATION ID", 540, 195);

      // 3. 카드 내부 프레임 (골드 테두리)
      ctx.strokeStyle = "rgba(230, 200, 117, 0.4)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.roundRect(80, 240, 920, 1500, 48);
      ctx.stroke();

      // 4. 이름 및 사주 간지
      ctx.fillStyle = "#FFFFFF";
      ctx.font = "bold 72px serif";
      ctx.fillText(`${person.name}님의 우주 정령`, 540, 360);

      ctx.fillStyle = "#F59E0B";
      ctx.font = "bold 38px sans-serif";
      ctx.fillText(`[${dayKey}] 일주 · ${spirit.name}`, 540, 430);

      // 5. 3D 행성 / 샌드맨 정령 샷 (있을 시 렌더링)
      if (planetSnapshotUrl) {
        const img = new Image();
        img.src = planetSnapshotUrl;
        await new Promise((res) => (img.onload = res));
        ctx.save();
        ctx.beginPath();
        ctx.arc(540, 800, 300, 0, Math.PI * 2);
        ctx.clip();
        ctx.drawImage(img, 240, 500, 600, 600);
        ctx.restore();

        ctx.strokeStyle = "#F59E0B";
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.arc(540, 800, 305, 0, Math.PI * 2);
        ctx.stroke();
      } else {
        // 대체 비주얼 원
        ctx.fillStyle = spirit.primaryColor;
        ctx.beginPath();
        ctx.arc(540, 800, 260, 0, Math.PI * 2);
        ctx.fill();
      }

      // 6. 종족 칭호 & 설명
      ctx.fillStyle = "#E2E8F0";
      ctx.font = "bold 42px sans-serif";
      ctx.fillText(spirit.speciesTitle, 540, 1200);

      ctx.fillStyle = "#94A3B8";
      ctx.font = "28px sans-serif";
      const wrapText = (text        , x        , y        , maxWidth        ) => {
        const words = text.split(" ");
        let line = "";
        for (let n = 0; n < words.length; n++) {
          const testLine = line + words[n] + " ";
          const metrics = ctx.measureText(testLine);
          if (metrics.width > maxWidth && n > 0) {
            ctx.fillText(line, x, y);
            line = words[n] + " ";
            y += 44;
          } else {
            line = testLine;
          }
        }
        ctx.fillText(line, x, y);
      };
      wrapText(spirit.conceptDesc, 540, 1270, 780);

      // 7. 성격 태그 3종 캡슐
      let tagX = 220;
      spirit.personalityTraits.forEach((t) => {
        ctx.fillStyle = "rgba(255, 255, 255, 0.12)";
        ctx.beginPath();
        ctx.roundRect(tagX, 1420, 200, 64, 32);
        ctx.fill();

        ctx.fillStyle = "#FDE68A";
        ctx.font = "bold 26px sans-serif";
        ctx.fillText(`#${t}`, tagX + 100, 1462);
        tagX += 230;
      });

      // 8. 하단 바이럴 푸터
      ctx.fillStyle = "#E6C875";
      ctx.font = "bold 32px sans-serif";
      ctx.fillText("🚀 나의 나선은하로 너의 행성을 착륙시켜줘!", 540, 1590);

      ctx.fillStyle = "#64748B";
      ctx.font = "24px monospace";
      ctx.fillText("우리은하 인연망 · saju-galaxy.app", 540, 1650);

      // 9. 이미지 다운로드 트리거
      const dataUrl = canvas.toDataURL("image/png");
      const a = document.createElement("a");
      a.href = dataUrl;
      a.download = `우주여권_${person.name}_${dayKey}.png`;
      a.click();
    } catch {
      alert("스토리 카드 생성 중 오류가 발생했습니다.");
    } finally {
      setDownloading(false);
    }
  };
