// The 920px frame keeps a 24px interior gutter on each side.
const TITLE_WIDTH = 872;
const MIN_FONT_SIZE = 36;
const TITLE_SUFFIX = "님의 우주 정령";
type TitleContext = Pick<CanvasRenderingContext2D, "font" | "measureText" | "fillText">;

/** Draw one centered title; only its display may be elided, never the saved name.
 * The caller retains its existing centered text alignment and fill style.
 */
export function drawPassportTitle(ctx: TitleContext, name: string): void {
  const fullTitle = `${name}${TITLE_SUFFIX}`;
  const fits = (text: string) => {
    const metrics = ctx.measureText(text);
    // Include asymmetric ink overhang where the Canvas implementation reports it.
    return Math.max(
      metrics.width,
      (metrics.actualBoundingBoxLeft || 0) * 2,
      (metrics.actualBoundingBoxRight || 0) * 2,
    ) <= TITLE_WIDTH;
  };

  for (let size = 72; size >= MIN_FONT_SIZE; size--) {
    ctx.font = `bold ${size}px serif`;
    if (fits(fullTitle)) {
      ctx.fillText(fullTitle, 540, 360);
      return;
    }
  }

  const tail = `…${TITLE_SUFFIX}`;
  if (!fits(tail)) {
    // Extremely wide fallback fonts may not leave room even for the fixed suffix.
    ctx.fillText(fits("…") ? "…" : "", 540, 360);
    return;
  }

  let prefix = "";
  if (typeof Intl !== "undefined" && typeof Intl.Segmenter === "function") {
    const segmenter = new Intl.Segmenter("ko", { granularity: "grapheme" });
    for (const { segment } of segmenter.segment(name)) {
      const next = prefix + segment;
      if (!fits(`${next}${tail}`)) break;
      prefix = next;
    }
  }
  // Without a grapheme segmenter, elide the whole overflowing name rather than
  // approximate Unicode boundaries. Short/fitting names were already retained.
  ctx.fillText(`${prefix}${tail}`, 540, 360);
}
