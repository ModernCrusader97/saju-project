/** Read-only source audit. Run with installed Node >= 24 and @napi-rs/canvas. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import { createRequire, stripTypeScriptTypes } from 'node:module';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const out = path.join(here, 'evidence');
fs.mkdirSync(out, { recursive: true });
const require = createRequire(import.meta.url);
const { createCanvas, GlobalFonts } = require('@napi-rs/canvas');
const sha256 = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const provenance = JSON.parse(fs.readFileSync(path.join(here, 'source-before.json'), 'utf8'));
for (const file of provenance.files) {
  assert.equal(sha256(fs.readFileSync(path.join(here, 'snapshots', file.path))), file.sha256);
}
const source = fs.readFileSync(path.join(here, 'snapshots/components/planet/CosmicPassportModal.tsx'), 'utf8');
const start = source.indexOf('  const handleDownloadStoryCard = async () => {');
const end = source.indexOf('\n\n  return (', start);
assert(start > 0 && end > start);
const exportTs = source.slice(start, end);
const exportJs = stripTypeScriptTypes(exportTs, { mode: 'strip' });
fs.writeFileSync(path.join(out, 'extracted-export.ts'), exportTs + '\n');
fs.writeFileSync(path.join(out, 'extracted-export.js'), exportJs + '\n');

// Evaluate the actual solar-input parser; imports are isolated explicitly.
const inputTs = fs.readFileSync(path.join(here, 'snapshots/lib/saju/input.ts'), 'utf8');
const errorTs = fs.readFileSync(path.join(here, 'snapshots/lib/saju/input-error.ts'), 'utf8');
const moduleBody = code => stripTypeScriptTypes(code, { mode: 'transform' })
  .replace(/^import .*?;\n/gm, '').replace(/^export \{.*?\}.*?;\n/gm, '').replace(/^export /gm, '');
const parser = vm.runInNewContext(`${moduleBody(errorTs)}\n${moduleBody(inputTs)}\nparseSajuInput`, {
  koreanLunarToSolar() { throw new Error('Lunar path is outside this audit'); },
});
const homeTs = fs.readFileSync(path.join(here, 'snapshots/app/page.tsx'), 'utf8');
assert.match(homeTs, /maxLength=\{40\}/);
const planetTs = fs.readFileSync(path.join(here, 'snapshots/app/planet/page.tsx'), 'utf8');
assert.match(planetTs, /if \(pName\) setInputName\(pName\)/);
assert.match(planetTs, /name: inputName,/);

// Record real export commands without a DOM, a browser, a download, or a snapshot image.
async function recordActualExport(name) {
  const operations = [], states = [], alerts = [];
  const state = {};
  const gradient = { addColorStop() {} };
  const measureFixture = text => ({ width: text.length * 14 });
  const ctx = new Proxy(state, {
    set(target, key, value) { target[key] = value; return true; },
    get(target, key) {
      if (key in target) return target[key];
      if (key === 'createLinearGradient') return () => gradient;
      if (key === 'measureText') return measureFixture; // Description wrap only, not title metrics.
      return (...args) => { operations.push({ op: key, args, font: state.font, textAlign: state.textAlign }); };
    },
  });
  const canvas = { getContext(type) { assert.equal(type, '2d'); return ctx; }, toDataURL(type) { assert.equal(type, 'image/png'); return 'data:image/png;test-fixture-only'; } };
  const anchor = { click() {} };
  const globals = {
    person: { name }, dayKey: '갑자', planetSnapshotUrl: undefined,
    // Unrelated metadata is an explicit fixture. No complete card pixels are claimed.
    spirit: { name: 'fixture', primaryColor: '#000000', speciesTitle: 'fixture', conceptDesc: 'fixture', personalityTraits: [] },
    setDownloading: value => states.push(value),
    alert: value => alerts.push(value),
    document: { createElement(tag) { if (tag === 'canvas') return canvas; if (tag === 'a') return anchor; throw new Error(`Unexpected element ${tag}`); } },
  };
  await vm.runInNewContext(`${exportJs}\nhandleDownloadStoryCard();`, globals);
  assert.equal(alerts.length, 0);
  assert.equal(canvas.width, 1080);
  assert.equal(canvas.height, 1920);
  const title = operations.find(op => op.op === 'fillText' && op.args[0] === `${name}님의 우주 정령`);
  const frame = operations.find(op => op.op === 'roundRect' && op.args[0] === 80 && op.args[1] === 240);
  assert(title && frame);
  assert.equal(title.font, 'bold 72px serif');
  assert.equal(title.textAlign, 'center');
  assert.deepEqual(Array.from(title.args.slice(1)), [540, 360]);
  assert.equal(title.args.length, 3, 'Source passes no fillText maxWidth');
  return { canvas: { width: canvas.width, height: canvas.height }, title, frame };
}
const fonts = [
  { family: 'Noto Serif CJK KR', path: '/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc' },
  { family: 'Noto Sans CJK KR', path: '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc' },
];
for (const font of fonts) {
  assert(fs.existsSync(font.path), `Required installed font missing: ${font.path}`);
  assert(GlobalFonts.registerFromPath(font.path), `Could not register ${font.path}`);
  font.sha256 = sha256(fs.readFileSync(font.path));
}
const names = [
  ['hangul_3', '홍길동'],
  ['hangul_6', '가나다라마바'],
  ['hangul_7', '가나다라마바사'],
  ['hangul_9', '가나다라마바사아자'],
  ['hangul_10', '가나다라마바사아자차'],
  ['latin_20', 'Alexandra Montgomery'],
  ['hangul_40', '가나다라마바사아자차'.repeat(4)],
  ['latin_40', 'W'.repeat(40)],
  ['hangul_50', '가나다라마바사아자차'.repeat(5)],
];
// Raster bounds avoid relying solely on a shaping engine's TextMetrics ink box.
function rasterEvidence(font, text) {
  const wide = createCanvas(8192, 160), c = wide.getContext('2d');
  c.font = font; c.textAlign = 'center'; c.fillStyle = '#FFFFFF';
  c.fillText(text, 4096, 100);
  const pixels = c.getImageData(0, 0, 8192, 160).data;
  let left = 8192, right = -1, top = 160, bottom = -1, inkPixels = 0, lostLeft = 0, lostRight = 0;
  for (let y = 0; y < 160; y++) for (let x = 0; x < 8192; x++) {
    if (pixels[(y * 8192 + x) * 4 + 3] === 0) continue;
    left = Math.min(left, x); right = Math.max(right, x); top = Math.min(top, y); bottom = Math.max(bottom, y);
    inkPixels++;
    const sourceX = x - (4096 - 540);
    if (sourceX < 0) lostLeft++;
    if (sourceX >= 1080) lostRight++;
  }
  assert(left > 0 && right < 8191 && top > 0 && bottom < 159, 'Wide diagnostic must not clip itself');
  const sourceLeft = left - (4096 - 540), sourceRightExclusive = right + 1 - (4096 - 540);
  return { inkLeft: sourceLeft, inkRightExclusive: sourceRightExclusive, inkTop: top + 260, inkBottomExclusive: bottom + 261,
    inkPixels, inkPixelsLeftOfCanvas: lostLeft, inkPixelsRightOfCanvas: lostRight,
    fractionInkOutsideCanvas: (lostLeft + lostRight) / inkPixels,
    crossesFrame: sourceLeft < 80 || sourceRightExclusive > 1000,
    crossesCanvas: lostLeft > 0 || lostRight > 0 };
}
const results = [];
const metricsCtx = createCanvas(1080, 1920).getContext('2d');
for (const [id, name] of names) {
  const input = parser({ name, gender: 'male', birthYear: 2000, birthMonth: 6, birthDay: 15, isUnknownTime: true, calendarType: 'solar' });
  assert.equal(input.name, name, 'Fixture should survive actual parser unchanged');
  const commands = await recordActualExport(name);
  const row = { id, name, utf16Units: name.length, withinHome40: name.length <= 40, parsedUnchanged: input.name === name, commands, measured: [] };
  for (const font of fonts) {
    metricsCtx.font = `bold 72px "${font.family}"`;
    metricsCtx.textAlign = commands.title.textAlign;
    const m = metricsCtx.measureText(commands.title.args[0]);
    assert(m.actualBoundingBoxAscent > 0, 'Must measure real visible glyphs');
    const inkLeft = 540 - m.actualBoundingBoxLeft;
    const inkRight = 540 + m.actualBoundingBoxRight;
    row.measured.push({ font: metricsCtx.font, width: m.width, inkLeft, inkRight,
      inkTop: 360 - m.actualBoundingBoxAscent, inkBottom: 360 + m.actualBoundingBoxDescent,
      crossesFrame: inkLeft < 80 || inkRight > 1000,
      crossesCanvas: inkLeft < 0 || inkRight > 1080,
      leftOutsideCanvas: Math.max(0, -inkLeft), rightOutsideCanvas: Math.max(0, inkRight - 1080),
      rawMetrics: m, raster: rasterEvidence(metricsCtx.font, commands.title.args[0]) });
  }
  results.push(row);
}

// Exact source title command with only a documented font substitution, isolated
// on a diagnostic canvas. The image is a CPU font specimen, never an app screenshot.
const specimens = ['hangul_3', 'hangul_7', 'hangul_10', 'latin_20', 'hangul_40', 'latin_40'];
const specimenIndex = [];
for (const id of specimens) {
  const row = results.find(r => r.id === id);
  const canvas = createCanvas(1080, 440), c = canvas.getContext('2d');
  c.fillStyle = '#020617'; c.fillRect(0, 0, 1080, 440);
  c.fillStyle = '#FFFFFF'; c.font = '20px sans-serif';
  c.fillText('CPU FONT SPECIMEN ONLY | Noto Serif CJK KR bold | NOT A BROWSER SCREENSHOT', 24, 42);
  c.fillText(`${id}: ${row.utf16Units} UTF-16 units | measured advance ${row.measured[0].width.toFixed(2)} px`, 24, 76);
  c.fillText('Original title position (540, 360); card edges x=80 and x=1000; canvas width 1080.', 24, 110);
  c.strokeStyle = 'rgba(230, 200, 117, 0.4)'; c.lineWidth = 3; c.beginPath(); c.roundRect(...row.commands.frame.args); c.stroke();
  c.fillStyle = '#FFFFFF'; c.font = row.measured[0].font; c.textAlign = row.commands.title.textAlign;
  c.fillText(...row.commands.title.args);
  const filename = `CPU_font_specimen_${id}.png`;
  const bytes = canvas.toBuffer('image/png');
  fs.writeFileSync(path.join(out, filename), bytes);
  specimenIndex.push({ path: filename, sha256: sha256(bytes), width: 1080, height: 440, description: 'Isolated CPU title/frame diagnostic; not a rendered app or complete export' });
}
const sourceContract = { sourceHash: provenance.files[0].sha256,
  exportTsSha256: sha256(exportTs), exportJsSha256: sha256(exportJs),
  titleFont: 'bold 72px serif', titleX: 540, titleY: 360, titleAlign: 'center', titleMaxWidth: null,
  frameLeft: 80, frameRight: 1000, frameWidth: 920, canvasWidth: 1080, canvasHeight: 1920,
  homeMaxUtf16: 40, parserMaxUtf16: 50,
  notes: ['Actual full export function extracted and type-stripped by built-in Node module.',
    'Recorder tests only source draw contract; description wrapping uses a fixture measureText.',
    'Name admission is checked with actual type-stripped solar parser.',
    'Real glyph metrics and specimens use explicitly registered CPU fonts, not generic serif and not browser font resolution.',
    'Native browser Canvas, DOM preview, real download, snapshot branch and async lifecycle were not tested.'] };
const result = { recordedAt: new Date().toISOString(), node: process.version,
  engine: `@napi-rs/canvas ${require('@napi-rs/canvas/package.json').version} (CPU/Skia)`,
  sourceContract, fonts, results, specimens: specimenIndex };
assert.equal(results[0].measured[0].raster.crossesFrame, false);
assert.equal(results.find(r => r.id === 'hangul_7').measured[0].raster.crossesFrame, true);
assert.equal(results.find(r => r.id === 'hangul_10').measured[0].raster.crossesCanvas, true);
assert.equal(results.find(r => r.id === 'hangul_40').measured[0].raster.crossesCanvas, true);
fs.writeFileSync(path.join(out, 'results.json'), JSON.stringify(result, null, 2) + '\n');
fs.writeFileSync(path.join(out, 'results.csv'), ['case,utf16_units,within_home_40,font,advance_px,raster_ink_left,raster_ink_right_exclusive,crosses_frame,crosses_canvas',
  ...results.flatMap(r => r.measured.map(m => [r.id, r.utf16Units, r.withinHome40, '"' + m.font.replaceAll('"', '""') + '"', m.width, m.raster.inkLeft, m.raster.inkRightExclusive, m.raster.crossesFrame, m.raster.crossesCanvas].join(',')))].join('\n') + '\n');
console.log(JSON.stringify({ result: 'Width defect reproduced in source contract and real-font CPU rendering; no browser claim.', sourceContract, rows: results.map(r => ({ id: r.id, units: r.utf16Units, width: r.measured[0].width, inkLeft: r.measured[0].raster.inkLeft, inkRightExclusive: r.measured[0].raster.inkRightExclusive, crossesFrame: r.measured[0].raster.crossesFrame, crossesCanvas: r.measured[0].raster.crossesCanvas })) }, null, 2));
