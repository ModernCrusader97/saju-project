# Passport title width investigation

A narrow title-fitting correction is warranted in the surviving source. A normal-length, permitted name can cause the PNG title to extend beyond the card and lose letters at the canvas edges. This is a source-contract finding supported by real installed-font CPU measurements and rasterization. It is **not** a browser screenshot, a claim about the latest missing source, or an implemented fix.

## Verified result

The export uses a 1080 × 1920 canvas. Its gold frame runs from x = 80 to x = 1000 (920 px wide). The title uses `bold 72px serif`, `textAlign = "center"`, and exactly:

```js
ctx.fillText(`${person.name}님의 우주 정령`, 540, 360);
```

There is no fourth `maxWidth` argument, preceding measurement, title wrapping, or font-size fitting. The title is ordinary filled text before the later snapshot clip region, so the frame does not constrain it. Canvas boundaries do.

These measurements use explicitly registered **Noto Serif CJK KR Bold at 72 px**. The x interval comes from scanning actual alpha pixels on an unclipped, wider CPU canvas and translating them back to the source's center. The right edge is exclusive.

| Name / case | UTF-16 units | Advance | Raster x interval | Result |
|---|---:|---:|---:|---|
| 홍길동 | 3 | 661.97 px | 210 to 862 | Fits; short-name control |
| 가나다라마바 | 6 | 870.62 px | 107 to 966 | Fits |
| 가나다라마바사 | 7 | 940.18 px | 73 to 1001 | Crosses the gold frame |
| 가나다라마바사아자차 | 10 | 1148.83 px | -32 to 1105 | Clipped by both canvas edges |
| Alexandra Montgomery | 20 | 1321.34 px | -120 to 1192 | Clipped by both canvas edges |
| Ten-syllable sequence repeated four times | 40 | 3235.39 px | -1075 to 2149 | Substantial clipping |
| W repeated forty times | 40 | 3606.63 px | -1263 to 2334 | Substantial clipping |

“Alexandra Montgomery” is a synthetic realistic example, not personal data. Its 20 characters are below the current home form's 40-unit limit, and also fit within a 20-character form limit. The conclusion does not rely on unusually large or malformed input. All names in the suite survive the actual solar-input parser unchanged. A 50-unit case separately covers the parser's upper limit; it is not described as enterable through the home field.

A second installed family, **Noto Sans CJK KR Bold**, also exceeds the canvas for the 10-character Korean and 20-character Latin examples. See `evidence/results.csv` and `evidence/results.json` for all 18 case/font combinations. Independent Pillow/FreeType advances agree with the CPU Canvas engine within **0.505 px** across all combinations, and the selected font faces contain every required glyph.

## User-visible path in surviving source

1. Enter `Alexandra Montgomery` in the home page's “이름 또는 별명” field, with a valid solar birth date.
2. Submit “나의 우주 보기”. The home handler carries the trimmed name in `/planet` URL parameters.
3. The planet page copies `pName` into `inputName`, passes it as `person.name` to the passport modal, and has a button opening that modal.
4. Press the PNG story-card button. The export title is drawn with the complete name plus `님의 우주 정령` and the unconstrained command above.

These steps are **source-traced**, not a performed browser interaction. Relevant snapshot locations:

- `app/page.tsx:5` and `:7`: URL navigation and `maxLength={40}`.
- `app/planet/page.tsx:51`, `:178`, `:505`: URL name, modal opener, and person prop.
- `lib/saju/input.ts:64`: trim and 50-UTF-16-unit slice; the 20- and 40-unit samples are unchanged.
- `components/planet/CosmicPassportModal.tsx:55`, `:83`, `:94`, `:99`: dimensions, centered text, frame, and title font/draw.

## Evidence and reproduction

All files are local to this investigation directory. No source edits, downloads, network, browser, desktop, installation, publishing, or Drive/GitHub operations were performed.

- `minimal-case.mjs`: short reproduction extracting the exact title command from the frozen source. Uses the 20-character realistic sample.
- `reproduce.mjs`: full audit. Verifies snapshot hashes, extracts the actual export function, strips TypeScript using Node's built-in transformer, and executes it against a draw-command recorder. It then measures and rasterizes the recorded title with installed fonts.
- `measure-fonts.py`: independent Pillow/FreeType advance and fontTools glyph-coverage checks.
- `evidence/extracted-export.ts` and `.js`: exact extracted source and type-stripped counterpart.
- `evidence/results.json`: source contract, source/renderer/font hashes, all metrics, scanned alpha bounds, and specimen hashes.
- `evidence/independent-font-metrics.json`: independent advance and glyph coverage evidence.
- `evidence/CPU_font_specimen_*.png`: isolated title/frame specimens labeled **CPU FONT SPECIMEN ONLY / NOT A BROWSER SCREENSHOT**. They use source title coordinates and frame geometry, with a documented font substitution. They are not full exported cards.

Run from this directory with the already installed tools:

```sh
node minimal-case.mjs
node reproduce.mjs
python3 measure-fonts.py
```

The tested tools are Node v24.19.0, `@napi-rs/canvas` 0.1.100 (CPU/Skia), Pillow 12.3.0, fontTools, and the installed Noto CJK bold font collections. The scripts neither install dependencies nor fetch fonts. Paths and SHA-256 hashes of both font files are in `evidence/results.json`. Source snapshots make the audit independent of changes to the surviving checkout; the current execution environment's installed font files remain prerequisites.

The recorder's unrelated spirit metadata and description-wrap measurements are explicit fixtures; **only the recorded title/frame/dimensions are used as source evidence**. Real title metrics and raster pixels are obtained separately from the CPU font engine. The no-snapshot branch permits source extraction without repeating image readiness, onerror, or lifecycle tests.

## Confidence and limits

- **Verified directly:** surviving source geometry and draw command; accepted input lengths; actual parser output; source-to-modal name path; CPU real-font metrics; CPU raster clipping; independent advances/glyph coverage; clean, unchanged source.
- **Not verified:** the user's browser's generic `serif` resolution, exact native browser Canvas pixels, the DOM preview, a real downloaded PNG, the snapshot branch, async lifecycle behavior, latest source `2709bb7`, or a deployed site.
- The CPU engine's generic `serif` selection did not resolve Hangul glyphs correctly in an initial capability check. Therefore no generic-font measurement is used as Hangul evidence. Explicit installed CJK fonts are essential here. They establish a realistic font-width failure, not the exact font selected on a user's device.
- CPU `TextMetrics.actualBoundingBoxRight` understated the right ink extent for mixed Latin/Korean runs. The report therefore uses scanned alpha-pixel bounds for clipping claims; raw metrics remain available transparently. Independent advances also agree with Pillow.
- The 7- and 10-character thresholds are examples for these fonts, not universal name-length limits. Fitting must depend on measured width, not character count.

## Distinctness from queued work

The verified source is clean commit `843a4a088a9e20760421b4c81f890d026a53ae6b`. The export title defect concerns text width after name admission and is independent of dialog focus, fullscreen state, clipboard permission/failure, and capture lifecycle/error handling.

The parent supplied a retained historical review of the prior passport error fix `69a7411`, dated October 8 at 09:27 UTC, stating that load handlers were moved before `src`, `onerror` reached the existing catch/finally, and the draw path was unchanged. The underlying patch is unavailable. This is historical context only; no fresh comparison with that patch or missing latest source is claimed or attempted. The parser's separately queued surrogate-boundary correction would also preserve these plain BMP/Latin examples unchanged, so it does not solve their display width.

## Narrow correction recommended, not implemented

Fit only the complete export title inside the existing frame, using a measured width bound no greater than 920 px with an explicit small inset for the border. Retain the full name and suffix. Preserve the `72px` starting size and existing appearance when the title fits; reduce font size proportionally only when necessary. Retain center x = 540, baseline y = 360, the existing font family/style, frame, artwork, other labels, and all asynchronous export semantics.

A one-line fit preserves the layout but makes maximum-length names small. That tradeoff should be recorded rather than silently truncating the name or claiming a readability guarantee. This audit does not choose a multiline redesign or add an input restriction. Any fitting implementation should verify short-name parity, the 20-character realistic case, Korean/Latin maximum-length cases, full text preservation, the chosen horizontal bounds, and unchanged export control flow. Native-browser verification should follow only through an authorized route when available.
