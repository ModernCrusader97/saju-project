# Isolated passport title-fitting candidate

The review candidate fixes only the exported title's width. The original checkout remains clean and unchanged. This candidate is based on surviving commit `843a4a088a9e20760421b4c81f890d026a53ae6b`; no claim is made about missing latest source `2709bb7` or the deployed site.

The parent authorized this isolated implementation after inspecting the original CPU overflow specimens. This follows the initial read-only investigation in `README.md`, which remains preserved as the pre-implementation report.

## Exact change and behavior

`candidate.patch` adds `lib/planet/passport-title.ts` and changes only an import and the two original title-drawing lines in `CosmicPassportModal.tsx`. The rest of the component is byte-identical to the frozen source. The helper performs no asynchronous operations, network work, state updates, storage writes, or model/filename changes.

- The frame stays at x = 80–1000. A **24 px interior gutter** on each side gives a centered **872 px title area**, x = 104–976. This small inset clears the 3 px border and leaves room for ordinary ink edges without shifting the layout.
- The complete name plus `님의 우주 정령` is measured first at **72 px**. If it fits, typography and draw coordinates remain unchanged.
- The helper checks descending whole-pixel sizes, stopping at **36 px**, half the original size. This avoids making a long name arbitrarily tiny. It is a design floor, not a promise that every viewing size satisfies an accessibility standard.
- If the full title still does not fit, it retains an exact prefix of whole name graphemes, adds `…`, and keeps the complete Korean suffix. This is **display-only elision**. It does not change `person.name`, parsed/stored data, or `우주여권_${person.name}_${dayKey}.png`.
- No wrapping, normalization, trimming, positioning, artwork, subtitle, or canvas-size changes are introduced.
- Measurement accounts for advance width and reported asymmetric ink overhang. The caller's existing center alignment and white fill remain in effect.

The loop measures at most 37 full-title font sizes per export, then stops the prefix scan when adding a grapheme would exceed the bound. Font sizing uses direct measurements rather than assuming widths scale perfectly across fonts.

## Grapheme and feature fallback policy

`Intl.Segmenter("ko", { granularity: "grapheme" })` supplies name boundaries. The helper never substitutes UTF-16 slicing, code-point iteration, `Array.from`, or a homemade Unicode approximation for grapheme segmentation.

When `Intl.Segmenter` is unavailable, a title that fits after sizing remains intact. If the name still overflows at 36 px, the displayed title becomes `…님의 우주 정령`. The entire name is safely elided because a trustworthy boundary cannot be found. The full name and filename remain unchanged.

For an exceptionally wide font in which even that fixed tail exceeds the area, the helper draws a fitting ellipsis alone. If even the ellipsis cannot fit, it draws an empty title. These last-resort cases are covered with deterministic metrics; they did not occur with either tested installed font.

## Verification results

The initial tests were written and run before the helper was created: **3 controls passed and 11 defect cases failed** against the extracted original title (`candidate-evidence/red-initial-*.json/log`). The final expanded baseline run has **3 passes and 15 expected failures**. The candidate passes **20 focused core checks**.

The core suite needs only Node's built-in modules and its TypeScript stripper. It loads the real candidate helper and uses documented deterministic text metrics. It covers:

- Short-title typography, realistic 20-character full-name retention, maximum-length display fitting, minimum size, suffix retention, coordinates, and display-only elision.
- Non-BMP letters, combining accents, decomposed Hangul, ZWJ plus skin-tone modifiers, standalone emoji modifiers, regional-indicator flags, and mixed clusters.
- Missing Segmenter, advance-only Canvas metrics, asymmetric overhang, and unusually wide suffix/ellipsis cases.
- Actual export-function invocation with a frozen full Unicode `person.name`, proving the download filename retains the entire original string.
- Exact restoration of the old component after removing the helper import and replacing the one helper call, proving all unrelated source, including async export/capture code, stayed byte-identical.

Some Unicode tests intentionally use strings longer than the form limit to force an elision boundary. They test helper safety, not form admission. The user-path defect is independently established with the accepted 20-character name and 40-character stress cases.

Optional real-font CPU checks also pass for **18 case/font combinations**, using explicitly registered Noto Serif CJK KR Bold and Noto Sans CJK KR Bold. Every resulting raster stays within x = 104–976. Both fonts preserve the short-title pixels exactly.

Representative serif results:

| Case | Before | After | After ink interval |
|---|---|---|---|
| 홍길동 | 72 px, 661.97 px advance | Same text, same 72 px pixels | 210–862 |
| Alexandra Montgomery | 72 px, 1321.34 px advance; clipped | Entire name at 47 px, 862.54 px advance | 109–965 |
| 40 Korean characters | 72 px, 3235.39 px advance; clipped | Whole-grapheme prefix + ellipsis + suffix at 36 px | 114–963 |
| 40 W characters | 72 px, 3606.63 px advance; clipped | Whole-character prefix + ellipsis + suffix at 36 px | 117–959 |

The eight `candidate-evidence/CPU_before_*.png` and `CPU_after_*.png` specimens are explicitly labeled **CPU FONT SPECIMEN ONLY / NOT A BROWSER SCREENSHOT**. They preserve the source title baseline and frame geometry. They are isolated diagnostics, not full cards or app screenshots. The realistic-name and Korean maximum-length after images were visually inspected.

## Reproduce and review

From this directory:

```sh
node test-title.mjs --baseline
node test-title.mjs
node render-candidate.mjs
```

The baseline command intentionally exits **1** because it reproduces the defect. The candidate commands exit **0** on success. The Node TypeScript API emits its standard experimental-feature warning; this is not a type-check pass.

Core tests are self-contained with Node v24.19.0 and standard ICU grapheme support. The optional renderer requires the already installed `@napi-rs/canvas` 0.1.100 and the two font paths recorded with SHA-256 hashes in `candidate-evidence/real-font-results.json`. It fetches and installs nothing. The earlier independent Pillow/FreeType checks of these fonts are in `evidence/independent-font-metrics.json`.

`CANDIDATE_SHA256.json` freezes code, source snapshots, tests, reports, and evidence for independent review. Run any review-generated output in a separate review directory if preserving those exact evidence bytes matters; the reproduction commands regenerate their result files.

## Integration limits

- No browser or native-browser Canvas was used. Browser generic `serif` selection and real downloaded PNGs remain unverified.
- No snapshot-image readiness, onerror, asynchronous lifecycle, or deployment test is claimed.
- Full application build, lint, and TypeScript type-check were not run. The old checkout is read-only, its `node_modules` directory is absent, TypeScript/Next/React/ESLint are not resolvable there, and installing packages is outside scope.
- The original DOM preview continues displaying the full name; this patch addresses only PNG title drawing.
- Apply or rebase only the narrow import/title hunk and helper after the current authorized source is recovered. **Do not replace a newer component wholesale with this frozen old-source candidate.** Previously queued lifecycle/capture/focus work must be preserved during later integration. Independent review and current-source integration are still pending.
