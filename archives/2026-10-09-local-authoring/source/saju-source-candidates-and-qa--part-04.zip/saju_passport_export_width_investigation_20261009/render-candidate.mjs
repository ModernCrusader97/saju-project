// Optional real-font CPU validation. Never launches a browser or changes the app.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createRequire, stripTypeScriptTypes } from 'node:module';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url)), out = path.join(here, 'candidate-evidence');
const require = createRequire(import.meta.url);
const { createCanvas, GlobalFonts } = require('@napi-rs/canvas');
const hash = x => crypto.createHash('sha256').update(x).digest('hex');
const audit = JSON.parse(fs.readFileSync(path.join(here, 'evidence/results.json'), 'utf8'));
for (const font of audit.fonts) {
  assert.equal(hash(fs.readFileSync(font.path)), font.sha256);
  assert(GlobalFonts.registerFromPath(font.path));
}
const original = fs.readFileSync(path.join(here, 'snapshots/components/planet/CosmicPassportModal.tsx'), 'utf8');
const oldTitle = original.match(/ctx\.font = "bold 72px serif";\n\s+ctx\.fillText\(`\$\{person\.name\}님의 우주 정령`, 540, 360\);/)[0];
const helperTs = fs.readFileSync(path.join(here, 'candidate/lib/planet/passport-title.ts'), 'utf8');
const helperJs = stripTypeScriptTypes(helperTs, { mode: 'strip' }).replace(/^export /gm, '');
const candidateDraw = vm.runInNewContext(`${helperJs}\ndrawPassportTitle`, { Intl });
function execute(mode, name, family, backing) {
  let declaredFont = '', call;
  const ctx = {
    get font() { return declaredFont; },
    set font(value) { declaredFont = value; backing.font = value.replace(/serif$/, `"${family}"`); },
    measureText(text) { return backing.measureText(text); },
    fillText(text, x, y) {
      call = { text, x, y, declaredFont, actualFont: backing.font, advance: backing.measureText(text).width };
      backing.fillText(text, x, y);
    },
  };
  if (mode === 'before') vm.runInNewContext(oldTitle, { ctx, person: { name } });
  else candidateDraw(ctx, name);
  assert(call);
  return call;
}
function raster(mode, name, family) {
  const canvas = createCanvas(8192, 160), ctx = canvas.getContext('2d');
  ctx.translate(4096 - 540, -260); ctx.textAlign = 'center'; ctx.fillStyle = '#FFFFFF';
  const call = execute(mode, name, family, ctx);
  const raw = ctx.getImageData(0, 0, 8192, 160).data;
  let left=8192, right=-1, top=160, bottom=-1, count=0;
  for(let y=0;y<160;y++)for(let x=0;x<8192;x++)if(raw[(y*8192+x)*4+3]){
    left=Math.min(left,x);right=Math.max(right,x);top=Math.min(top,y);bottom=Math.max(bottom,y);count++;
  }
  assert(left>0 && right<8191 && top>0 && bottom<159);
  return { ...call, inkLeft:left-(4096-540), inkRightExclusive:right+1-(4096-540),
    inkTop:top+260, inkBottomExclusive:bottom+261, inkPixels:count, pixelSha256:hash(raw) };
}
const measured=[];
for(const row of audit.results)for(const font of audit.fonts){
  const before=raster('before',row.name,font.family), after=raster('after',row.name,font.family);
  assert(after.inkLeft>=104 && after.inkRightExclusive<=976, `${row.id} actual ink exceeds chosen gutter`);
  assert(after.advance<=872);
  assert.equal(after.x,540);assert.equal(after.y,360);
  const size=Number(after.declaredFont.match(/(\d+)px/)[1]);
  assert(size>=36 && size<=72);
  assert(after.text.endsWith('님의 우주 정령'));
  if(row.id==='hangul_3'){
    assert.equal(after.pixelSha256,before.pixelSha256,'Short-title pixels must remain identical');
    assert.equal(after.declaredFont,'bold 72px serif');
  }
  if(row.id==='latin_20')assert.equal(after.text,row.name+'님의 우주 정령','Realistic name should be retained fully');
  measured.push({id:row.id,name:row.name,utf16Units:row.utf16Units,font:font.family,before,after,
    displayElided:after.text!==row.name+'님의 우주 정령'});
}
const specimens=[];
for(const id of ['hangul_3','latin_20','hangul_40','latin_40'])for(const mode of ['before','after']){
  const row=measured.find(r=>r.id===id&&r.font==='Noto Serif CJK KR'), detail=row[mode];
  const canvas=createCanvas(1080,440), ctx=canvas.getContext('2d');
  ctx.fillStyle='#020617';ctx.fillRect(0,0,1080,440);
  ctx.fillStyle='#FFFFFF';ctx.font='20px "Noto Serif CJK KR"';
  ctx.fillText(`${mode.toUpperCase()} | CPU FONT SPECIMEN ONLY | NOT A BROWSER SCREENSHOT`,24,42);
  ctx.fillText(`${id}: ${row.utf16Units} units | ${detail.declaredFont} | advance ${detail.advance.toFixed(2)} px`,24,76);
  ctx.fillText('Noto Serif CJK KR; original center (540, 360); chosen title area x=104 to x=976.',24,110);
  ctx.fillText(mode==='after'&&row.displayElided?'Name display is elided; full model name and filename stay unchanged.':'Single-line title; original frame and baseline retained.',24,144);
  ctx.strokeStyle='rgba(230, 200, 117, 0.4)';ctx.lineWidth=3;ctx.beginPath();ctx.roundRect(80,240,920,1500,48);ctx.stroke();
  ctx.textAlign='center';ctx.fillStyle='#FFFFFF';execute(mode,row.name,row.font,ctx);
  const file=`CPU_${mode}_${id}.png`, bytes=canvas.toBuffer('image/png');
  fs.writeFileSync(path.join(out,file),bytes);specimens.push({file,sha256:hash(bytes),width:1080,height:440});
}
const result={recordedAt:new Date().toISOString(),engine:`@napi-rs/canvas ${require('@napi-rs/canvas/package.json').version} (CPU/Skia)`,
  sourceCommit:'843a4a088a9e20760421b4c81f890d026a53ae6b',helperSha256:hash(helperTs),fonts:audit.fonts,
  bounds:{frameLeft:80,frameRight:1000,gutter:24,titleLeft:104,titleRight:976,width:872,minFontSize:36,maxFontSize:72},
  measurements:measured,specimens,limits:['Explicit font substitution; not browser generic serif resolution.',
    'Only title/frame specimens; not complete exports or app screenshots.',
    'No browser, actual download, snapshot-image branch, or async lifecycle claim.']};
fs.writeFileSync(path.join(out,'real-font-results.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({passed:measured.length,shortNamePixelParity:true,specimens:specimens.length,
  serifRows:measured.filter(r=>r.font==='Noto Serif CJK KR').map(r=>({id:r.id,font:r.after.declaredFont,text:r.after.text,advance:r.after.advance,inkLeft:r.after.inkLeft,inkRightExclusive:r.after.inkRightExclusive,displayElided:r.displayElided}))},null,2));
