# Independent passport-title review

**Result: no blocking finding in the isolated title-fitting candidate.** Suitable for preservation and later narrow integration, subject to the integration checks below. This review does not approve deployment or replacement of the full old component.

Reviewed on 2026-10-09 against surviving old source commit `843a4a088a9e20760421b4c81f890d026a53ae6b`:

- Patch SHA-256: `81ed151e35a3a35a8ec0c68e5bbf05c5e19ce8956a660d2638ce0dbbebb032ff`
- Helper SHA-256: `70f5b1e97138ccee4b23a151100653951222efda5284bc68524ff710f373b8a3`
- Candidate component SHA-256: `fc12c4ede68d68964c5fa3a1828dfad61e89348beb353f6d66d967bc5d43ff22`

## Findings

The 872 px centered bound correctly incorporates both advance width and reported asymmetric ink extents for the existing centered caller. The caller already sets centered alignment; the next label resets the font. The helper preserves other drawing state, measures each font size directly, retains fitting titles at 72 px, and never shrinks below 36 px. At the minimum it selects only whole-grapheme name prefixes while keeping the ellipsis and Korean suffix. Missing segmentation support safely elides the entire overflowing name. No UTF-16/code-point fallback is introduced.

The import, title-draw call, and new helper are the complete production change. Reversing the two component edits restores the source byte for byte. Applying the patch in a disposable baseline copy produces exactly the frozen candidate bytes. Existing image loading, capture, and filename code is untouched; the extracted export test retains the complete Unicode download filename.

## Fresh evidence

- `node verify-frozen.mjs`: all 52 frozen entries verified before and after review.
- Separate-copy replay: candidate **20/20**; original baseline **3 controls pass, 15 expected failures**; CPU/font suite **18/18** with identical short-title raster pixels in both CJK font families.
- Independent `review-targeted.mjs`: **22/22**. Real CPU raster bounds and context-state checks cover combining marks, non-BMP letters, decomposed Hangul, ZWJ/modifier emoji, odd regional-indicator sequences, keycaps, mixed graphemes, missing Segmenter, and absent Intl. All drawn ink stayed within x = 104–976. Unicode stress strings deliberately exceed form limits where needed to exercise elision.
- Visually inspected all eight before/after **CPU/font specimens, not browser screenshots**. The realistic Latin name is complete at 47 px; maximum Korean/Latin examples show whole-prefix elision at 36 px; the short Korean title is unchanged.

`review-execution.json` records commands/results and patch application. `REVIEW_SHA256.json` indexes the compact review artifacts. Duplicate copied sources/specimens and `patch-application/` are disposable and unnecessary for preservation.

## Limits and integration gate

No browser, actual download, full build/type-check/lint, image readiness/error handling, or deployment was exercised. CPU tests explicitly register fonts and cannot establish browser generic-serif selection. The helper trusts supplied Canvas metrics; tested raster bounds provide font/engine-specific corroboration, not a universal guarantee. Latest source `2709bb7` remains unavailable. Recover current authorized source, integrate only the import/title hunk and helper, preserve queued image/capture/lifecycle fixes, then run application and native-browser export checks before claiming integration complete.
