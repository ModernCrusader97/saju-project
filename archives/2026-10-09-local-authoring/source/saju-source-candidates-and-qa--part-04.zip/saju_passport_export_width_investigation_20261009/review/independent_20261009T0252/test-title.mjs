// Core tests use only Node built-ins. Deterministic metrics test the actual
// title algorithm, not a copied implementation; real-font tests are separate.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { stripTypeScriptTypes } from 'node:module';
import { fileURLToPath } from 'node:url';
const root = path.dirname(fileURLToPath(import.meta.url));
const baseline = process.argv.includes('--baseline');
const oldSource = fs.readFileSync(path.join(root, 'snapshots/components/planet/CosmicPassportModal.tsx'), 'utf8');
const oldTitle = oldSource.match(/ctx\.font = "bold 72px serif";\n\s+ctx\.fillText\(`\$\{person\.name\}님의 우주 정령`, 540, 360\);/)?.[0];
assert(oldTitle);
const suffix = '님의 우주 정령', maxWidth = 872, minSize = 36;
const hostSegmenter = new Intl.Segmenter('ko', { granularity: 'grapheme' });
const clusters = text => [...hostSegmenter.segment(text)].map(v => v.segment);
function fakeContext() {
  const ctx = { font: '', textAlign: 'center', calls: [],
    measureText(text) {
      const size = Number(this.font.match(/([\d.]+)px/)[1]);
      const em = clusters(text).reduce((sum, g) => sum + (/^\s+$/u.test(g) ? .25 : /^[a-zA-Z]/u.test(g) ? (g === 'W' ? .95 : .52) : 1), 0);
      const width = em * size;
      return { width, actualBoundingBoxLeft: width / 2, actualBoundingBoxRight: width / 2 };
    },
    fillText(text, x, y) { this.calls.push({ text, x, y, font: this.font, measuredWidth: this.measureText(text).width }); },
  };
  return ctx;
}
function loadDraw({ missingSegmenter = false } = {}) {
  if (baseline) return (ctx, name) => vm.runInNewContext(oldTitle, { ctx, person: { name } });
  const file = fs.readFileSync(path.join(root, 'candidate/lib/planet/passport-title.ts'), 'utf8');
  const js = stripTypeScriptTypes(file, { mode: 'strip' }).replace(/^export /gm, '');
  return vm.runInNewContext(`${js}\ndrawPassportTitle`, { Intl: missingSegmenter ? {} : Intl });
}
function runName(name, options) {
  const ctx = options?.context ?? fakeContext();
  loadDraw(options)(ctx, name);
  assert.equal(ctx.calls.length, 1);
  const call = ctx.calls[0];
  assert.equal(call.x, 540); assert.equal(call.y, 360);
  return call;
}
function sizeOf(call) { return Number(call.font.match(/([\d.]+)px/)[1]); }
function assertFits(call) {
  assert(call.measuredWidth <= maxWidth + 1e-7, `Expected width <= ${maxWidth}; got ${call.measuredWidth}: ${call.text}`);
  assert(sizeOf(call) >= minSize && sizeOf(call) <= 72);
}
function assertSafeElision(name, call) {
  assertFits(call);
  assert(call.text.endsWith(`…${suffix}`), 'An elided title keeps ellipsis and the complete fixed suffix');
  const prefix = call.text.slice(0, -(`…${suffix}`.length));
  const original = clusters(name);
  assert(original.slice(0, clusters(prefix).length).join('') === prefix, 'Visible name is an exact whole-grapheme prefix');
  assert(prefix.length < name.length);
  assert.equal(sizeOf(call), minSize);
}
const tests = [];
const test = (name, body) => tests.push({ name, body });
test('short Korean control preserves exact 72px typography and title', () => {
  const call = runName('홍길동'); assert.equal(call.text, `홍길동${suffix}`); assert.equal(call.font, 'bold 72px serif'); assertFits(call);
});
test('20-character realistic name shrinks without losing any content', () => {
  const name = 'Alexandra Montgomery'; assert.equal(name.length, 20);
  const call = runName(name); assertFits(call); assert.equal(call.text, name + suffix); assert(sizeOf(call) < 72);
});
test('40-character Korean name uses minimum size then safe elision', () => assertSafeElision('가나다라마바사아자차'.repeat(4), runName('가나다라마바사아자차'.repeat(4))));
test('40-character wide Latin name fits and preserves suffix', () => assertSafeElision('W'.repeat(40), runName('W'.repeat(40))));
for (const [label, cluster] of [
  ['non-BMP letter', '𐐀'], ['combining mark', 'e\u0301'], ['decomposed Hangul', '\u1112\u1161\u11ab'],
  ['ZWJ plus modifier', '👩🏽‍🚀'], ['emoji modifier', '👍🏿'], ['regional-indicator flag', '🇰🇷'],
]) {
  test(`elision never splits ${label} clusters`, () => {
    const name = cluster.repeat(40), call = runName(name);
    assertSafeElision(name, call);
    const visible = call.text.slice(0, -(`…${suffix}`.length));
    assert(visible.length > 0, 'Should retain some whole clusters when they fit');
    assert.equal(visible, cluster.repeat(clusters(visible).length));
  });
}
test('mixed grapheme sequence retains a valid prefix without normalization', () => {
  const name = 'A🇰🇷e\u0301👩🏽‍🚀\u1112\u1161\u11ab𐐀B'.repeat(6);
  assertSafeElision(name, runName(name));
});
test('missing Segmenter keeps a fitting title intact', () => {
  const name = '홍길동'; const call = runName(name, { missingSegmenter: true });
  assert.equal(call.text, name + suffix); assert.equal(sizeOf(call), 72); assertFits(call);
});
test('missing Segmenter elides the entire overflowing name safely', () => {
  const call = runName('👩🏽‍🚀'.repeat(40), { missingSegmenter: true });
  assertFits(call); assert.equal(call.text, `…${suffix}`); assert.equal(sizeOf(call), 36);
});
test('full input value is never normalized or trimmed by the helper', () => {
  const name = '  e\u0301  '; const call = runName(name);
  assert.equal(call.text, name + suffix); assert.equal(sizeOf(call), 72);
});
test('advance-only metrics remain supported', () => {
  const ctx = fakeContext(), measure = ctx.measureText;
  ctx.measureText = function (text) { return { width: measure.call(this, text).width }; };
  const call = runName('Alexandra Montgomery', { context: ctx }); assertFits(call);
});
test('reported asymmetric ink overhang also stays inside the bound', () => {
  const ctx = fakeContext(), measure = ctx.measureText;
  ctx.measureText = function (text) {
    const m = measure.call(this, text); m.actualBoundingBoxLeft += 100; return m;
  };
  const call = runName('홍길동', { context: ctx });
  const m = ctx.measureText(call.text); assert(m.actualBoundingBoxLeft <= maxWidth / 2); assertFits(call);
});
test('an exceptionally wide fixed suffix falls back to one fitting ellipsis', () => {
  const ctx = fakeContext();
  ctx.measureText = text => ({ width: text === '…' ? 36 : 2000 });
  const call = runName('홍길동', { context: ctx }); assertFits(call); assert.equal(call.text, '…');
});
test('no glyph is drawn when even one ellipsis cannot fit at the minimum', () => {
  const ctx = fakeContext(); ctx.measureText = text => ({ width: text === '' ? 0 : 2000 });
  const call = runName('홍길동', { context: ctx }); assertFits(call); assert.equal(call.text, '');
});
if (!baseline) test('actual export keeps the full Unicode name in its download filename', async () => {
  const file = fs.readFileSync(path.join(root, 'candidate/components/planet/CosmicPassportModal.tsx'), 'utf8');
  const start = file.indexOf('  const handleDownloadStoryCard = async () => {');
  const stop = file.indexOf('\n\n  return (', start);
  const js = stripTypeScriptTypes(file.slice(start, stop), { mode: 'strip' });
  const name = 'A🇰🇷e\u0301👩🏽‍🚀\u1112\u1161\u11ab𐐀B'.repeat(6);
  const person = Object.freeze({ name });
  const drawing = fakeContext();
  const ctx = new Proxy(drawing, { get(target, key) {
    if (key in target) return target[key];
    if (key === 'createLinearGradient') return () => ({ addColorStop() {} });
    return () => {};
  } });
  const anchor = { click() {} };
  const canvas = { getContext() { return ctx; }, toDataURL() { return 'data:image/png;fixture-only'; } };
  await vm.runInNewContext(`${js}\nhandleDownloadStoryCard();`, {
    person, dayKey: '갑자', planetSnapshotUrl: undefined,
    spirit: { name: 'fixture', primaryColor: '#000000', speciesTitle: 'fixture', conceptDesc: 'fixture', personalityTraits: [] },
    drawPassportTitle: loadDraw(), setDownloading() {}, alert(message) { throw Error(message); },
    document: { createElement(tag) { return tag === 'canvas' ? canvas : anchor; } },
  });
  assert.equal(person.name, name);
  assert.equal(anchor.download, `우주여권_${name}_갑자.png`);
  const title = drawing.calls.find(call => call.x === 540 && call.y === 360);
  assertSafeElision(name, title);
});
if (!baseline) test('production call-site changes are limited to import and title draw', () => {
  const candidate = fs.readFileSync(path.join(root, 'candidate/components/planet/CosmicPassportModal.tsx'), 'utf8');
  const restored = candidate
    .replace('import { drawPassportTitle } from "@/lib/planet/passport-title";\n', '')
    .replace('drawPassportTitle(ctx, person.name);', 'ctx.font = "bold 72px serif";\n      ctx.fillText(`${person.name}님의 우주 정령`, 540, 360);');
  assert.equal(restored, oldSource, 'Async flow, art, full name, filename, and all unrelated source must remain byte-identical');
});
const results = [];
for (const { name, body } of tests) {
  try { await body(); results.push({ name, status: 'pass' }); }
  catch (error) { results.push({ name, status: 'fail', message: error.message }); }
}
const result = { mode: baseline ? 'baseline' : 'candidate', passed: results.filter(r => r.status === 'pass').length, failed: results.filter(r => r.status === 'fail').length, results };
const file = path.join(root, 'candidate-evidence', baseline ? 'red-results.json' : 'green-results.json');
fs.writeFileSync(file, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
process.exitCode = result.failed ? 1 : 0;
