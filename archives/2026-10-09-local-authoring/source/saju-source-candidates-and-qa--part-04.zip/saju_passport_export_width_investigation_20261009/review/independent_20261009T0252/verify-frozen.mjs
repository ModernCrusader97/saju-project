// Read-only integrity check; run before copying the package for independent tests.
import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const root = new URL('./', import.meta.url);
const manifest = JSON.parse(fs.readFileSync(new URL('CANDIDATE_SHA256.json', root), 'utf8'));
for (const entry of manifest) {
  const bytes = fs.readFileSync(new URL(entry.path, root));
  const digest = crypto.createHash('sha256').update(bytes).digest('hex');
  assert.equal(digest, entry.sha256, `Frozen file changed: ${entry.path}`);
}
console.log(`Verified ${manifest.length} frozen files.`);
