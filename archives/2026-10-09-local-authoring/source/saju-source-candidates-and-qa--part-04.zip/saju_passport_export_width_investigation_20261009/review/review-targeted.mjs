// Independent review-only CPU Canvas checks; no browser, network, or source mutation.
// node review/review-targeted.mjs [candidate-package-directory]
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createRequire, stripTypeScriptTypes } from 'node:module';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(process.argv[2] ?? path.join(here, '..'));
const require = createRequire(import.meta.url);
const { createCanvas, GlobalFonts } = require('@napi-rs/canvas');
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
const helper = fs.readFileSync(path.join(root, 'candidate/lib/planet/passport-title.ts'), 'utf8');
const js = stripTypeScriptTypes(helper, { mode: 'strip' }).replace(/^export /gm, '');
const load = intl => vm.runInNewContext(`${js}\ndrawPassportTitle`, { Intl: intl });
const fonts = JSON.parse(fs.readFileSync(path.join(root, 'evidence/results.json'), 'utf8')).fonts;
const extraFonts = [
  '/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf',
  '/usr/share/fonts/truetype/noto/NotoSansDeseret-Regular.ttf',
];
const allFonts = [...fonts.map(f => f.path), ...extraFonts].map(file => {
  const bytes = fs.readFileSync(file);
  assert(GlobalFonts.registerFromPath(file));
  return { path: file, sha256: hash(bytes) };
});
const segmenter = new Intl.Segmenter('ko', { granularity: 'grapheme' });
const segments = s => [...segmenter.segment(s)].map(v => v.segment);
const suffix = '님의 우주 정령';
const cases = [
  ['six_hangul_near_boundary', '가나다라마바'],
  ['combining_accent', 'e\u0301'.repeat(40)],
  ['non_BMP_letters', '𐐀'.repeat(40)],
  ['decomposed_hangul', '\u1112\u1161\u11ab'.repeat(40)],
  ['ZWJ_modifier', '👩🏽‍🚀'.repeat(40)],
  ['skin_tone_modifier', '👍🏿'.repeat(40)],
  ['regional_indicator_odd_sequence', '🇰🇷🇺🇸🇬'.repeat(9)],
  ['keycap_variation_selector', '1\uFE0F\u20E3'.repeat(40)],
  ['mixed_unicode', 'A🇰🇷e\u0301👩🏽‍🚀\u1112\u1161\u11ab𐐀B'.repeat(6)],
];
const results = [];
function draw(name, family, options = {}) {
  const intl = Object.hasOwn(options, 'intl') ? options.intl : Intl;
  const canvas = createCanvas(4096, 512), ctx = canvas.getContext('2d');
  ctx.translate(1508, 0);
  ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#FFFFFF'; ctx.globalAlpha = 1;
  const state = () => ({ align: ctx.textAlign, baseline: ctx.textBaseline, fill: ctx.fillStyle,
    alpha: ctx.globalAlpha, transform: Array.from(ctx.getTransform().toFloat64Array()) });
  const beforeState = state();
  let declaredFont = '', call, drawCount = 0, measurements = 0;
  const proxy = new Proxy(ctx, {
    get(target, key) {
      if (key === 'font') return declaredFont;
      if (key === 'measureText') return text => { measurements++; return target.measureText(text); };
      if (key === 'fillText') return (text, x, y) => {
        drawCount++;
        const m = target.measureText(text);
        call = { text, x, y, font: declaredFont, actualFont: target.font, width: m.width,
          actualBoundingBoxLeft: m.actualBoundingBoxLeft, actualBoundingBoxRight: m.actualBoundingBoxRight };
        target.fillText(text, x, y);
      };
      const value = Reflect.get(target, key);
      return typeof value === 'function' ? value.bind(target) : value;
    },
    set(target, key, value) {
      assert.equal(key, 'font', 'Only font state should be changed by this helper');
      declaredFont = value;
      target.font = value.replace(/serif$/, `"${family}", "Noto Color Emoji", "Noto Sans Deseret"`);
      return true;
    },
  });
  load(intl)(proxy, name);
  assert.equal(drawCount, 1);
  assert.deepEqual(state(), beforeState, 'Caller drawing state other than font must survive');
  assert.equal(call.x, 540); assert.equal(call.y, 360);
  assert(call.width <= 872);
  const px = ctx.getImageData(0, 0, 4096, 512).data;
  let left = Infinity, right = -Infinity;
  for (let y = 0; y < 512; y++) for (let x = 0; x < 4096; x++) {
    if (px[(y * 4096 + x) * 4 + 3]) { left = Math.min(left, x - 1508); right = Math.max(right, x + 1 - 1508); }
  }
  assert(left >= 104 && right <= 976, `Actual ink outside title interval: ${left}..${right}`);
  assert(measurements <= 40 + segments(name).length);
  if (call.text !== name + suffix) {
    assert(call.text.endsWith('…' + suffix));
    const visible = call.text.slice(0, -('…' + suffix).length);
    assert(segments(name).some((_, i, list) => list.slice(0, i + 1).join('') === visible) || visible === '');
    assert.equal(call.font, 'bold 36px serif');
  }
  return { ...call, inkLeft: left, inkRightExclusive: right, measurements, callerStatePreserved: true };
}
for (const font of fonts) for (const [id, name] of cases) {
  try {
    const call = draw(name, font.family);
    if (id === 'six_hangul_near_boundary' && font.family === 'Noto Serif CJK KR') {
      assert.equal(call.font, 'bold 72px serif'); assert.equal(call.text, name + suffix);
    }
    results.push({ id, family: font.family, status: 'pass', ...call });
  } catch (error) { results.push({ id, family: font.family, status: 'fail', error: error.message }); }
}
for (const [id, name, expected, intl] of [
  ['missing_Segmenter_keeps_sized_full_name', 'Alexandra Montgomery', 'Alexandra Montgomery' + suffix, {}],
  ['missing_Segmenter_elides_safe_whole_name', '👩🏽‍🚀'.repeat(40), '…' + suffix, {}],
  ['absent_Intl_keeps_sized_full_name', 'Alexandra Montgomery', 'Alexandra Montgomery' + suffix, undefined],
  ['absent_Intl_elides_safe_whole_name', '👩🏽‍🚀'.repeat(40), '…' + suffix, undefined],
]) {
  try {
    const call = draw(name, fonts[0].family, { intl });
    assert.equal(call.text, expected);
    results.push({ id, status: 'pass', ...call });
  } catch (error) { results.push({ id, status: 'fail', error: error.message }); }
}
const output = { recordedAt: new Date().toISOString(), engine: `@napi-rs/canvas ${require('@napi-rs/canvas/package.json').version} CPU/Skia`,
  helperSha256: hash(helper), registeredFonts: allFonts, passed: results.filter(r => r.status === 'pass').length,
  failed: results.filter(r => r.status === 'fail').length, results,
  limits: ['CPU font substitution, not native browser Canvas.', 'Unicode visual shaping is exercised, not a cross-platform glyph-coverage guarantee.',
    'Stress Unicode samples may exceed the form limit; they test safe elision boundaries.', 'Only helper title pixels and state are tested; no app, async-image, or real-download claim.'] };
fs.writeFileSync(path.join(here, 'targeted-results.json'), JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify({ passed: output.passed, failed: output.failed, failures: results.filter(r => r.status === 'fail') }, null, 2));
process.exitCode = output.failed ? 1 : 0;
