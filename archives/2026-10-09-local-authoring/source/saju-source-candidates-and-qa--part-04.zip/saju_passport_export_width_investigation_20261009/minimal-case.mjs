// Offline CPU reproduction of the exact name/title draw. No browser or download.
import { createRequire } from 'node:module';
import fs from 'node:fs';
import vm from 'node:vm';
const require = createRequire(import.meta.url);
const { createCanvas, GlobalFonts } = require('@napi-rs/canvas');
const source = fs.readFileSync(new URL('./snapshots/components/planet/CosmicPassportModal.tsx', import.meta.url), 'utf8');
const command = source.match(/ctx\.fillText\(`\$\{person\.name\}님의 우주 정령`, 540, 360\);/)?.[0];
if (!command) throw new Error('Source title command changed; investigate before rerunning');
GlobalFonts.registerFromPath('/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc');
const ctx = createCanvas(1080, 1920).getContext('2d');
// Explicit installed font substitution is essential: this is not browser serif resolution.
ctx.font = 'bold 72px "Noto Serif CJK KR"';
ctx.textAlign = 'center';
const person = { name: 'Alexandra Montgomery' }; // 20 units; within the home's 40-unit limit.
vm.runInNewContext(command, { ctx, person });
console.log(JSON.stringify({
  sourceCommand: command, name: person.name, nameUnits: person.name.length,
  sourceFont: 'bold 72px serif', cpuFont: ctx.font,
  measuredAdvancePx: ctx.measureText(`${person.name}님의 우주 정령`).width,
  canvasWidthPx: 1080, frameWidthPx: 920,
  evidence: 'CPU real-font advance only; run reproduce.mjs for alpha bounds and input admission evidence',
}, null, 2));
