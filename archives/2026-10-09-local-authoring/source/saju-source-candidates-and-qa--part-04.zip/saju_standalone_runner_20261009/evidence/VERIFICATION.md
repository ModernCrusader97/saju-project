# Recorded verification

The final runner and its exact packaged ZIP both passed the combined verification under Node 24.19.0, Python 3.12.14 and Git 2.52.0 on Linux. `EXECUTION_INDEX.json` records the frozen runner hashes, ZIP hash, report paths, result hashes and durations.

- Calendar: three expected original assertion failures, 17 passing candidate groups, 73,414 Gregorian dates, 73,413 transitions, 900 output comparisons, 27 fixed instants in seven timezones.
- Name reproduction: 28 named well-formed inputs and 896 generated inputs; four named and nine generated historical split-pair cases reproduced.
- Name baseline: 986 checks, 968 passed, exactly 18 expected failures, expected exit 1.
- Name candidate: 987 checks, 987 passed, exit 0.
- Both capsule delivery manifests and frozen manifests passed. Before/after inventories matched. The two original local input ZIPs and packaged copies retained their pinned hashes.
- Optional historical checkout verification was explicitly not requested in every current run.
- All 23 behavioral runner tests passed, including malformed child output, unexpected exit, timeout fail-fast, process-group cleanup, bounded logs, corrupt/missing inputs and safe extraction boundaries.

The final ZIP was extracted to a fresh location and invoked from another working directory, with deliberately invalid inherited Node hook and output variables. The clean child environment omitted them, and all four commands still passed. This demonstrates relocation and the reviewed standalone execution path; it is not an OS/network sandbox proof.

The QA archive retains the primary and exact-ZIP relocation reports, stdout/stderr, produced JSON results and before/after inventories. Repeated extracted source trees are omitted from the QA archive because their identical source archives are included in the runner ZIP; all of the complete local run directories remain available for review. Absolute paths inside historical and new reports identify where evidence was captured, not dependencies to supply to a later run.

Development red logs are intentionally retained and labeled in the index. These are not failed final candidate tests. One early run assumed 27 frozen name entries instead of the actual 26, and used a historical calendar log that had requested the old checkout. Those fixture assumptions were corrected. A new implicit-parent case-alias extraction test then exposed and verified the corresponding rejection fix.

The runner and implementation commands did not access the original checkout or denied backups and performed no desktop access, package installation, network/browser work, app build, application typecheck/lint, commit, upload, integration, deployment or live-site check. The independent review may separately record read-only checkout custody comparisons; those are distinct from the runner’s optional harness checkout status, which remains not requested. Historical source remains 843a4a0; latest 2709bb7 remains unavailable; neither candidate is integrated or live.
