"""Behavioral tests; all fixtures and children are confined to temporary directories."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True


class RunnerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.available = (ROOT / "run.py").is_file()
        if cls.available:
            spec = importlib.util.spec_from_file_location("saju_runner", ROOT / "run.py")
            cls.r = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = cls.r
            spec.loader.exec_module(cls.r)

    def setUp(self):
        self.assertTrue(self.available, "The combined verifier must exist before its behavior can pass")
        self.temp = tempfile.TemporaryDirectory(prefix="selftest-", dir=ROOT / "evidence")
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)

    def archive(self, entries):
        target = self.base / "fixture.zip"
        with zipfile.ZipFile(target, "w") as z:
            for name, content in entries:
                z.writestr(name, content)
        return target

    def test_missing_and_corrupt_capsules_rejected_before_extraction(self):
        empty = self.base / "capsules"
        empty.mkdir()
        with self.assertRaisesRegex(self.r.VerificationError, "missing|unreadable"):
            self.r.verify_archives(empty)
        for capsule in self.r.CAPSULES:
            (empty / capsule["filename"]).write_bytes(b"not the pinned archive")
        with self.assertRaisesRegex(self.r.VerificationError, "size|hash"):
            self.r.verify_archives(empty)
        self.assertEqual(list(self.base.glob("extracted*")), [])

    def test_same_size_archive_corruption_rejected(self):
        dest = self.base / "capsules"
        dest.mkdir()
        for capsule in self.r.CAPSULES:
            content = bytearray((ROOT / "capsules" / capsule["filename"]).read_bytes())
            content[-1] ^= 1
            (dest / capsule["filename"]).write_bytes(content)
        with self.assertRaisesRegex(self.r.VerificationError, "hash"):
            self.r.verify_archives(dest)

    def test_safe_relative_extraction_preserves_bytes(self):
        archive = self.archive([("top/a.txt", b"hello"), ("top/sub/b.txt", b"world")])
        dest = self.base / "out"
        self.r.safe_extract(archive, dest)
        self.assertEqual((dest / "top/a.txt").read_bytes(), b"hello")
        self.assertEqual((dest / "top/sub/b.txt").read_bytes(), b"world")

    def test_unsafe_paths_rejected_without_partial_writes(self):
        for name in ["../escape", "/absolute", "top/../../escape", "C:/drive", "top\\escape", "top/./a", "top//a"]:
            with self.subTest(name=name):
                archive = self.archive([("safe", b"safe"), (name, b"bad")])
                dest = self.base / "out"
                with self.assertRaises(self.r.VerificationError):
                    self.r.safe_extract(archive, dest)
                self.assertFalse(dest.exists(), "Complete preflight must precede all extraction writes")
        self.assertFalse((self.base.parent / "escape").exists())

    def test_symlink_member_and_case_collisions_rejected(self):
        link = zipfile.ZipInfo("top/link")
        link.create_system = 3
        link.external_attr = (stat.S_IFLNK | 0o777) << 16
        for entries in [[(link, b"../../outside")], [("top/A", b"1"), ("top/a", b"2")], [("top", b"file"), ("top/child", b"bad")]]:
            with self.subTest(entries=repr(entries)):
                with self.assertRaises(self.r.VerificationError):
                    self.r.safe_extract(self.archive(entries), self.base / "out")
                self.assertFalse((self.base / "out").exists())

    def test_implicit_parent_case_aliases_rejected(self):
        archive = self.archive([("top/a", b"a"), ("TOP/b", b"b")])
        with self.assertRaises(self.r.VerificationError):
            self.r.safe_extract(archive, self.base / "out")
        self.assertFalse((self.base / "out").exists())

    def test_existing_destination_and_symlink_destination_rejected(self):
        archive = self.archive([("a", b"new")])
        dest = self.base / "existing"
        dest.mkdir()
        (dest / "keep").write_text("preserve")
        with self.assertRaises(self.r.VerificationError):
            self.r.safe_extract(archive, dest)
        alias = self.base / "alias"
        alias.symlink_to(dest, target_is_directory=True)
        with self.assertRaises(self.r.VerificationError):
            self.r.safe_extract(archive, alias)
        self.assertEqual((dest / "keep").read_text(), "preserve")

    def test_archive_expansion_limit_rejected_before_writes(self):
        archive = self.archive([("too-large", b"x" * 4097)])
        with patch.object(self.r, "MAX_MEMBER_BYTES", 4096):
            with self.assertRaisesRegex(self.r.VerificationError, "limit"):
                self.r.safe_extract(archive, self.base / "out")
        self.assertFalse((self.base / "out").exists())

    def test_snapshot_detects_changed_added_removed_files_and_symlinks(self):
        directory = self.base / "tree"
        directory.mkdir()
        target = directory / "a"
        target.write_text("first")
        before = self.r.inventory(directory)
        target.write_text("second")
        self.assertNotEqual(self.r.inventory(directory), before)
        target.unlink()
        self.assertNotEqual(self.r.inventory(directory), before)
        target.symlink_to(ROOT / "run.py")
        with self.assertRaisesRegex(self.r.VerificationError, "symlink|regular"):
            self.r.inventory(directory)

    def test_delivery_and_frozen_manifests_are_enforced(self):
        capsule = self.r.CAPSULES[1]
        dest = self.base / "name"
        self.r.safe_extract(ROOT / "capsules" / capsule["filename"], dest)
        result = self.r.verify_capsule(capsule, dest)
        self.assertEqual(result["delivery_files"], 106)
        self.assertEqual(result["frozen_files"], 26)
        helper = dest / capsule["root"] / "candidate/name-boundary.ts"
        helper.write_text("tampered")
        with self.assertRaisesRegex(self.r.VerificationError, "hash"):
            self.r.verify_capsule(capsule, dest)

    def name_result(self, mode):
        capsule = self.r.CAPSULES[1]
        with zipfile.ZipFile(ROOT / "capsules" / capsule["filename"]) as z:
            filename = "green-results.json" if mode == "candidate" else "red-results.json"
            return json.loads(z.read(capsule["root"] + "/" + filename))

    def test_exact_expected_red_accepted_and_unexpected_exits_rejected(self):
        baseline = self.name_result("baseline")
        expected = copy.deepcopy(baseline)
        self.r.validate_name(baseline, expected, "baseline", 1)
        for code in [0, 2, -9]:
            with self.subTest(code=code), self.assertRaises(self.r.VerificationError):
                self.r.validate_name(baseline, expected, "baseline", code)

    def test_changed_red_identity_or_harness_error_is_not_expected_failure(self):
        baseline = self.name_result("baseline")
        bad = copy.deepcopy(baseline)
        failure = next(x for x in bad["results"] if not x["passed"])
        failure["name"] = "unexpected harness crash"
        with self.assertRaises(self.r.VerificationError):
            self.r.validate_name(bad, baseline, "baseline", 1)
        bad = copy.deepcopy(baseline)
        next(x for x in bad["results"] if not x["passed"])["error"] = "ENOENT missing file"
        with self.assertRaises(self.r.VerificationError):
            self.r.validate_name(bad, baseline, "baseline", 1)

    def test_candidate_cannot_pass_with_false_counts_or_checkout_claim(self):
        expected = self.name_result("candidate")
        for change in ["count", "failed-case", "checkout", "hash"]:
            bad = copy.deepcopy(expected)
            if change == "count": bad["summary"]["tests"] = 986
            if change == "failed-case": bad["results"][0]["passed"] = False
            if change == "checkout": bad["summary"]["originalCheckoutVerification"]["verified"] = True
            if change == "hash": bad["summary"]["historicalParserSha256"] = "0" * 64
            with self.subTest(change=change), self.assertRaises(self.r.VerificationError):
                self.r.validate_name(bad, expected, "candidate", 0)

    def test_malformed_duplicate_missing_or_nonfinite_json_rejected(self):
        for value in ["{", '{"x":1,"x":2}', '{"x":NaN}']:
            with self.subTest(value=value), self.assertRaises(self.r.VerificationError):
                self.r.parse_json(value)
        for text in ["", "VERIFIED {broken}", "VERIFIED {}\nVERIFIED {}", "VERIFIED {}"]:
            with self.subTest(text=text), self.assertRaises(self.r.VerificationError):
                self.r.validate_calendar(text, 0)

    def test_calendar_rejects_missing_metrics_and_unexpected_exit(self):
        with zipfile.ZipFile(ROOT / "capsules" / self.r.CAPSULES[0]["filename"]) as z:
            log = z.read(self.r.CAPSULES[0]["root"] + "/evidence/coordinator-verification.log").decode()
        # Historical saved coordinator log explicitly checked the old checkout;
        # this runner only accepts default standalone mode, so build that fixture.
        lines = log.splitlines()
        index = next(i for i, line in enumerate(lines) if line.startswith("VERIFIED "))
        data = json.loads(lines[index][9:])
        data["oldCheckout"] = {"checked": False, "reason": "No --source-checkout supplied; preserved snapshots were checked."}
        lines[index] = "VERIFIED " + json.dumps(data, separators=(",", ":"))
        log = "\n".join(lines)
        self.r.validate_calendar(log, 0)
        with self.assertRaises(self.r.VerificationError): self.r.validate_calendar(log, 1)
        with self.assertRaises(self.r.VerificationError): self.r.validate_calendar(log.replace('"supportedDates":73414', '"supportedDates":0'), 0)

    def test_child_timeout_stops_before_later_side_effect(self):
        marker = self.base / "must-not-exist"
        code = "import time,pathlib; time.sleep(5); pathlib.Path(" + repr(str(marker)) + ").write_text('late')"
        outcome = self.r.run_process([sys.executable, "-I", "-c", code], self.base, {}, self.base / "logs", 0.15)
        self.assertEqual(outcome["termination"], "timeout")
        self.assertLess(outcome["duration_seconds"], 3)
        self.assertFalse(marker.exists())

    def test_log_flood_is_bounded_and_fails(self):
        code = "import os; [os.write(1,b'x'*4096) for _ in range(10000)]"
        outcome = self.r.run_process([sys.executable, "-I", "-c", code], self.base, {}, self.base / "logs", 5, log_limit=8192)
        self.assertEqual(outcome["termination"], "log-limit")
        self.assertLessEqual((self.base / "logs/stdout.log").stat().st_size, 8192)

    def test_timeout_kills_descendants_with_inherited_pipes(self):
        marker = self.base / "descendant-must-not-write"
        grandchild = "import time,pathlib; time.sleep(1); pathlib.Path(" + repr(str(marker)) + ").write_text('late')"
        child = "import subprocess,sys,time; subprocess.Popen([sys.executable,'-I','-c'," + repr(grandchild) + "]); time.sleep(5)"
        outcome = self.r.run_process([sys.executable, "-I", "-c", child], self.base, {}, self.base / "logs", 0.15)
        self.assertEqual(outcome["termination"], "timeout")
        time.sleep(1.1)
        self.assertFalse(marker.exists(), "Timed-out child process group must not continue writing")

    def test_cli_rejects_command_hooks(self):
        result = subprocess.run([sys.executable, str(ROOT / "run.py"), "--command", "echo surprise"], capture_output=True, text=True)
        self.assertEqual(result.returncode, 2)
        self.assertIn("unrecognized arguments", result.stderr)

    def copied_bundle(self):
        bundle = self.base / "bundle"
        (bundle / "capsules").mkdir(parents=True)
        (bundle / "tests").mkdir()
        for name in ["run.py", "tests/test_runner.py"]:
            (bundle / name).write_bytes((ROOT / name).read_bytes())
        for capsule in self.r.CAPSULES:
            (bundle / "capsules" / capsule["filename"]).write_bytes((ROOT / "capsules" / capsule["filename"]).read_bytes())
        self.r.write_json(bundle / "RUNNER_INTEGRITY.json", {"format": 1, "files": {name: self.r.digest(bundle / name) for name in ["run.py", "tests/test_runner.py"]}})
        return bundle

    def test_full_runner_missing_archive_reports_failure_without_commands(self):
        bundle = self.copied_bundle()
        (bundle / "capsules" / self.r.CAPSULES[1]["filename"]).unlink()
        with patch.object(self.r, "BUNDLE", bundle):
            self.assertEqual(self.r.execute(self.base), 1)
        evidence = next(self.base.glob("saju-verify-*"))
        report = json.loads((evidence / "report.json").read_text())
        self.assertEqual(report["status"], "failed")
        self.assertTrue(all(step["status"] == "not-run" for step in report["steps"]))
        self.assertFalse((evidence / "logs").exists())

    def test_full_runner_malformed_child_result_fails_fast_with_retained_evidence(self):
        bundle = self.copied_bundle()
        real_process = self.r.run_process
        commands = []
        def malformed(command, cwd, env, logs, timeout, **kwargs):
            commands.append(command)
            if "verify.mjs" in command:
                return real_process([sys.executable, "-I", "-c", "print('VERIFIED {}')"], cwd, env, logs, timeout)
            return real_process(command, cwd, env, logs, timeout, **kwargs)
        with patch.object(self.r, "BUNDLE", bundle), patch.object(self.r, "run_process", side_effect=malformed):
            self.assertEqual(self.r.execute(self.base), 1)
        evidence = next(self.base.glob("saju-verify-*"))
        report = json.loads((evidence / "report.json").read_text())
        self.assertEqual([step["status"] for step in report["steps"]], ["failed", "not-run", "not-run", "not-run"])
        self.assertEqual(report["extracted_unchanged"], {"calendar": True, "name": True})
        self.assertEqual((evidence / "logs/calendar/stdout.log").read_text(), "VERIFIED {}\n")
        self.assertFalse(any("test-boundary.mjs" in command or "reproduce.mjs" in command for command in commands))

    def test_environment_drops_node_hooks_and_credentials(self):
        with patch.dict(os.environ, {"NODE_OPTIONS": "--require=/forbidden/hook", "NODE_PATH": "/forbidden", "TOKEN": "synthetic-secret", "GIT_CONFIG_COUNT": "1"}):
            env = self.r.clean_environment(self.base, Path(sys.executable), Path("/usr/bin/git"))
        for name in ["NODE_OPTIONS", "NODE_PATH", "TOKEN", "GIT_CONFIG_COUNT"]:
            self.assertNotIn(name, env)
        self.assertEqual(env["TZ"], "UTC")

    def test_full_runner_timeout_and_unexpected_exit_skip_later_commands(self):
        bundle = self.copied_bundle()
        real_process = self.r.run_process
        for failure in ["timeout", "exit"]:
            parent = self.base / failure
            parent.mkdir()
            commands = []
            def failing(command, cwd, env, logs, timeout, **kwargs):
                commands.append(command)
                if "verify.mjs" in command:
                    code = "import time; time.sleep(10)" if failure == "timeout" else "raise SystemExit(7)"
                    return real_process([sys.executable, "-I", "-c", code], cwd, env, logs, 0.1)
                return real_process(command, cwd, env, logs, timeout, **kwargs)
            with self.subTest(failure=failure), patch.object(self.r, "BUNDLE", bundle), patch.object(self.r, "run_process", side_effect=failing):
                self.assertEqual(self.r.execute(parent), 1)
                report = json.loads(next(parent.glob("saju-verify-*/report.json")).read_text())
                self.assertEqual([step["status"] for step in report["steps"]], ["failed", "not-run", "not-run", "not-run"])
                self.assertEqual(report["steps"][0]["process"]["termination"], "timeout" if failure == "timeout" else None)
                self.assertFalse(any("test-boundary.mjs" in command or "reproduce.mjs" in command for command in commands))


if __name__ == "__main__":
    unittest.main(verbosity=2)
