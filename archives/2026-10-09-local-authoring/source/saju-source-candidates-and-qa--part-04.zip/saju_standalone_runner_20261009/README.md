# SaJu combined standalone verifier

This portable bundle reruns two **isolated historical-source candidates**. It does not integrate either patch into SaJu. Historical source reference: `843a4a088a9e20760421b4c81f890d026a53ae6b`. Latest reported source `2709bb7` remains unavailable and untested. Neither candidate is live.

## Run

Requirements: trusted local **Node 24**, **Python 3.11+**, and **Git**, on a POSIX system with process groups (Linux/macOS). The recorded execution used Node 24.19.0, Python 3.12.14 and Git 2.52.0 on Linux. No third-party Python or npm package is required or installed. Other environments, including macOS, have not been independently exercised here. Windows is explicitly unsupported by this process supervisor.

Unzip the complete bundle to a fresh location, then run from any working directory:

```sh
python3 /path/to/saju-combined-verifier/run.py --output-parent /existing/output/directory
```

The output parent must already exist. If omitted, the current working directory is used. Every invocation creates and retains a unique `saju-verify-*` directory; it never reuses old results. The only CLI option is `--output-parent` (plus standard `--help`). There are no command hooks, script discovery, checkout flags, configurable archives, or automatic retry options.

Exit **0** means every required integrity and behavioral check passed, including the exact expected baseline failures. Exit **1** means a verification/runtime failure or operator interruption. Exit **2** means invalid CLI arguments. Read the printed `report.json` path; do not treat a directory's existence or an unfinished report as a pass.

Run the runner's behavioral self-tests separately:

```sh
python3 /path/to/saju-combined-verifier/tests/test_runner.py
```

They use temporary directories under the bundle's `evidence/` directory and remove their own fixtures. Timeout tests launch synthetic Python children; these are test-only fixtures and are not production command options. Orchestration tests substitute synthetic malformed responses, unexpected exits and timeouts at the internal process boundary to verify failure reporting and skipped later steps. The actual combined verifier is also exercised separately against the original pinned capsules.

## Exactly what executes

Both archive sizes and SHA-256 values, the runner file manifest, all 149 capsule delivery-manifest entries and both frozen manifests are verified before capsule execution. Tool version checks use the local Node and Git executables, whose paths, versions and binary hashes are recorded.

Four fixed commands then run serially, from the appropriate freshly extracted capsule root, with `TZ=UTC`:

1. `node --disable-warning=ExperimentalWarning verify.mjs` (90-second ceiling): calendar baseline's **3 expected assertion failures**, **17 passing candidate groups**, **73,414 dates**, **73,413 transitions**, **900 output comparisons**, **27 instants / 7 timezones**, plus the capsule's patch application check in its disposable copy.
2. `node --disable-warning=ExperimentalWarning reproduce.mjs` (15-second ceiling): name defect reproduction; **28 named inputs**, **896 generated inputs**, 4 named / 9 generated split-pair cases, unchanged controls.
3. `node --disable-warning=ExperimentalWarning test-boundary.mjs` (15-second ceiling): exit 1 is accepted only for **986 checks: 968 passed and the exact 18 expected failures**. Every result identity, outcome and assertion message must match the pinned frozen expectations. Any different exit, extra failure or harness error fails the combined run.
4. `node --disable-warning=ExperimentalWarning test-boundary.mjs --candidate` (15-second ceiling): **987 checks passed**, exit 0, exact result identities and source/helper hashes.

The name commands use fresh `SAJU_BOUNDARY_OUTPUT_DIR` destinations outside their extracted capsule. The calendar command runs without `--record` and without `--source-checkout`. Both capsules explicitly report original-checkout verification as **not requested**. Historical checkout checks stored inside the capsules are prior evidence, not actions performed by this runner.

## Integrity and evidence

The exact included archives are:

- `SaJu_Standalone_Orbital_Calendar_Fix_QA_20261009_0138.zip`: 200,403 bytes, SHA-256 `b6eea7a14b89f1d320c893b75f80f4419eea47364362a6cd3d8e1795afeb4aac`
- `SaJu_Standalone_Name_Boundary_Fix_QA_20261009_0155.zip`: 277,850 bytes, SHA-256 `c3d8d90e14b607ff20b3a937db71b4dccb25b288203944f616a8b06325aaa77d`

`RUNNER_INTEGRITY.json` pins the runner, tests and guide. These local manifests detect accidental modification against a trusted copy; they are not signatures or an independent authenticity guarantee. The two capsule hashes are also hard-coded in `run.py`.

ZIP extraction performs a complete path/type/size preflight before writing: no absolute paths, parent traversal, backslashes, drive syntax, control characters, symlinks/special files, duplicate or case-aliasing paths, file/directory conflicts, encrypted entries, or unsupported compression. The destination must be new. Limits: 1,000 entries, 8 MiB per entry, 32 MiB total expanded archive bytes. ZIP file permissions are not restored.

The run retains a structured report, before/after complete file/directory inventories, exact source/harness hashes, new name JSON evidence, and bounded stdout/stderr for each command. Each stream is capped at 1 MiB; overflow is a failure and kills the process group. Version checks have 5-second ceilings. Capsule commands also share a 160-second execution budget measured from the run's start. Timeout kills the child process group, then stops the remaining plan. Integrity is checked after each successful step and again on failure/completion. A report lists unstarted commands as `not-run`.

All extracted capsule file bytes and paths must match their before snapshot at the end; original ZIPs and frozen runner files are checked again. The name output directories keep its frozen evidence intact; the calendar verifier removes its temporary patch-check directory itself. Failed runs retain their evidence for diagnosis; the operator can remove their own generated run directories when no longer needed.

The companion `SaJu_Combined_Standalone_Verifier_QA_20261009.zip` supplies the recorded execution evidence and relocation proof indexed in `evidence/EXECUTION_INDEX.json`; extract it alongside the runner ZIP to merge its evidence folder. The runner itself does not require the saved QA evidence. Self-test logs include the initial red run, corrected fixture-assumption run, and final green run. The first fixture corrections were a 26-entry (not 27) name frozen manifest and constructing an explicit no-checkout calendar fixture from a historical log that had requested the old checkout.

## Boundaries

This runner invokes trusted, pinned code with an allowlisted environment that omits inherited Node hooks, Git configuration and credentials. It is **not an OS/filesystem/network sandbox**. It does not defend against a malicious host, a concurrent filesystem attacker, compromised installed tools, or an edited runner plus edited trust manifest. Tests and commands are local and were reviewed for this task; no network/browser/package installation is performed by the command plan.

The original old checkout is neither read nor modified. Relocation demonstrates that the bundle has no sibling-checkout or author-workspace-path runtime dependency, but it does not prove absence of all external reads through an operating-system sandbox. Native Node and Git, OS libraries and timezone data remain runtime dependencies.

The inherited capsule seams and limits remain: calendar tests run selected exact historical Gregorian source slices and the orbital function in a Node VM; name tests execute the real historical parser with an explicit throwing lunar seam. No full application build, typecheck, lint, module graph, database/HTTP integration, native browser/WebGL, newest-source compatibility, deployment or live-site verification is claimed. Calendar checks preserve the old application's anchor convention; they are not astronomical validation. Name checks preserve a 50-UTF-16-unit cap, not whole grapheme clusters or a new malformed-input policy.

After recovery, both changes still require reconciliation with the current canonical source and current project validation. This package is an independently reviewable verification deliverable only. No commit, upload, permission change or publication is part of its command plan.
