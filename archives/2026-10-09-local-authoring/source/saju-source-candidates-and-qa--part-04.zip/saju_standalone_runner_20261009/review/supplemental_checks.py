"""Independent reviewer checks. Writes only under this review directory."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import time
from unittest.mock import patch
import zipfile

sys.dont_write_bytecode = True
REVIEW = Path(__file__).resolve().parent
BUNDLE = REVIEW / "final ZIP relocated/saju-combined-verifier"
spec = importlib.util.spec_from_file_location("reviewed_saju_runner", BUNDLE / "run.py")
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
BASE = REVIEW / "supplemental"
BASE.mkdir(exist_ok=False)
results = []


def rejected_zip(label, entries, limit=None):
    case = BASE / label
    case.mkdir()
    archive = case / "fixture.zip"
    with zipfile.ZipFile(archive, "w") as z:
        for name, body in entries:
            z.writestr(name, body)
    destination = case / "extracted"
    try:
        if limit:
            with patch.object(r, limit[0], limit[1]):
                r.safe_extract(archive, destination)
        else:
            r.safe_extract(archive, destination)
    except r.VerificationError as e:
        assert not destination.exists()
        results.append({"check": label, "passed": True, "error": str(e)})
    else:
        raise AssertionError(label + " was accepted")


rejected_zip("entry-count-limit", [("a", b""), ("b", b"")], ("MAX_MEMBERS", 1))
rejected_zip("total-expanded-limit", [("a", b"123"), ("b", b"456")], ("MAX_ARCHIVE_BYTES", 5))
rejected_zip("control-path", [("safe", b""), ("top/a\nb", b"bad")])
fifo = zipfile.ZipInfo("top/fifo")
fifo.create_system = 3
fifo.external_attr = (stat.S_IFIFO | 0o600) << 16
rejected_zip("special-file", [("safe", b""), (fifo, b"")])

# Exercise the real process supervisor when the process leader has already
# exited, but an inherited-pipe descendant remains in its process group.
case = BASE / "exited-parent-timeout"
case.mkdir()
marker = case / "must-not-appear"
grandchild = "import time,pathlib;time.sleep(0.6);pathlib.Path(" + repr(str(marker)) + ").write_text('late')"
parent = "import subprocess,sys;subprocess.Popen([sys.executable,'-I','-c'," + repr(grandchild) + "])"
outcome = r.run_process([sys.executable, "-I", "-c", parent], case, {}, case / "logs", 0.15)
assert outcome["termination"] == "timeout"
time.sleep(0.75)
assert not marker.exists()
r.write_json(case / "process.json", outcome)
results.append({"check": "timeout-kills-descendant-after-leader-exit", "passed": True})

# A stderr flood must be bounded just as stdout is in the supplied self-tests.
case = BASE / "stderr-flood"
case.mkdir()
outcome = r.run_process([sys.executable, "-I", "-c", "import os;[os.write(2,b'x'*4096) for _ in range(1000)]"], case, {}, case / "logs", 3, log_limit=8192)
assert outcome["termination"] == "log-limit"
assert (case / "logs/stderr.log").stat().st_size == 8192
r.write_json(case / "process.json", outcome)
results.append({"check": "stderr-overflow-is-bounded-failure", "passed": True})

real_process = r.run_process

# Run the real preceding commands and real baseline, then emulate an
# unexpected successful exit from that baseline. Candidate must not run.
case = BASE / "baseline-unexpected-success"
case.mkdir()
def bad_baseline(command, cwd, env, logs, timeout, **kwargs):
    outcome = real_process(command, cwd, env, logs, timeout, **kwargs)
    if "test-boundary.mjs" in command and "--candidate" not in command:
        outcome["exit_code"] = 0
    return outcome
with patch.object(r, "run_process", side_effect=bad_baseline):
    assert r.execute(case) == 1
report = r.read_json(next(case.glob("saju-verify-*/report.json")))
assert [step["status"] for step in report["steps"]] == ["passed", "passed", "failed", "not-run"]
assert "Unexpected baseline exit: 0" in report["error"]
assert report["extracted_unchanged"] == {"calendar": True, "name": True}
results.append({"check": "real-baseline-with-unexpected-success-stops-candidate", "passed": True, "report": report["run_directory"] + "/report.json"})

# A write into extracted input after an otherwise valid reproduction must
# fail integrity and stop the remaining command plan. Only a review fixture
# is altered; both original and copied ZIP inputs remain untouched.
case = BASE / "extracted-source-mutation"
case.mkdir()
def mutated_reproduction(command, cwd, env, logs, timeout, **kwargs):
    outcome = real_process(command, cwd, env, logs, timeout, **kwargs)
    if "reproduce.mjs" in command:
        target = Path(cwd) / "candidate/name-boundary.ts"
        target.write_bytes(target.read_bytes() + b"\n// synthetic reviewer mutation\n")
    return outcome
with patch.object(r, "run_process", side_effect=mutated_reproduction):
    assert r.execute(case) == 1
report = r.read_json(next(case.glob("saju-verify-*/report.json")))
assert [step["status"] for step in report["steps"]] == ["passed", "failed", "not-run", "not-run"]
assert "Extracted capsule changed after name-reproduction: name" in report["error"]
assert report["extracted_unchanged"] == {"calendar": True, "name": False}
results.append({"check": "extracted-source-mutation-stops-later-commands", "passed": True, "report": report["run_directory"] + "/report.json"})

r.write_json(REVIEW / "supplemental-results.json", {"checks": results, "passed": len(results), "failed": 0})
print(json.dumps({"passed": len(results), "failed": 0, "checks": [row["check"] for row in results]}, indent=2))
