# Independent review: combined SaJu standalone verifier

Review date: 2026-10-09 UTC.

**Result: accepted within the bounded tooling-only scope. No blocking findings.** The frozen distributable independently passed its 23 self-tests, a real relocated four-command execution, and eight supplementary reviewer checks. This review does not approve application integration or deployment.

## Frozen inputs reviewed

The implementer confirmed the freeze before final acceptance. The reviewer read the actual runner, tests, guide, plan, manifest, and the capsule entrypoints and supporting harnesses. Final file hashes were checked again after execution.

| File | SHA-256 |
| --- | --- |
| `run.py` | `94bf54a0bacc9f53323b0d63866f5944b08b9f8cc4921c7567597027e75fe24d` |
| `tests/test_runner.py` | `82755a17f7b7e982b2c4a2a00e816b177504ebc24d7ac679769bd45291c4e9e9` |
| `README.md` | `73fb7dc595364fe6eb9f02693d0140e61598af96e766f3fd831d97f0e2109b96` |
| `docs/PLAN.md` | `758f75980666c396450ced132f9a77492c561a6814b3d4bd708cfa77c1672c47` |
| `RUNNER_INTEGRITY.json` | `6cb022932efb1c4ad180931bc20d3cb715e6178cc334566fdeacd889b0777029` |

Final `SaJu_Combined_Standalone_Verifier_20261009.zip`: **378,567 bytes**, SHA-256 `2a641dd478411a65cd48428492e8d8fd7b7245f4c15f51acd8bde2864ec69e90`.

The bundled calendar ZIP is exactly 200,403 bytes with SHA-256 `b6eea7a14b89f1d320c893b75f80f4419eea47364362a6cd3d8e1795afeb4aac`. The name ZIP is exactly 277,850 bytes with SHA-256 `c3d8d90e14b607ff20b3a937db71b4dccb25b288203944f616a8b06325aaa77d`.

## Independent execution evidence

The reviewer independently unpacked the exact final distributable under `review/final ZIP relocated/`, then invoked it from the separate `review/unrelated working directory/`. Both paths include spaces. Only existing Python, Node and Git were used; no packages or external sources were fetched.

The final self-test execution passed **23/23** tests. The real final run created the unique directory `outputs/saju-verify-5q5zby_t/`, exited 0, and ran the four fixed commands serially:

| Step | Exit | Verified result |
| --- | --- | --- |
| Calendar verifier | 0 | 3 expected baseline assertion failures; 17 passing candidate groups; 73,414 dates; 73,413 transitions; 900 preservation comparisons; 27 instants across 7 timezones; disposable-copy patch validation |
| Name reproduction | 0 | 28 named and 896 generated cases, exact observations and controls, unchanged snapshots |
| Name baseline | 1 | 986 checks: 968 passed and the exact 18 frozen failures, including their identities and assertion messages |
| Name candidate | 0 | 987 checks passed, exact result identities and parser/helper hashes |

Final report: `outputs/saju-verify-5q5zby_t/report.json`, SHA-256 `d9d933196d2f7e07e4053072b15273a8b5af6d42840a1f3a1a797afdaf9842d0`.

The report verifies 43 calendar and 106 name delivery-manifest files, plus 28 calendar and 26 name frozen-manifest files. Complete extracted file/directory inventories and runner/archive integrity matched before and after. Both capsules report optional original-checkout verification as **not requested**.

A prior independent copied-bundle run also passed from the unrelated working directory with deliberately invalid inherited Node hooks, Node module path, name-output destination, and Git configuration. Those settings were omitted from child environments. It created a different output directory, `outputs/saju-verify-t2vzvk4l/`. Its code and tests are identical to the final freeze; its guide predates only the companion-QA-archive documentation clarification. The exact final ZIP was then separately retested as described above.

Runtime observed: Linux, Python 3.12.14, Node v24.19.0 and Git 2.52.0. Executable paths and binary hashes are recorded in the reports.

## Negative tests and source inspection

The supplied tests independently exercised missing/corrupt archives, traversal and path collisions, symlinks, fresh destinations, member size limits, source inventories, manifest tampering, malformed/duplicate/nonfinite JSON, unexpected expected-red identities/errors/exits, false candidate counts, CLI command-hook rejection, sanitized environments, timeouts, process-group descendants, bounded stdout, and fail-fast orchestration.

The reviewer added eight checks in `supplemental_checks.py`, all passing:

1. Archive entry-count limit is enforced before extraction writes.
2. Aggregate expanded-size limit is enforced before extraction writes.
3. A C0 control character in a ZIP path is rejected before writes.
4. A FIFO/special-file ZIP member is rejected before writes.
5. Timeout kills an inherited-pipe descendant even after its process leader has exited; the descendant's delayed marker never appears.
6. Stderr overflow is a failure and its retained log stays at the configured 8,192-byte test cap.
7. A real baseline result with a synthetically changed exit 0 fails; candidate remains `not-run`.
8. A synthetic change to an extracted source fixture after real reproduction fails integrity; baseline and candidate remain `not-run`.

The last two tests retain complete failed reports and logs under `supplemental/`. Their process-boundary substitutions and fixture mutation are explicitly reviewer-only; the production command plan contains no user-supplied commands or hooks. No implementation, supplied test, guide, archive, or old-checkout file was edited by the reviewer.

Source inspection confirmed hard-coded input pins, new unique extraction/output directories, path/type/collision/size preflight, regular-file and hash checks, complete capsule file-manifest coverage, exact name result comparison, shell-free fixed argument arrays, per-step ceilings, process-group termination, bounded command streams, fail-fast sequencing, and final integrity checks. Calendar and name entrypoints derive runtime paths from their own extracted location. The historical author-checkout path is provenance, and the optional checkout arguments are never passed.

## Separate custody comparison and limits

The reviewer separately performed a **read-only** before/after custody inventory of the existing old checkout and original ZIP locations. This is distinct from the runner's own optional checkout check, which stayed not requested. All 232 checkout entries, including 177 regular files and Git metadata, matched by path/type and file bytes; all four original/bundled archive copies matched their initial sizes and hashes. These inventories bracket the exact-final-ZIP run and supplementary checks. They do not retroactively attest to activity before that window or prove absence of all external reads.

All reviewer-generated files are under `review/`. No network, browser, desktop, Library, GitHub, Drive, credential, installation, commit, publication, or deployment action was used.

Acceptance is limited to these pinned historical capsules at source `843a4a088a9e20760421b4c81f890d026a53ae6b`. Latest reported source `2709bb7` remains unavailable; the denied restoration stays held. This is not evidence of current-source compatibility, a full app build/typecheck/lint/module graph, HTTP/database integration, native browser/WebGL behavior, or a live-site fix. Calendar tests retain the historical anchor convention and explicit VM seams. Name tests retain the throwing lunar seam, the 50-UTF-16-unit limit, and existing malformed-input/grapheme limitations.

The runner is not an OS, filesystem, or network sandbox, and its manifests are not authenticity signatures. Trusted tools/host and no concurrent filesystem attacker remain assumptions. Linux was exercised; macOS portability was not independently tested. Windows is expressly unsupported. Output location is operator-selected, so custody conclusions apply to the reviewed invocations with outputs placed under `review/`.

## Evidence map

- `final-selftests.log`: exact-final-package self-test output.
- `final-relocated-run.log`: exact-final-package four-step execution output.
- `final-zip-independent-verification.json`: archive hash and independent invocation records.
- `independent-summary.json`: final file hashes, both successful run summaries, manifest counts and custody result.
- `supplemental-results.json` and `supplemental-checks.log`: eight additional checks and retained failure-report paths.
- `originals-before-second-run.json` and `originals-after-second-run.json`: identical read-only custody inventories.
- `REVIEW_EVIDENCE_SHA256.json`: hashes of the review report and key independent evidence files.
