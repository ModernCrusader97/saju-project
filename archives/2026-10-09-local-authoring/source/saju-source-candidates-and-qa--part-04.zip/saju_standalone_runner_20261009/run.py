#!/usr/bin/env python3
"""Fixed, dependency-free verification of two pinned historical SaJu capsules.

This is an integrity/reproduction tool, not an OS or network sandbox.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import selectors
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time
import zipfile

BUNDLE = Path(__file__).resolve().parent
HEAD = "843a4a088a9e20760421b4c81f890d026a53ae6b"
PARSER_SHA = "7880ae0a8808631918cc3d33ac4acc39955443fac9c4d24acc11077b17e220cf"
HELPER_SHA = "4d84f006107e4b30aa60598574fdd4a6160fef03d25a7743e6a29b3e6887f53f"
CAPSULES = (
    {"id": "calendar", "filename": "SaJu_Standalone_Orbital_Calendar_Fix_QA_20261009_0138.zip", "size": 200403,
     "sha256": "b6eea7a14b89f1d320c893b75f80f4419eea47364362a6cd3d8e1795afeb4aac", "root": "saju-orbital-calendar-candidate"},
    {"id": "name", "filename": "SaJu_Standalone_Name_Boundary_Fix_QA_20261009_0155.zip", "size": 277850,
     "sha256": "c3d8d90e14b607ff20b3a937db71b4dccb25b288203944f616a8b06325aaa77d", "root": "saju-name-boundary-candidate"},
)
METRICS = {"boundaryDates": 24, "supportedDates": 73414, "adjacentDayTransitions": 73413,
           "invalidDateInputs": 24, "rejectedClockCases": 3, "rejectedClockAssertions": 9,
           "preservationComparisons": 900, "ownerAndFriendVariantsEach": 15, "timezoneInstants": 27, "timezones": 7}
NO_CHECKOUT = {"requested": False, "status": "not-requested", "verified": False}
MAX_MEMBER_BYTES = 8 * 1024 * 1024
MAX_ARCHIVE_BYTES = 32 * 1024 * 1024
MAX_MEMBERS = 1000
LOG_LIMIT = 1024 * 1024
STEP_PLAN = (
    ("calendar", "verify.mjs", (), 90),
    ("name-reproduction", "reproduce.mjs", (), 15),
    ("name-baseline", "test-boundary.mjs", (), 15),
    ("name-candidate", "test-boundary.mjs", ("--candidate",), 15),
)


class VerificationError(Exception):
    pass


def require(condition, message):
    if not condition:
        raise VerificationError(message)


def digest(path):
    require(path.is_file() and not path.is_symlink(), f"Not a regular file: {path}")
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def parse_json(text):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, f"Duplicate JSON key: {key}")
            result[key] = value
        return result
    def constant(value):
        raise VerificationError(f"Nonfinite JSON number: {value}")
    try:
        return json.loads(text, object_pairs_hook=pairs, parse_constant=constant)
    except (ValueError, TypeError) as error:
        raise VerificationError(f"Malformed JSON: {error}") from error


def read_json(path):
    require(path.is_file() and not path.is_symlink(), f"Missing regular JSON result: {path}")
    require(path.stat().st_size <= MAX_MEMBER_BYTES, f"JSON size limit: {path}")
    try:
        return parse_json(path.read_text(encoding="utf-8"))
    except UnicodeError as error:
        raise VerificationError(f"Invalid UTF-8 JSON: {path}") from error


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def relative_name(name):
    require(isinstance(name, str) and bool(name) and "\\" not in name and ":" not in name
            and not any(ord(char) < 32 for char in name), f"Unsafe relative path: {name!r}")
    require(not name.startswith("/") and all(part not in ("", ".", "..") for part in name.split("/")),
            f"Unsafe relative path: {name!r}")
    return PurePosixPath(name)


def verify_archives(directory):
    results = []
    for capsule in CAPSULES:
        path = directory / capsule["filename"]
        require(path.is_file() and not path.is_symlink(), f"Archive missing or unreadable: {path}")
        require(path.stat().st_size == capsule["size"], f"Archive size mismatch: {path.name}")
        actual = digest(path)
        require(actual == capsule["sha256"], f"Archive hash mismatch: {path.name}")
        results.append({**capsule, "observed_sha256": actual})
    return results


def safe_extract(archive, destination):
    """Preflight the entire ZIP; never use extractall or honor archive permissions."""
    require(not destination.exists() and not destination.is_symlink(), "Extraction destination must be fresh")
    try:
        with zipfile.ZipFile(archive) as z:
            entries = z.infolist()
            require(0 < len(entries) <= MAX_MEMBERS, "Archive member count limit")
            names = {}
            spellings = {}
            total = 0
            for entry in entries:
                require(entry.orig_filename == entry.filename, "Truncated ZIP member name")
                name = entry.filename[:-1] if entry.is_dir() else entry.filename
                relative_name(name)
                require(name.casefold() not in names, f"Duplicate/case-colliding member: {name}")
                names[name.casefold()] = (name, entry.is_dir())
                for component in (PurePosixPath(name), *PurePosixPath(name).parents):
                    if str(component) == ".":
                        continue
                    spelling = str(component)
                    require(spellings.get(spelling.casefold(), spelling) == spelling,
                            f"Case-colliding parent path: {name}")
                    spellings[spelling.casefold()] = spelling
                kind = stat.S_IFMT(entry.external_attr >> 16)
                require(kind in (0, stat.S_IFDIR if entry.is_dir() else stat.S_IFREG),
                        f"Nonregular/symlink ZIP member: {name}")
                require(not entry.flag_bits & 1, "Encrypted ZIP member is unsupported")
                require(entry.compress_type in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED), "Unsupported ZIP compression")
                require(0 <= entry.file_size <= MAX_MEMBER_BYTES, "Archive member size limit")
                total += entry.file_size
                require(total <= MAX_ARCHIVE_BYTES, "Archive expanded size limit")
            for name, _ in names.values():
                for parent in PurePosixPath(name).parents:
                    if str(parent) != "." and str(parent).casefold() in names:
                        require(names[str(parent).casefold()][1], f"Archive file/directory conflict: {name}")
            destination.mkdir(mode=0o700)
            for entry in entries:
                target = destination.joinpath(*PurePosixPath(entry.filename).parts)
                if entry.is_dir():
                    target.mkdir(parents=True, exist_ok=True, mode=0o700)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                written = 0
                with z.open(entry) as source, target.open("xb") as output:
                    while block := source.read(65536):
                        written += len(block)
                        require(written <= entry.file_size and written <= MAX_MEMBER_BYTES, "Archive stream size limit")
                        output.write(block)
                require(written == entry.file_size, f"ZIP member length mismatch: {entry.filename}")
    except (zipfile.BadZipFile, OSError, RuntimeError) as error:
        raise VerificationError(f"Archive extraction failed: {error}") from error


def inventory(root):
    result = {}
    require(root.is_dir() and not root.is_symlink(), f"Not a regular directory: {root}")
    for directory, dirs, files in os.walk(root, followlinks=False):
        for name in sorted(dirs + files):
            path = Path(directory) / name
            require(not path.is_symlink(), f"Unexpected symlink: {path}")
            key = path.relative_to(root).as_posix()
            if path.is_dir():
                result[key + "/"] = {"type": "directory"}
            else:
                require(path.is_file(), f"Unexpected nonregular file: {path}")
                result[key] = {"type": "file", "bytes": path.stat().st_size, "sha256": digest(path)}
    return dict(sorted(result.items()))


def verify_hash_map(root, hashes):
    require(isinstance(hashes, dict) and bool(hashes), "Empty or malformed hash manifest")
    for name, expected in hashes.items():
        relative_name(name)
        require(isinstance(expected, str) and re.fullmatch(r"[a-f0-9]{64}", expected), f"Invalid hash: {name}")
        require(digest(root.joinpath(*PurePosixPath(name).parts)) == expected, f"Manifest hash mismatch: {name}")
    return len(hashes)


def verify_capsule(capsule, extraction):
    root = extraction / capsule["root"]
    delivery = read_json(extraction / "DELIVERY_INTEGRITY.json")
    require(delivery.get("source_reference_head") == HEAD, "Wrong source reference")
    delivery_base = root if capsule["id"] == "calendar" else extraction
    count = verify_hash_map(delivery_base, delivery.get("files"))
    prefix = capsule["root"] + "/" if capsule["id"] == "calendar" else ""
    actual = {name for name, data in inventory(extraction).items() if data["type"] == "file"}
    require(actual == {prefix + name for name in delivery["files"]} | {"DELIVERY_INTEGRITY.json"}, "Unexpected/unlisted capsule file")
    if capsule["id"] == "calendar":
        frozen = read_json(root / "artifact-sha256.json")["files"]
    else:
        frozen = {}
        for line in (root / "frozen-manifest.sha256").read_text().splitlines():
            match = re.fullmatch(r"([a-f0-9]{64})  (.+)", line)
            require(match is not None, "Malformed frozen manifest line")
            sha, name = match.groups()
            require(name not in frozen, "Duplicate frozen manifest path")
            frozen[name] = sha
    frozen_count = verify_hash_map(root, frozen)
    return {"delivery_files": count, "frozen_files": frozen_count,
            "delivery_manifest_sha256": digest(extraction / "DELIVERY_INTEGRITY.json"),
            "source_and_harness_hashes": {name: data["sha256"] for name, data in inventory(root).items()
                                         if data["type"] == "file" and (name.endswith((".mjs", ".ts", ".tsx", ".patch")) or name.startswith(("source/", "snapshots/")))}}


def run_process(command, cwd, env, logs, timeout, log_limit=LOG_LIMIT):
    """Internal process primitive. CLI exposes only the fixed STEP_PLAN."""
    logs.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    process = subprocess.Popen(command, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    streams = {"stdout": process.stdout, "stderr": process.stderr}
    counts = {"stdout": 0, "stderr": 0}
    termination = None
    selector = selectors.DefaultSelector()
    handles = {}
    try:
        for name, stream in streams.items():
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, selectors.EVENT_READ, name)
            handles[name] = (logs / (name + ".log")).open("xb")
        while selector.get_map() or process.poll() is None:
            if time.monotonic() - started >= timeout:
                termination = "timeout"
                break
            for key, _ in selector.select(timeout=min(0.05, max(0, timeout - (time.monotonic() - started)))):
                block = os.read(key.fileobj.fileno(), 65536)
                if not block:
                    selector.unregister(key.fileobj)
                    continue
                name = key.data
                remaining = max(0, log_limit - counts[name])
                handles[name].write(block[:remaining])
                counts[name] += len(block)
                if counts[name] > log_limit:
                    termination = "log-limit"
                    break
            if termination:
                break
        if termination:
            try: os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError: pass
        process.wait(timeout=2)
    finally:
        if process.poll() is None:
            try: os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError: pass
            process.wait(timeout=2)
        selector.close()
        for handle in handles.values(): handle.close()
        for stream in streams.values(): stream.close()
    return {"command": list(command), "cwd": str(cwd), "exit_code": process.returncode,
            "termination": termination, "timeout_seconds": timeout,
            "duration_seconds": round(time.monotonic() - started, 4),
            "log_bytes_observed": counts, "log_limit_per_stream": log_limit,
            "logs": {name: {"path": str(logs / (name + ".log")), "sha256": digest(logs / (name + ".log")),
                            "bytes": (logs / (name + ".log")).stat().st_size} for name in streams}}


def validate_calendar(text, exit_code):
    require(exit_code == 0, f"Calendar verifier unexpected exit: {exit_code}")
    lines = [line[len("VERIFIED "):] for line in text.splitlines() if line.startswith("VERIFIED ")]
    require(len(lines) == 1, "Expected exactly one calendar VERIFIED result")
    data = parse_json(lines[0])
    require(isinstance(data, dict), "Malformed calendar result")
    require(data.get("redFailures") == 3 and data.get("greenGroups") == 17, "Unexpected calendar red/green counts")
    for key, value in METRICS.items():
        require(type(data.get(key)) is int and data[key] == value, f"Calendar metric mismatch: {key}")
    require(data.get("oldCheckout") == {"checked": False, "reason": "No --source-checkout supplied; preserved snapshots were checked."}, "Calendar original checkout must be not-requested")
    require(data.get("patch") == {"dryRun": "passed", "appliedToDisposableCopy": "passed", "matchesCandidateBytes": True,
                                 "targetFiles": 1, "sha256": "02ea4336e6b2054c32bcbf0bbb2399113064335bc14e310e00f19b9d0f634a2d"}, "Unexpected calendar patch verification")
    require("PASS 12 hash-pinned source snapshots" in text, "Missing calendar snapshot confirmation")
    return {"status": "passed", "expected_baseline_failures": 3, "candidate_groups_passed": 17,
            "metrics": METRICS, "original_checkout": "not-requested", "patch": data["patch"]}


def validate_name(data, frozen_expected, mode, exit_code):
    require(isinstance(data, dict) and isinstance(data.get("summary"), dict) and isinstance(data.get("results"), list), "Malformed name result")
    summary = data["summary"]
    baseline = mode == "baseline"
    require(exit_code == (1 if baseline else 0), f"Unexpected {mode} exit: {exit_code}")
    require(summary.get("mode") == mode, "Name mode mismatch")
    require(summary.get("originalCheckoutVerification") == NO_CHECKOUT, "Name original checkout must be not-requested")
    require(summary.get("snapshotsPreserved") is True and summary.get("historicalParserSha256") == PARSER_SHA, "Name source/hash mismatch")
    require(summary.get("helperSha256") == (None if baseline else HELPER_SHA), "Name helper hash mismatch")
    expected_counts = (986, 968, 18) if baseline else (987, 987, 0)
    for key, value in zip(("tests", "passed", "failed"), expected_counts):
        require(type(summary.get(key)) is int and summary[key] == value, f"Unexpected name {key}")
    require(data["results"] == frozen_expected["results"], "Name result identities, outcomes or assertion errors differ from frozen expectations")
    require(len(data["results"]) == summary["tests"], "Name result count mismatch")
    require(sum(item.get("passed") is True for item in data["results"]) == summary["passed"], "Name pass count mismatch")
    require(sum(item.get("passed") is False for item in data["results"]) == summary["failed"], "Name failure count mismatch")
    return {"status": "expected-baseline-failure" if baseline else "passed", **summary,
            "expected_failure_names": [item["name"] for item in data["results"] if item["passed"] is False]}


def validate_reproduction(data, source_root, expected_snapshot):
    require(isinstance(data, dict), "Malformed reproduction result")
    require(data.get("head") == HEAD and data.get("parserSha256") == PARSER_SHA, "Reproduction source mismatch")
    require(data.get("errorModuleSha256") == "a1533c1b2c00755ed076e978990d0fb8119ec80ff5599096da4781990b54285a", "Reproduction error module mismatch")
    require(data.get("sourceRoot") == str(source_root), "Reproduction used an unexpected source path")
    require(data.get("snapshotFilesHashed") == 4 and data.get("snapshotsPreserved") is True, "Reproduction snapshot mismatch")
    require(data.get("originalCheckoutVerification") == NO_CHECKOUT, "Reproduction checkout must be not-requested")
    expected_totals = {"namedWellFormedInputs": 28, "namedFailures": ["emoji-at-50-51", "astral-cjk-at-50-51", "24-emojis-bmp-emoji", "whitespace-around-split-boundary"],
                       "generatedWellFormedInputs": 896, "generatedFailures": 9, "invalidNameControls": 4, "alreadyMalformedControls": 2}
    require(data.get("totals") == expected_totals, "Reproduction totals mismatch")
    # Compare semantic observations to pinned evidence, excluding historical paths/runtime.
    for key in ("observations", "matrix", "invalidNameControls", "alreadyMalformedControls", "method", "result"):
        require(data.get(key) == expected_snapshot.get(key), f"Reproduction evidence mismatch: {key}")
    return {"status": "passed", "totals": expected_totals, "original_checkout": "not-requested"}


def clean_environment(run_dir, node, git):
    home = run_dir / "runtime-home"
    temporary = run_dir / "temporary"
    home.mkdir()
    temporary.mkdir()
    return {"PATH": os.pathsep.join(dict.fromkeys([str(node.parent), str(git.parent), os.defpath])),
            "HOME": str(home), "TMPDIR": str(temporary), "TMP": str(temporary), "TEMP": str(temporary),
            "TZ": "UTC", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8", "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_CONFIG_GLOBAL": os.devnull, "GIT_OPTIONAL_LOCKS": "0", "GIT_TERMINAL_PROMPT": "0"}


def verify_bundle():
    manifest = read_json(BUNDLE / "RUNNER_INTEGRITY.json")
    require(manifest.get("format") == 1, "Unsupported runner integrity format")
    count = verify_hash_map(BUNDLE, manifest.get("files"))
    require("run.py" in manifest["files"] and "tests/test_runner.py" in manifest["files"], "Runner integrity manifest is incomplete")
    return {"files": count, "manifest_sha256": digest(BUNDLE / "RUNNER_INTEGRITY.json"), "hashes": manifest["files"]}


def execute(output_parent):
    require(os.name == "posix", "This runner requires POSIX process-group support (Linux/macOS)")
    require(sys.version_info >= (3, 11), "Python 3.11 or newer is required")
    require(output_parent.is_dir(), "Output parent must be an existing directory")
    run_dir = Path(tempfile.mkdtemp(prefix="saju-verify-", dir=output_parent.resolve()))
    print(f"Evidence directory: {run_dir}", flush=True)
    report = {"format": 1, "status": "running", "started_at": datetime.now(timezone.utc).isoformat(),
              "source_reference_head": HEAD, "latest_2709bb7": "unavailable; not checked",
              "integrated": False, "live": False, "original_checkout": "not-requested",
              "sandbox_claim": False, "python": sys.version, "run_directory": str(run_dir),
              "steps": [{"id": step[0], "status": "not-run"} for step in STEP_PLAN]}
    extracted = {}
    before = {}
    started = time.monotonic()
    try:
        report["runner_integrity"] = verify_bundle()
        report["archives_before"] = verify_archives(BUNDLE / "capsules")
        for capsule in CAPSULES:
            dest = run_dir / ("extracted-" + capsule["id"])
            safe_extract(BUNDLE / "capsules" / capsule["filename"], dest)
            extracted[capsule["id"]] = dest
            before[capsule["id"]] = inventory(dest)
            write_json(run_dir / (capsule["id"] + "-inventory-before.json"), before[capsule["id"]])
            report.setdefault("capsule_integrity", {})[capsule["id"]] = verify_capsule(capsule, dest)
        tools = {}
        for name in ("node", "git"):
            found = shutil.which(name)
            require(found is not None, f"Required local tool missing: {name}")
            tools[name] = Path(found).resolve()
            require(tools[name].is_file(), f"Invalid local tool: {name}")
        env = clean_environment(run_dir, tools["node"], tools["git"])
        report["environment_policy"] = "Allowlisted environment; no inherited NODE_OPTIONS, NODE_PATH, Git config or credentials. Not a sandbox."
        for name, executable in tools.items():
            result = run_process([str(executable), "--version"], run_dir, env, run_dir / "logs" / (name + "-version"), 5)
            require(result["termination"] is None and result["exit_code"] == 0, f"Cannot verify {name} version")
            version = (run_dir / "logs" / (name + "-version") / "stdout.log").read_text().strip()
            if name == "node": require(re.fullmatch(r"v24\.\d+\.\d+", version), "Node 24 is required")
            report.setdefault("tools", {})[name] = {"path": str(executable), "version": version, "sha256": digest(executable)}
        calendar_root = extracted["calendar"] / CAPSULES[0]["root"]
        name_root = extracted["name"] / CAPSULES[1]["root"]
        expected_red = read_json(name_root / "red-results.json")
        expected_green = read_json(name_root / "green-results.json")
        expected_reproduction = read_json(name_root / "evidence.json")

        def step_action(index):
            identity, script, arguments, timeout = STEP_PLAN[index]
            entry = report["steps"][index]
            entry["status"] = "running"
            write_json(run_dir / "report.json", report)
            require(time.monotonic() - started < 160, "Overall run timeout before next command")
            cwd = calendar_root if identity == "calendar" else name_root
            output = run_dir / "results" / identity
            output.mkdir(parents=True)
            step_env = {**env}
            if identity != "calendar": step_env["SAJU_BOUNDARY_OUTPUT_DIR"] = str(output)
            command = [str(tools["node"]), "--disable-warning=ExperimentalWarning", script, *arguments]
            result = run_process(command, cwd, step_env, run_dir / "logs" / identity,
                                 min(timeout, max(0.1, 160 - (time.monotonic() - started))))
            entry["process"] = result
            require(result["termination"] is None, f"{identity} terminated: {result['termination']}")
            stdout = Path(result["logs"]["stdout"]["path"]).read_text(encoding="utf-8")
            stderr = Path(result["logs"]["stderr"]["path"]).read_text(encoding="utf-8")
            if identity == "calendar":
                require(stderr == "", "Unexpected calendar stderr")
                entry["validation"] = validate_calendar(stdout, result["exit_code"])
                require(list(output.iterdir()) == [], "Unexpected calendar result files")
            elif identity == "name-reproduction":
                require(result["exit_code"] == 0 and stderr == "", "Unexpected reproduction exit/diagnostic")
                require({p.name for p in output.iterdir()} == {"evidence.json", "snapshot-before.json", "snapshot-after.json"}, "Unexpected reproduction files")
                data = read_json(output / "evidence.json")
                entry["validation"] = validate_reproduction(data, name_root / "snapshots/original", expected_reproduction)
                snapshots = read_json(name_root / "snapshots/manifest.json")
                require(read_json(output / "snapshot-before.json") == snapshots == read_json(output / "snapshot-after.json"), "Reproduction snapshots changed")
                printed = parse_json(stdout)
                require(printed == {key: value for key, value in data.items() if key not in ("observations", "matrix", "invalidNameControls", "alreadyMalformedControls")}, "Reproduction stdout/file mismatch")
            else:
                baseline = identity == "name-baseline"
                filename = "red-results.json" if baseline else "green-results.json"
                require({p.name for p in output.iterdir()} == {filename}, "Unexpected name result files")
                data = read_json(output / filename)
                entry["validation"] = validate_name(data, expected_red if baseline else expected_green, "baseline" if baseline else "candidate", result["exit_code"])
                require(parse_json(stdout) == data["summary"], "Name stdout/file mismatch")
                expected_stderr = "".join("FAIL " + row["name"] + ": " + row["error"] + "\n" for row in data["results"] if not row["passed"])
                require(stderr == expected_stderr, "Unexpected name stderr/harness diagnostic")
            for key, destination in extracted.items():
                require(inventory(destination) == before[key], f"Extracted capsule changed after {identity}: {key}")
            require(verify_archives(BUNDLE / "capsules") == report["archives_before"], "Input archive changed during execution")
            entry["status"] = entry["validation"]["status"]
            entry["extracted_capsules_unchanged"] = True
            entry["evidence"] = inventory(output)
            print(f"{identity}: {entry['status']}", flush=True)
            write_json(run_dir / "report.json", report)

        for index in range(len(STEP_PLAN)):
            step_action(index)
        report["status"] = "passed"
    except (VerificationError, OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
        report["status"] = "failed"
        report["error"] = f"{type(error).__name__}: {error}"
        for entry in report["steps"]:
            if entry["status"] == "running": entry["status"] = "failed"
    except KeyboardInterrupt:
        report["status"] = "interrupted"
        report["error"] = "Interrupted by the operator"
    finally:
        try:
            report["archives_after"] = verify_archives(BUNDLE / "capsules")
            for key, destination in extracted.items():
                after = inventory(destination)
                write_json(run_dir / (key + "-inventory-after.json"), after)
                unchanged = after == before[key]
                report.setdefault("extracted_unchanged", {})[key] = unchanged
                require(unchanged, f"Final extracted capsule changed: {key}")
            report["runner_integrity_after"] = verify_bundle()
            if "runner_integrity" in report:
                require(report["runner_integrity_after"] == report["runner_integrity"], "Runner files changed")
        except (VerificationError, OSError, ValueError, KeyError, TypeError) as error:
            report["status"] = "failed"
            report["final_integrity_error"] = f"{type(error).__name__}: {error}"
        report["ended_at"] = datetime.now(timezone.utc).isoformat()
        report["duration_seconds"] = round(time.monotonic() - started, 4)
        try:
            report["evidence_inventory"] = inventory(run_dir)
        except (VerificationError, OSError) as error:
            report["status"] = "failed"
            report["evidence_inventory"] = {}
            report["evidence_inventory_error"] = str(error)
        report["evidence_inventory"].pop("report.json", None)
        write_json(run_dir / "report.json", report)
    print(f"Result: {report['status']}; report: {run_dir / 'report.json'}", flush=True)
    return 0 if report["status"] == "passed" else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-parent", type=Path, default=Path.cwd(), help="Existing directory for a new retained saju-verify-* directory")
    args = parser.parse_args()
    try:
        return execute(args.output_parent)
    except (VerificationError, OSError) as error:
        print(f"FAILED: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
