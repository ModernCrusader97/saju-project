# Remaining surface assessment

2026-10-09. The read-only source is the old surviving commit 843a4a088a9e20760421b4c81f890d026a53ae6b. Latest maintenance commit 2709bb7 cannot currently be restored within the selected Library scope. No bypass, retrieval retry, deployment, browser, or credential action was attempted.

The bounded UI/export pass found the passport PNG title as a concrete isolated defect; the reviewed candidate and evidence are preserved in Library item libfile_f915441e3e788191b94a59865a42aaf4. Other capture/image/focus/clipboard paths overlap previously queued fixes and were not patched from the old snapshot. The queried ordinary UI files expose no file-import/FileReader flow. That is a scoped search result, not a claim about absent features in latest source.

Old SajuInputModal has label/selection semantics gaps, but their relationship to the lost v27 dialog-accessibility patch is unverified. No competing patch was created. Old PlanetStudio still parses birth data from URL parameters; the later canonical session journey is unavailable, so broadening that old flow would risk preparing incompatible work.

The shared response parser checks only a shallow envelope. No ordinary route producer was found that emits the malformed data needed to establish a separate reachable issue. Normal AI provider execution is disabled in this snapshot. Atomic friend append already uses json_insert in one owner-scoped UPDATE, so no read-modify-write lost-update patch is warranted. Chat persistence and saved summary work are already queued and excluded.

The independent read-only audit records a synthetic-test-only validator false pass for inherited object-property names, conditional on a provider violating its response schema. Keep this as a diagnostic note until current-source reconciliation; it is not evidence of a current production interpretation defect.

The separate question-boundary audit is confirmed reuse coverage for the existing reviewed helper, not a new truncation algorithm. It ran 51/51 characterization checks against snapshot-backed old route/AI/store bodies with local import seams. Valid 499-BMP-plus-🙂 text becomes a lone high surrogate at all three 500-unit cuts (initial reading route, chat route, AI cleaner), and reaches template output, storage bind arguments and response JSON. Actual D1/provider transport was not exercised. JSON escaping preserves that malformed string; direct UTF-8 and URLSearchParams replace it, while encodeURIComponent throws. Reuse the exact shared helper before the first destructive cut, preserving each canonical trim/cap order. Applying it after a split cannot recover the lost low surrogate. Source and probe evidence remain at ../saju_question_boundary_investigation_20261009/FINDINGS.md, probe-question-boundaries.mjs, probe-results.json and source-manifest.json. The preserved helper is Library libfile_726c5c1e7c2c8191ae554da0e026a13c; its helper SHA256 is 4d84f006107e4b30aa60598574fdd4a6160fef03d25a7743e6a29b3e6887f53f. Current canonical call sites must be reconciled after restoration, preserving queued atomic chat exchange behavior.

## Integration order once authorized source is readable

1. Restore and hash-verify latest2709bb7 source/history/QA and selected dragon C bytes. Preserve exact prior pins and rollback. The private live v29 state remains separate from queued work.
2. Reconcile the shared 50-UTF16 name canonicalization with the reviewed pair-boundary helper. Extend the existing helper only at actual canonical 500-unit question cuts confirmed in current source; preserve trim/order/caps and atomic chat persistence.
3. Reconcile orbital-calendar delegation to the existing daily-pillar function alongside the queued midnight/tab-return behavior. Run transition/timezone checks against actual current call sites.
4. Integrate only the passport title helper/import/draw hunk. Preserve queued image readiness, cached-load, error and capture fixes. Verify the real native-browser PNG and font selection when an authorized browser is available.
5. Independently verify the restored selected C asset, actual Three animation/bounds/clearance and lifecycle contract before replacing that dragon pin. Keep unapproved pig limbs separate.
6. Run the current application build/type checks and full exact-head maintenance runner, plus focused regressions added by reconciled changes. Historical 48-stage results are not fresh proof. Publication remains under the parent's current batch workflow.

There is no further robust independently verifiable production candidate from this bounded remaining-surface pass. Current-source recovery and integration have higher value than another speculative patch or synthetic test package.
