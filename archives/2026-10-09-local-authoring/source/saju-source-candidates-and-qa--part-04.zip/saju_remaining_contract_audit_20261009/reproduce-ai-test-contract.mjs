import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { stripTypeScriptTypes } from 'node:module';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

// Read the old source unchanged. Replace only its runtime imports with local doubles.
// No real backend, credentials, network, provider, browser, or user data are used.
const sourcePath = fileURLToPath(new URL('../saju_planet_preview/app/api/ai-test/route.ts', import.meta.url));
const source = await readFile(sourcePath, 'utf8');
assert.equal((source.match(/^import /gm) ?? []).length, 2);
const moduleBody = stripTypeScriptTypes(source.replace(/^import .*;\n/gm, ''), { mode: 'strip' })
  .replace(/^export /gm, '');
const loadRoute = new Function('env', 'analyzeSaju', 'fetch', moduleBody + '\nreturn { GET, POST };');
const facts = {
  yearPillar: '경진', monthPillar: '임오', dayPillar: '갑자', hourPillar: '경오', dayMaster: '갑목',
};
const analysis = {
  yearPillar: { gan: '경', ji: '진' }, monthPillar: { gan: '임', ji: '오' },
  dayPillar: { gan: '갑', ji: '자' }, hourPillar: { gan: '경', ji: '오' }, dayMaster: '갑목',
};
let fetchCalls = 0;
let providerAnswer;
const environmentDouble = {
  GEMINI_API_KEY: 'local-test-sentinel-not-a-real-credential',
  DB: { prepare: () => ({ bind: () => ({ first: async () => ({ calls: 1 }) }) }) },
};
const fetchDouble = async (_url, options) => {
  fetchCalls++;
  const requestBody = JSON.parse(options.body);
  const enumKeys = requestBody.generationConfig.responseFormat.text.schema.properties.basisFactIds.items.enum;
  assert.deepEqual(enumKeys, Object.keys(facts));
  return Response.json({ candidates: [{ finishReason: 'STOP', content: { parts: [{ text: JSON.stringify(providerAnswer) }] } }] });
};
const route = loadRoute(environmentDouble, () => analysis, fetchDouble);
const request = () => new Request('https://fixture.invalid/api/ai-test', {
  method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ case: 'known_time' }),
});
const observations = [];
for (const basisId of ['dayMaster', 'unknownFact', 'constructor', 'toString', '__proto__']) {
  providerAnswer = { factEcho: facts, summary: 'Local synthetic fixture.', basisFactIds: [basisId], uncertainty: 'No accuracy claim.' };
  const response = await route.POST(request());
  const result = await response.json();
  assert.equal(response.status, 200);
  assert.equal(result.valid, basisId !== 'unknownFact');
  assert.equal(Object.keys(facts).includes(basisId), basisId === 'dayMaster');
  observations.push({ basisId, declaredBySchema: Object.keys(facts).includes(basisId), acceptedByOldValidator: result.valid });
}
assert.equal(fetchCalls, 5);

// A bound database rejecting its budget query escapes the route's later try/catch.
// This is a conditional error-path observation, not evidence of a real outage.
const budgetFailure = new Error('synthetic budget store unavailable');
const failedBudgetRoute = loadRoute({
  ...environmentDouble,
  DB: { prepare: () => ({ bind: () => ({ first: async () => { throw budgetFailure; } }) }) },
}, () => { throw new Error('Analysis should not run.'); }, () => { throw new Error('Fetch should not run.'); });
await assert.rejects(failedBudgetRoute.POST(request()), (error) => error === budgetFailure);
assert.equal(fetchCalls, 5);

console.log(JSON.stringify({
  sourcePath, sourceSHA256: createHash('sha256').update(source).digest('hex'),
  status: 'OLD_SOURCE_BEHAVIOR_CONFIRMED', observations,
  budgetFailure: 'Handler rejects before its error-response boundary; no provider double called.',
  limits: ['Route imports replaced with local doubles.', 'No provider behavior was observed.', 'No latest or deployed source was available.', 'No application source was changed.'],
}, null, 2));
