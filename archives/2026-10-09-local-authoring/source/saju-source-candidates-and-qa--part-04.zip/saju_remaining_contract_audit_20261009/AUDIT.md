# Remaining SaJu data-contract audit

Date: 2026-10-09 UTC. Read-only application-source audit.

Source: `/workspace/scratch/c9f1a9454187/saju_planet_preview`, HEAD `843a4a088a9e20760421b4c81f890d026a53ae6b`.

This is the surviving **old** checkout. The latest `2709bb7` source was unavailable after restart. These findings do not describe the latest source or deployed site.

## Result

No new, independent ordinary-user-flow defect was established within the requested scope. The remaining concrete candidate is a small false-pass defect in the synthetic AI diagnostic endpoint. It is useful to retain as a later validator correction, but it does not justify claiming another production interpretation fix or continuing a broad speculative audit.

## Confirmed diagnostic-only candidate

`app/api/ai-test/route.ts:47` uses `x in facts` to validate each returned `basisFactIds` entry. The route's own provider schema at line 23 defines the allowed values as `Object.keys(facts)`. These sets differ: `constructor`, `toString`, and `__proto__` are inherited properties, so the validator accepts them even though the schema enum excludes them.

The local reproduction loads the unchanged route source, removes its two imports, strips TypeScript with Node's built-in API, and supplies local doubles for the analysis, budget store, and provider transport. With otherwise matching synthetic fact echoes:

- `dayMaster`: declared by schema, returned `valid: true`
- `unknownFact`: absent from schema, returned `valid: false`
- `constructor`, `toString`, `__proto__`: absent from schema, each returned `valid: true`

Practical scope: an out-of-schema provider answer can be falsely marked valid by this synthetic test. There is no evidence that the real provider emits such a response, and the route already says this is a basic fact comparison rather than a guarantee about free-text accuracy. No production reading, stored user data, or live provider behavior was tested. A correction, if later authorized, should enforce the existing own-key/schema set rather than create new interpretation rules.

## Additional conditional observation

`app/api/ai-test/route.ts:17` awaits the budget database query before the `try` at line 25. A local rejecting database double makes `POST` reject instead of returning the route's JSON error envelope. No analysis or provider transport occurs. This shows an error-boundary gap during a diagnostic budget-store failure; it does not prove an actual outage, the framework's ultimate response body, or a quota bypass. Lower priority than the validator candidate.

## Source map and rejected expansions

| Surface | Evidence and disposition |
| --- | --- |
| `lib/http-client.ts:3-8` | Validates only an object envelope and a string error field. Nested payload validation is shallow, but no in-scope ordinary route producer was found that generates a malformed successful payload. A hand-invented malformed response alone would establish only a hardening opportunity. |
| `lib/ai/doryeong-ai.ts:60-111,131-179` | Provider content and fortune/chat parsers are unreachable in normal preview readings because `configuredProvider()` returns `undefined` at lines 182-184. Do not promote dormant-parser possibilities to current reachable bugs. |
| `lib/ai/doryeong-ai.ts:215-239,280-365` | Reachable preview template generation reconstructs the expected result. Routes validate the category before indexing templates. The known 500-unit question truncation belongs to the existing UTF-16 helper reuse note, not a new independent finding. |
| `lib/saju/input.ts:19-34` | JSON syntax errors and non-object envelopes are deliberately converted to input errors. Existing birth/calendar/name validation work was excluded. |
| `app/api/saju/route.ts`, `app/api/saju/[id]/route.ts`, `app/api/saju/[id]/chat/route.ts`, `app/api/guin/route.ts`, `app/api/guin/[id]/route.ts` | Ordinary route input/storage errors return JSON inside their handlers. Owner isolation, private caching, chat pair atomicity, and friend response/race work were already excluded. No additional independent error-contract issue established. |
| `lib/db/store.ts:16-25` | Stored JSON is trusted after parsing. Demonstrating nested corruption would require an unsupported storage state or an actual legacy record contract. No such record was read or invented. |
| `lib/connector-contract.mts`, `lib/connector-errors.mts` | Starter connector contracts project envelopes and catch transport errors. These do not establish a SaJu data-flow candidate; examples and boilerplate are not sufficient evidence of a reachable app bug. |

## Verification and limits

Run: `node reproduce-ai-test-contract.mjs` from this directory. Node `v24.19.0`; exit code 0. The script asserts the five identifier cases and the rejecting budget-store case. It tests the old source behavior, not a fix. Route SHA-256: `2e1fcb86585e91e96d1fd6ec10936b7f885f75c6890f81ca94b1f2535a8fcbed`.

Application source was not edited. No installs, real credentials, user records, network requests, backend access, browser access, Library retrieval, GitHub changes, or publication occurred. No latest/build/hosted validation is claimed. Stop this bounded audit here pending the parent's scope decision or access to the latest authoritative source.

## Audited source fingerprints

All values are SHA-256 of the unchanged local file bytes.

| File | SHA-256 |
| --- | --- |
| `lib/http-client.ts` | `62b9d80947ebcbcc0b87e2fbea86634c676b30a2cf7a30e7580638fbc667c372` |
| `lib/ai/doryeong-ai.ts` | `5320c0836ef5c9370629bfc5e437777acb2a1669bb078c11e863f16154947c00` |
| `lib/saju/input.ts` | `7880ae0a8808631918cc3d33ac4acc39955443fac9c4d24acc11077b17e220cf` |
| `lib/db/store.ts` | `49a961195f57ba7ed734978c2ebaaa94bff99f3385b44169fa9a11905f9fd6a9` |
| `app/api/saju/route.ts` | `09e995b99dfe5df1344a7c18f9406b156962ac130831b4e8dc4dde219a7bc843` |
| `app/api/saju/[id]/route.ts` | `a961fcf75131ebfe4bd40e3a139370b8d8984efcdb523495f3f0d44b6b9b225d` |
| `app/api/saju/[id]/chat/route.ts` | `a76b1b37f7cd7d2a886c282a57da2750b892f2774a7c529b5f949236a0c646af` |
| `app/api/guin/route.ts` | `d30b39ba805647b315dc006e21e21222669d746bb0eaba59a3e04d1a75ebb145` |
| `app/api/guin/[id]/route.ts` | `8dd73d626b0b06fee452a2c0dbb9dac1f85476d4bda38c18c41e0e7aae899e08` |
| `app/api/ai-test/route.ts` | `2e1fcb86585e91e96d1fd6ec10936b7f885f75c6890f81ca94b1f2535a8fcbed` |
| `lib/connector-contract.mts` | `e1a7b24a8793af34b595690d9b1300c897c7321c14f215cedf58ad95799d7c3e` |
| `lib/connector-errors.mts` | `a22edf13d6873ae832c4a2a0d579fc666c73ec996ef0722d39172649d38f0871` |

Ordinary route error boundaries: `app/api/saju/route.ts:33-49`; `app/api/saju/[id]/route.ts:16-18`; `app/api/saju/[id]/chat/route.ts:33-39`; `app/api/guin/route.ts:56-61`; `app/api/guin/[id]/route.ts:18-20,79-84`. Connector call-site search found no references outside `lib/connectors.ts` and the definitions themselves.
