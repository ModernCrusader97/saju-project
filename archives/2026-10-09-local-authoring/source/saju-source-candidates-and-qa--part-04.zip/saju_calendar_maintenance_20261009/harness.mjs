import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { stripTypeScriptTypes } from 'node:module';
import { fileURLToPath } from 'node:url';
import { compileFunction, createContext } from 'node:vm';

export const ROOT = fileURLToPath(new URL('.', import.meta.url));
export const digest = (bytes) => createHash('sha256').update(bytes).digest('hex');
export const read = (path) => readFileSync(new URL(path, import.meta.url), 'utf8');
const provenanceBytes = read('provenance.json');
assert.equal(digest(provenanceBytes), '4d634dfd633e60cf79802e5c8929e518e7d4973c10b3b20a455ab5ba5bd9312e', 'immutable provenance');
export const provenance = JSON.parse(provenanceBytes);

export function verifySnapshots() {
  for (const [path, expected] of Object.entries(provenance.sourceSnapshotSha256)) {
    assert.equal(digest(read(`source/${path}`)), expected, `original snapshot: ${path}`);
  }
}

// These are verbatim, line-addressed source slices. No calculation or validator
// body is rewritten. Full source-file and per-slice hashes are checked first.
function extractSource() {
  verifySnapshots();
  return provenance.extractions.map((entry) => {
    const full = read(`source/${entry.path}`);
    const lines = full.match(/[^\n]*\n|[^\n]+$/g) ?? [];
    const slice = lines.slice(entry.startLine - 1, entry.endLine).join('');
    assert.equal(digest(slice), entry.sha256, `source slice: ${entry.name}`);
    return { name: entry.name, source: slice };
  });
}

function executable(source, mode = 'strip') {
  // Only ESM declaration wrappers are removed after TypeScript erasure; source
  // calculations are left intact. Transform mode is needed for the ORIGINAL
  // SajuInputError constructor's TypeScript parameter property.
  return stripTypeScriptTypes(source, { mode })
    .replace(/^export (?=(?:function|class)\b)/gm, '');
}

export function loadReference() {
  const slices = extractSource();
  const body = slices.map((entry) => executable(entry.source,
    entry.name === 'input_error' ? 'transform' : 'strip')).join('\n');
  const context = createContext({ Date });
  return compileFunction(`${body}\nreturn { getDailyPillar, parseSolarDate, SajuInputError };`, [], {
    parsingContext: context, filename: 'hash-pinned-original-gregorian-slices.ts',
  })();
}

export function loadOrbital(kind, reference = loadReference()) {
  assert.ok(['original', 'candidate'].includes(kind));
  const path = `${kind === 'original' ? 'source' : 'candidate'}/lib/saju/daily-orbital.ts`;
  const full = read(path);
  if (kind === 'original') {
    assert.equal(digest(full), provenance.sourceSnapshotSha256['lib/saju/daily-orbital.ts']);
  } else {
    const expected = JSON.parse(read('candidate-sha256.json'))['lib/saju/daily-orbital.ts'];
    assert.equal(digest(full), expected, 'candidate source hash');
  }
  const allowedImports = [
    'import { GuinPerson } from "./types";',
    'import { TEN_STEM_SPIRITS } from "../planet/elemental-spirit";',
    ...(kind === 'candidate' ? ['import { getDailyPillar } from "./manse";'] : []),
  ];
  const imports = full.split('\n').filter((line) => line.startsWith('import '));
  assert.deepEqual(imports, allowedImports, 'explicitly bounded import seams');
  // GuinPerson is type-only in this body. TEN_STEM_SPIRITS is unused. Do not
  // execute its unavailable Three.js dependency or pretend to have tested it.
  assert.equal(full.match(/\bTEN_STEM_SPIRITS\b/g)?.length, 1);
  const source = full.split('\n').filter((line) => !allowedImports.includes(line)).join('\n');
  let now = Date.UTC(2000, 0, 1, 12);
  class ClockDate extends Date {
    constructor(...args) { super(...(args.length ? args : [now])); }
    static now() { return now; }
  }
  const context = createContext({ Date: ClockDate });
  const fn = compileFunction(`${executable(source)}\nreturn calculateDailyOrbitalWeather;`, ['getDailyPillar'], {
    parsingContext: context, filename: path,
  })(reference.getDailyPillar);
  return {
    at(instant, owner, friends) {
      now = typeof instant === 'number' ? instant : Date.parse(instant);
      return fn(owner, friends);
    },
  };
}

verifySnapshots();
