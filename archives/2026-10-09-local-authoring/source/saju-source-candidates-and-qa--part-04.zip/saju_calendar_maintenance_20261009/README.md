# SaJu orbital calendar consistency candidate

This standalone package reproduces an inconsistency in the surviving **old source at `843a4a088a9e20760421b4c81f890d026a53ae6b`** and tests a minimal candidate patch. The patch is **not integrated, deployed, or live**. The reported latest revision `2709bb7` is unavailable; its behavior is unknown. The earlier queued `38bca01` was reported to concern midnight/tab-return refresh in `app/daily/page.tsx`; its diff is unavailable and it is not evidence that this separate formula was fixed or still exists in the latest site.

## Result

The old `daily-orbital.ts` estimates today's stem using `(year * 365 + zeroBasedMonth * 30 + day) % 10`. It ignores actual month lengths and leap days. At 2026-01-31 → 2026-02-01 it repeats `을`; the existing app day-pillar convention advances from `을·WOOD` to `병·FIRE`. At the source's 2000-01-01 anchor, the old orbital output is `을·WOOD`, whereas `getDailyPillar` returns `무·EARTH`.

The candidate imports the already-existing `getDailyPillar` from `./manse`, passes the same local `Date` year/month/day used by the old orbital function and `/daily`, and uses its returned `gan` and `element`. The existing owner/friend relationship rules, Korean copy, filtering, ordering and return schema remain untouched. No new interpretive rule, solar-term algorithm, UI refresh mechanism, or performance change is added.

## Reproduce

Requirements: Node **24.19.0** (the verified runtime) and Git for checking the unified patch. No npm packages, network, browser, credentials or app server are needed. Run from this directory:

```sh
node --disable-warning=ExperimentalWarning verify.mjs
```

This verifies the preserved source snapshots, applies the patch only to a disposable copy inside this package, requires three expected red assertions on the old source, and runs the full green suite. It returns exit code 0 only if those expectations hold. The original checkout is not needed for this self-contained mode.

For the additional read-only original-checkout check used for the saved report:

```sh
node --disable-warning=ExperimentalWarning verify.mjs --source-checkout /workspace/scratch/c9f1a9454187/saju_planet_preview --record
```

`--record` writes the reproduced logs and `evidence/verification.json`. It preserves `evidence/initial-red.txt`, which was recorded before the candidate existed. Without `--record`, evidence files are not changed. The disposable patch-test copy is created and removed within this package in either mode. The old checkout is read only.

Individual suites:

```sh
TZ=UTC node --disable-warning=ExperimentalWarning run-tests.mjs --source original --scope regression
TZ=UTC node --disable-warning=ExperimentalWarning run-tests.mjs --source candidate --scope full
```

The first command is intentionally expected to exit 1 with three behavioral assertion failures. The second is expected to exit 0. The warning flag suppresses only Node's ExperimentalWarning for its TypeScript API; errors still fail the runner.

## What is verified

- 17 green test groups, including the three regressions.
- Every **73,414** Gregorian date from 1900-01-01 through 2100-12-31 and all **73,413** adjacent day transitions.
- A separate **UTC day-ordinal oracle**, using `Date.UTC` day differences rather than the source Julian Day formula, checks stem, branch and element. It deliberately uses the source's existing 2000-01-01 = 무오 anchor. This verifies arithmetic and consistency, not the independent astronomical or interpretive correctness of that anchor.
- 24 explicit boundaries, including January/February, 30-day months, year rollover, ordinary/leap February, 1900 and 2100 as non-leap centuries and 2000 as a leap century.
- The original helper rejects 24 invalid date inputs with the original `SajuInputError` type/status; the candidate propagates that validation for three invalid/out-of-range clock cases, with nine assertions covering normal, empty and self-only friend lists.
- 900 baseline/candidate output comparisons across 15 owner variants × 15 friend variants × four dates. These cover all ten stems, missing/null/empty/unknown pillar values, all four classifications, exact unchanged non-date output, return keys, duplicate IDs, ordering, self filtering, empty lists and input immutability. An explicit independent five-element classification matrix also checks the results.
- 27 fixed instants across UTC, Asia/Seoul, America/New_York, Europe/Berlin, Pacific/Kiritimati, Pacific/Honolulu and Australia/Lord_Howe. Each verifies hard-coded local calendar parts/hour/offset, midnight/year boundaries where supplied, and representative 23/25-hour DST days and 30-minute DST changes. Dates are selected locally, without converting the product to UTC or a fixed Korea timezone.
- The unified patch targets one file, passes a Git dry run, and produces bytes identical to the candidate when applied to a disposable original copy.
- All 12 saved source/dependency snapshots are hash checked. With `--source-checkout`, the original clean HEAD and all 151 tracked-file SHA-256 values are checked again.

## Exact harness seams

`provenance.json` was captured before the red test and candidate. It pins full files and the following unmodified source slices; `harness.mjs` additionally pins the provenance file itself by SHA-256.

| Source | Extraction |
| --- | --- |
| `lib/saju/input-error.ts` | Original error class, lines 1 through EOF; recorded upper bound 7, file has 6 newline-terminated lines |
| `lib/saju/input.ts` | Lines 37–60: `integer` and `parseSolarDate` |
| `lib/saju/manse.ts` | Lines 4–30: stem and branch tables |
| `lib/saju/manse.ts` | Lines 114–136: `getJulianDay` and `calculateDayPillar` |
| `lib/saju/manse.ts` | Lines 358–372: `getDailyPillar` |

All calculation and validation source bytes are preserved and hash checked before execution. Node's `stripTypeScriptTypes` erases type syntax. `loadReference` processes each extracted slice separately: the slice named `input_error` uses `mode: "transform"` for the original class's TypeScript constructor parameter property, and every other slice, including Gregorian validators and calculations, uses `mode: "strip"`. Only then are the resulting strings joined for the reference VM. The full orbital source also uses strip mode. Top-level `export` declaration wrappers are removed so the slices can run in a VM function. No calculation body or validation rule is edited by the harness.

The orbital VM executes the **entire original or candidate function body**, not a reimplementation. Its exact import declarations are checked before removing their module-loading wrappers: `GuinPerson` supplies only erased type annotations, `TEN_STEM_SPIRITS` is unused (verified to occur only in its import), and the candidate's `getDailyPillar` binding is supplied by the exact source-slice VM above. A native-Date subclass freezes only zero-argument construction/`Date.now`; constructor arguments, local date methods and DST semantics remain native. The reference validator uses native `Date`/`Date.UTC` unchanged. Every timezone test runs in a separate Node process with an explicit `TZ`.

This avoids unavailable runtime imports for lunar conversion and Three.js. It does **not** test their imports, side effects, bundling, or the complete `manse.ts` module graph. The full original files, package manifest, lockfile, tsconfig and app daily consumer are included for review.

## Behavior and verification limits

The existing `getDailyPillar` supports years **1900–2100** and rejects invalid input. The candidate now inherits those errors for an invalid system clock or a date outside that range; the old approximation silently produced an output. Validation happens before friend filtering, so even empty or self-only friend lists throw under these invalid-clock conditions instead of returning an empty array. Supported valid dates preserve all output except the corrected `elementStatus`. JavaScript normalizes impossible constructed dates before this function sees them, so invalid Gregorian triples are tested directly against the original helper; they cannot be injected as a real `Date` without changing the clock seam.

The checkout's Node engine requirement is `>=22.13.0`, but this standalone harness was verified only on Node 24.19.0. Original `node_modules` is absent. `provenance.json` records exact direct/dev dependency constraints and package scripts; full `package-lock.json` is preserved. Relevant runtime imports would require `korean-lunar-calendar@0.4.0` and `three@0.186.1`; neither was installed or mocked as working.

No app build, application typecheck, lint, repository integration tests, browser/WebGL tests, network calls, package installation, external writes, commit, or deployment was performed. The repository has no `test` script; its README describes `npm run build` followed by `node scripts/integration-preview.mjs`. Those checks require unavailable dependencies and built app artifacts and were outside this bounded standalone task. The VM suite passing is not a claim that application integration or the latest live site passes.

## Files

- `daily-orbital-calendar.patch`: one-file unified patch.
- `candidate/lib/saju/daily-orbital.ts`: ordinary app-compatible TypeScript candidate; no harness hooks.
- `harness.mjs`, `run-tests.mjs`, `verify.mjs`: self-contained test and reproduction tools.
- `source/`: unchanged read-only source/dependency snapshots.
- `provenance.json`, `source-tracked-sha256.json`, `candidate-sha256.json`: source provenance and hashes.
- `evidence/initial-red.txt`: pre-candidate reproduction, intentionally failing.
- `evidence/initial-green.txt`: first complete candidate pass.
- `evidence/reproduced-red.txt`, `evidence/reproduced-green.txt`, `evidence/verification.json`: saved final rerun evidence.

## Later integration handoff

The complete candidate file is a **reference against `843a4a0`**, not a replacement to copy over `2709bb7` or any newer source. After that source is recovered, inspect its current `getDailyPillar`, date-handling convention, dependency graph and orbital function. Reconcile only the small helper import and date-delegation hunk if still applicable. Preserve newer wording, imports, refresh logic and behavior that this old snapshot cannot verify. Then run the current application's relevant typecheck, lint, build, integration and UI checks before making any integration or deployment claim.

The completed [independent standalone review](review/INDEPENDENT_REVIEW.md) found no blocking code or test findings against the recorded source, candidate, harness and test hashes. That result is bounded to this standalone package. This package must still be reconciled with the unavailable latest source before anyone treats it as an integration-ready or deployed fix.
