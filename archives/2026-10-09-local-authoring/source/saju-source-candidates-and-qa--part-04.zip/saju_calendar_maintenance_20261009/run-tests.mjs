import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { loadOrbital, loadReference, read } from './harness.mjs';

const arg = (name, fallback) => {
  const index = process.argv.indexOf(name);
  return index < 0 ? fallback : process.argv[index + 1];
};
const kind = arg('--source', 'candidate');
const scope = arg('--scope', 'full');
assert.ok(['full', 'regression', 'timezone'].includes(scope));
const reference = loadReference();
const orbital = loadOrbital(kind, reference);
const original = loadOrbital('original', reference);
const STEMS = ['갑', '을', '병', '정', '무', '기', '경', '신', '임', '계'];
const BRANCHES = ['자', '축', '인', '묘', '진', '사', '오', '미', '신', '유', '술', '해'];
const ELEMENTS = ['wood', 'wood', 'fire', 'fire', 'earth', 'earth', 'metal', 'metal', 'water', 'water'];
const owner = { id: 'synthetic-owner', name: 'Owner', pillars: { dayKey: '갑자' }, isMe: true };
const friend = { id: 'synthetic-friend', name: 'Friend', pillars: { dayKey: '병인' }, isMe: false };
const DAY_MS = 86400000;
const modulo = (n, divisor) => ((n % divisor) + divisor) % divisor;

// Independent calendar arithmetic: built-in UTC day ordinals, not the source's
// Julian Day function. The cycle anchor is deliberately the existing app's
// 2000-01-01 = 무오 convention, not a new interpretation or external oracle.
function oracle(year, month, day) {
  const days = (Date.UTC(year, month - 1, day) - Date.UTC(2000, 0, 1)) / DAY_MS;
  assert.ok(Number.isInteger(days));
  const index = modulo(4 + days, 10);
  return { gan: STEMS[index], ji: BRANCHES[modulo(6 + days, 12)], element: ELEMENTS[index] };
}
const status = (pillar) => `오늘의 우주 기운 [${pillar.gan}·${pillar.element.toUpperCase()}] 영향권`;
const plain = (value) => JSON.parse(JSON.stringify(value));
const withoutStatus = (value) => plain(value).map(({ elementStatus, ...rest }) => rest);
function localNoon(y, m, d) { return new Date(y, m - 1, d, 12).getTime(); }
function insightAt(instant, engine = orbital) { return engine.at(instant, owner, [friend])[0]; }
function checkDate(y, m, d, instant = localNoon(y, m, d)) {
  const expected = oracle(y, m, d);
  const gotReference = reference.getDailyPillar(y, m, d);
  assert.deepEqual({ gan: gotReference.gan, ji: gotReference.ji, element: gotReference.element }, expected, `reference ${y}-${m}-${d}`);
  assert.equal(insightAt(instant).elementStatus, status(expected), `orbital ${y}-${m}-${d}`);
}

const results = [];
const metrics = {};
function test(name, fn) {
  try { fn(); results.push({ name, passed: true }); console.log(`PASS ${name}`); }
  catch (error) {
    results.push({ name, passed: false, message: error.message, code: error.code });
    console.log(`FAIL ${name}\n${error.stack}`);
  }
}

if (scope !== 'timezone') {
  test('regression: anchor day has the existing helper stem and element', () => {
    assert.equal(insightAt(localNoon(2000, 1, 1)).elementStatus, '오늘의 우주 기운 [무·EARTH] 영향권');
  });
  test('regression: Jan 31 to Feb 1 advances one stem instead of repeating', () => {
    const first = insightAt(localNoon(2026, 1, 31)).elementStatus.match(/\[(.)·/u)[1];
    const next = insightAt(localNoon(2026, 2, 1)).elementStatus.match(/\[(.)·/u)[1];
    assert.equal(modulo(STEMS.indexOf(next) - STEMS.indexOf(first), 10), 1, `actual stems: ${first} -> ${next}`);
  });
  test('regression: Jan 31 and Feb 1 both match independent day ordinals', () => {
    checkDate(2026, 1, 31);
    checkDate(2026, 2, 1);
  });
}

if (scope === 'full') {
  test('reference: unchanged anchor returns all original pillar fields', () => {
    assert.deepEqual(plain(reference.getDailyPillar(2000, 1, 1)), {
      gan: '무', ji: '오', ganHanja: '戊', jiHanja: '午', element: 'earth', elemKo: '토', name: '무오 (戊午)',
    });
  });
  test('calendar: month, year, leap day and leap-century boundaries', () => {
    const dates = [
      [1900, 1, 1], [1900, 2, 28], [1900, 3, 1],
      [1999, 12, 31], [2000, 1, 1], [2000, 2, 28], [2000, 2, 29], [2000, 3, 1],
      [2024, 2, 28], [2024, 2, 29], [2024, 3, 1], [2025, 2, 28], [2025, 3, 1],
      [2026, 1, 31], [2026, 2, 1], [2026, 4, 30], [2026, 5, 1], [2026, 12, 31], [2027, 1, 1],
      [2099, 12, 31], [2100, 1, 1], [2100, 2, 28], [2100, 3, 1], [2100, 12, 31],
    ];
    dates.forEach((parts) => checkDate(...parts));
    metrics.boundaryDates = dates.length;
  });
  test('calendar: every supported Gregorian date agrees with an independent UTC oracle', () => {
    assert.equal(process.env.TZ, 'UTC', 'the exhaustive sweep must run in UTC');
    let count = 0;
    let previous;
    for (let instant = Date.UTC(1900, 0, 1, 12); instant <= Date.UTC(2100, 11, 31, 12); instant += DAY_MS) {
      const date = new Date(instant);
      checkDate(date.getUTCFullYear(), date.getUTCMonth() + 1, date.getUTCDate(), instant);
      const current = reference.getDailyPillar(date.getUTCFullYear(), date.getUTCMonth() + 1, date.getUTCDate());
      if (previous) {
        assert.equal(modulo(STEMS.indexOf(current.gan) - STEMS.indexOf(previous.gan), 10), 1);
        assert.equal(modulo(BRANCHES.indexOf(current.ji) - BRANCHES.indexOf(previous.ji), 12), 1);
      }
      previous = current;
      count++;
    }
    assert.equal(count, 73414);
    metrics.supportedDates = count;
    metrics.adjacentDayTransitions = count - 1;
  });
  test('validation: original helper rejects invalid Gregorian dates and unsupported years', () => {
    const invalid = [
      [1899, 12, 31], [2101, 1, 1], [1900, 2, 29], [2100, 2, 29], [2025, 2, 29],
      [2000, 2, 30], [2026, 4, 31], [2026, 6, 31], [2026, 9, 31], [2026, 11, 31],
      [2026, 0, 1], [2026, 13, 1], [2026, 1, 0], [2026, 1, 32],
      [2026.5, 1, 1], [2026, 1.5, 1], [2026, 1, 1.5],
      [NaN, 1, 1], [2026, Infinity, 1], [2026, 1, NaN],
      [null, 1, 1], [2026, true, 1], [2026, 1, undefined], ['2026x', 1, 1],
    ];
    for (const date of invalid) {
      assert.throws(() => reference.getDailyPillar(...date), (error) => error instanceof reference.SajuInputError && error.status === 400);
    }
    metrics.invalidDateInputs = invalid.length;
  });
  test('validation: candidate propagates the existing helper error for out-of-range or invalid clocks', () => {
    for (const instant of [localNoon(1899, 12, 31), localNoon(2101, 1, 1), NaN]) {
      assert.throws(() => insightAt(instant), (error) => error instanceof reference.SajuInputError && error.status === 400);
      assert.throws(() => orbital.at(instant, owner, []), (error) => error instanceof reference.SajuInputError && error.status === 400);
      assert.throws(() => orbital.at(instant, owner, [{ ...friend, isMe: true }]), (error) => error instanceof reference.SajuInputError && error.status === 400);
    }
    // This is a documented change from the old approximation's silent output.
    metrics.rejectedClockCases = 3;
    metrics.rejectedClockAssertions = 9;
  });
  test('preservation: classifications, text, defaults, filtering, ordering, schema and input immutability', () => {
    const expected = {
      wood:  ['gentle_breeze', 'golden_rendezvous', 'gentle_breeze', 'caution_belt', 'super_charged'],
      fire:  ['super_charged', 'gentle_breeze', 'golden_rendezvous', 'gentle_breeze', 'caution_belt'],
      earth: ['gentle_breeze', 'super_charged', 'gentle_breeze', 'golden_rendezvous', 'gentle_breeze'],
      metal: ['caution_belt', 'gentle_breeze', 'super_charged', 'gentle_breeze', 'golden_rendezvous'],
      water: ['golden_rendezvous', 'caution_belt', 'gentle_breeze', 'super_charged', 'gentle_breeze'],
    };
    const elementOrder = ['wood', 'fire', 'earth', 'metal', 'water'];
    const variants = [...STEMS.map((stem) => ({ dayKey: `${stem}자` })), undefined, null, {}, { dayKey: '' }, { dayKey: '?' }];
    const ownerElement = (pillars) => ELEMENTS[STEMS.indexOf(pillars?.dayKey?.charAt(0) || '갑')] || 'wood';
    const friendElement = (pillars) => ELEMENTS[STEMS.indexOf(pillars?.dayKey?.charAt(0) || '을')] || 'fire';
    const freeze = (value) => {
      if (value && typeof value === 'object') { Object.values(value).forEach(freeze); Object.freeze(value); }
      return value;
    };
    const dates = [[2000, 1, 1], [2026, 1, 31], [2026, 2, 1], [2100, 12, 31]];
    let comparisons = 0;
    const seen = new Set();
    for (const [ownerIndex, pillars] of variants.entries()) {
      const person = freeze({ ...owner, pillars });
      const friends = freeze(variants.map((friendPillars, index) => ({
        id: index < 2 ? 'duplicate-id' : `synthetic-${index}`,
        name: index === 0 ? '' : `Friend ${index}`, pillars: friendPillars,
        // Missing isMe remains included, while true is excluded below.
        ...(index % 2 ? { isMe: false } : {}),
      })).concat([{ ...friend, id: 'excluded-self', isMe: true }]));
      const before = JSON.stringify({ person, friends });
      for (const parts of dates) {
        const instant = localNoon(...parts);
        const got = orbital.at(instant, person, friends);
        const baseline = original.at(instant, person, friends);
        assert.equal(got.length, variants.length);
        assert.deepEqual(withoutStatus(got), withoutStatus(baseline), `owner variant ${ownerIndex}`);
        for (let index = 0; index < got.length; index++) {
          assert.deepEqual(Object.keys(got[index]).sort(), Object.keys(baseline[index]).sort());
          const classification = expected[ownerElement(pillars)][elementOrder.indexOf(friendElement(variants[index]))];
          assert.equal(got[index].weatherType, classification);
          assert.equal(got[index].elementStatus, status(oracle(...parts)));
          seen.add(classification);
          comparisons++;
        }
      }
      assert.equal(JSON.stringify({ person, friends }), before);
      assert.deepEqual(plain(orbital.at(localNoon(2026, 1, 1), person, [])), []);
      assert.deepEqual(plain(orbital.at(localNoon(2026, 1, 1), person, [{ ...friend, isMe: true }])), []);
    }
    assert.equal(seen.size, 4);
    metrics.preservationComparisons = comparisons;
    metrics.ownerAndFriendVariantsEach = variants.length;
  });
  test('patch scope: all content after ownerStem remains byte-for-byte identical', () => {
    const marker = '  const ownerStem =';
    const before = read('source/lib/saju/daily-orbital.ts');
    const after = read('candidate/lib/saju/daily-orbital.ts');
    assert.equal(after.slice(after.indexOf(marker)), before.slice(before.indexOf(marker)));
  });
}

// Hard-coded local dates/hours and offsets confirm what each instant means in
// each zone. The orbital VM gets the same native local Date getters as the app.
const zoneCases = {
  UTC: [
    ['2026-01-31T23:59:59.999Z', 2026, 1, 31, 23, 0], ['2026-02-01T00:00:00Z', 2026, 2, 1, 0, 0],
    ['2026-12-31T23:59:59.999Z', 2026, 12, 31, 23, 0], ['2027-01-01T00:00:00Z', 2027, 1, 1, 0, 0],
  ],
  'Asia/Seoul': [
    ['2026-01-31T14:59:59.999Z', 2026, 1, 31, 23, -540], ['2026-01-31T15:00:00Z', 2026, 2, 1, 0, -540],
  ],
  'America/New_York': [
    ['2026-03-08T04:59:59.999Z', 2026, 3, 7, 23, 300], ['2026-03-08T05:00:00Z', 2026, 3, 8, 0, 300],
    ['2026-03-08T06:59:59.999Z', 2026, 3, 8, 1, 300], ['2026-03-08T07:00:00Z', 2026, 3, 8, 3, 240],
    ['2026-03-09T04:00:00Z', 2026, 3, 9, 0, 240],
    ['2026-11-01T04:00:00Z', 2026, 11, 1, 0, 240],
    ['2026-11-01T05:59:59.999Z', 2026, 11, 1, 1, 240], ['2026-11-01T06:00:00Z', 2026, 11, 1, 1, 300],
    ['2026-11-02T05:00:00Z', 2026, 11, 2, 0, 300],
  ],
  'Europe/Berlin': [
    ['2026-03-29T00:59:59.999Z', 2026, 3, 29, 1, -60], ['2026-03-29T01:00:00Z', 2026, 3, 29, 3, -120],
    ['2026-10-25T00:59:59.999Z', 2026, 10, 25, 2, -120], ['2026-10-25T01:00:00Z', 2026, 10, 25, 2, -60],
  ],
  'Pacific/Kiritimati': [
    ['2026-12-31T09:59:59.999Z', 2026, 12, 31, 23, -840], ['2026-12-31T10:00:00Z', 2027, 1, 1, 0, -840],
  ],
  'Pacific/Honolulu': [
    ['2026-02-01T09:59:59.999Z', 2026, 1, 31, 23, 600], ['2026-02-01T10:00:00Z', 2026, 2, 1, 0, 600],
  ],
  'Australia/Lord_Howe': [
    ['2026-04-04T14:59:59.999Z', 2026, 4, 5, 1, -660], ['2026-04-04T15:00:00Z', 2026, 4, 5, 1, -630],
    ['2026-10-03T15:29:59.999Z', 2026, 10, 4, 1, -630], ['2026-10-03T15:30:00Z', 2026, 10, 4, 2, -660],
  ],
};

if (scope === 'timezone') {
  test(`timezone: local date consistency in ${process.env.TZ}`, () => {
    const cases = zoneCases[process.env.TZ];
    assert.ok(cases, 'known zone');
    for (const [instant, y, m, d, hour, offset] of cases) {
      const date = new Date(instant);
      assert.deepEqual([date.getFullYear(), date.getMonth() + 1, date.getDate(), date.getHours(), date.getTimezoneOffset()], [y, m, d, hour, offset]);
      checkDate(y, m, d, instant);
      assert.deepEqual(withoutStatus(orbital.at(instant, owner, [friend])), withoutStatus(original.at(instant, owner, [friend])));
    }
    if (process.env.TZ === 'America/New_York') {
      assert.equal((Date.parse('2026-03-09T04:00:00Z') - Date.parse('2026-03-08T05:00:00Z')) / 3600000, 23);
      assert.equal((Date.parse('2026-11-02T05:00:00Z') - Date.parse('2026-11-01T04:00:00Z')) / 3600000, 25);
    }
    metrics.timezoneInstants = cases.length;
  });
}

if (scope === 'full') {
  for (const zone of Object.keys(zoneCases)) {
    test(`timezone subprocess: ${zone}`, () => {
      const result = spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', fileURLToPath(import.meta.url), '--source', kind, '--scope', 'timezone'], {
        env: { ...process.env, TZ: zone }, encoding: 'utf8', timeout: 15000,
      });
      assert.ifError(result.error);
      assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
      const summary = JSON.parse(result.stdout.split('\n').find((line) => line.startsWith('SUMMARY ')).slice(8));
      metrics.timezoneInstants = (metrics.timezoneInstants ?? 0) + summary.metrics.timezoneInstants;
    });
  }
  metrics.timezones = Object.keys(zoneCases).length;
}

const failed = results.filter((item) => !item.passed);
console.log(`SUMMARY ${JSON.stringify({ source: kind, scope, timezone: process.env.TZ, tests: results.length, passed: results.length - failed.length, failed: failed.length, metrics, results })}`);
process.exitCode = failed.length ? 1 : 0;
