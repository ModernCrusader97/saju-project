import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { ROOT, digest, provenance, read, verifySnapshots } from './harness.mjs';

const checkIndex = process.argv.indexOf('--source-checkout');
const sourceCheckout = checkIndex < 0 ? undefined : resolve(process.argv[checkIndex + 1]);
const record = process.argv.includes('--record');
const verification = {
  verifiedAt: new Date().toISOString(), node: process.version,
  sourceHead: provenance.sourceHead, latestReportedRevision: '2709bb7', latestRevisionStatus: 'unavailable',
  integrated: false, live: false,
};

function run(command, args, cwd = ROOT, extra = {}) {
  const result = spawnSync(command, args, {
    cwd, env: { ...process.env, GIT_OPTIONAL_LOCKS: '0', TZ: 'UTC' }, encoding: 'utf8', timeout: 60000, ...extra,
  });
  assert.ifError(result.error);
  return result;
}

verifySnapshots();
verification.snapshotFilesVerified = Object.keys(provenance.sourceSnapshotSha256).length;
console.log(`PASS ${verification.snapshotFilesVerified} hash-pinned source snapshots`);

if (sourceCheckout) {
  const trackedManifest = read('source-tracked-sha256.json');
  assert.equal(digest(trackedManifest), 'e7b6d2168aa5d775c2f7ce67164984c4673a274c2431458479aec656a83b10b9');
  const files = JSON.parse(trackedManifest);
  const head = run('git', ['rev-parse', 'HEAD'], sourceCheckout);
  assert.equal(head.status, 0, head.stderr);
  assert.equal(head.stdout.trim(), provenance.sourceHead);
  const status = run('git', ['--no-optional-locks', 'status', '--porcelain=v1'], sourceCheckout);
  assert.equal(status.status, 0, status.stderr);
  assert.equal(status.stdout, '', 'old source checkout must remain clean');
  const tracked = run('git', ['ls-files', '-z'], sourceCheckout);
  assert.equal(tracked.status, 0, tracked.stderr);
  assert.deepEqual(tracked.stdout.split('\0').filter(Boolean).sort(), Object.keys(files).sort());
  for (const [path, expected] of Object.entries(files)) {
    assert.equal(digest(readFileSync(join(sourceCheckout, path))), expected, `unchanged old source ${path}`);
  }
  verification.oldCheckout = { checked: true, clean: true, unchangedTrackedFiles: Object.keys(files).length, head: head.stdout.trim() };
  console.log(`PASS old checkout clean; ${Object.keys(files).length} tracked files unchanged`);
} else {
  verification.oldCheckout = { checked: false, reason: 'No --source-checkout supplied; preserved snapshots were checked.' };
  console.log('NOTE original checkout not requested; snapshot checks are self-contained');
}

const patch = read('daily-orbital-calendar.patch');
assert.deepEqual(patch.split('\n').filter((line) => line.startsWith('--- ') || line.startsWith('+++ ')), [
  '--- a/lib/saju/daily-orbital.ts', '+++ b/lib/saju/daily-orbital.ts',
], 'patch targets only the approved orbital file');
assert.ok(!patch.includes('GIT binary patch'));
const temp = mkdtempSync(join(ROOT, '.patch-check-'));
try {
  mkdirSync(join(temp, 'lib/saju'), { recursive: true });
  writeFileSync(join(temp, 'lib/saju/daily-orbital.ts'), read('source/lib/saju/daily-orbital.ts'));
  const check = run('git', ['apply', '--no-index', '--check', join(ROOT, 'daily-orbital-calendar.patch')], temp);
  assert.equal(check.status, 0, check.stderr);
  const apply = run('git', ['apply', '--no-index', join(ROOT, 'daily-orbital-calendar.patch')], temp);
  assert.equal(apply.status, 0, apply.stderr);
  assert.equal(readFileSync(join(temp, 'lib/saju/daily-orbital.ts'), 'utf8'), read('candidate/lib/saju/daily-orbital.ts'));
  assert.deepEqual(readdirSync(temp, { recursive: true }).sort(), ['lib', 'lib/saju', 'lib/saju/daily-orbital.ts']);
  verification.patch = { dryRun: 'passed', appliedToDisposableCopy: 'passed', matchesCandidateBytes: true, targetFiles: 1, sha256: digest(patch) };
  console.log('PASS unified patch dry-run and exact application to a disposable copy');
} finally {
  rmSync(temp, { recursive: true });
}

function suite(kind, scope) {
  const result = run(process.execPath, ['--disable-warning=ExperimentalWarning', 'run-tests.mjs', '--source', kind, '--scope', scope]);
  const summaryLine = result.stdout.split('\n').find((line) => line.startsWith('SUMMARY '));
  assert.ok(summaryLine, `${kind} suite did not complete:\n${result.stdout}\n${result.stderr}`);
  assert.equal(result.stderr, '', 'unexpected diagnostic output');
  return { ...result, summary: JSON.parse(summaryLine.slice(8)) };
}
const red = suite('original', 'regression');
assert.equal(red.status, 1, 'the original regression must fail');
assert.equal(red.summary.tests, 3);
assert.equal(red.summary.failed, 3);
assert.ok(red.summary.results.every((result) => result.code === 'ERR_ASSERTION'), 'red failures must be behavioral assertions, not harness errors');
verification.red = { exitCode: red.status, ...red.summary };
console.log('PASS red verification: all 3 expected behavioral assertions fail on the original source');

const green = suite('candidate', 'full');
assert.equal(green.status, 0, `${green.stdout}\n${green.stderr}`);
assert.equal(green.summary.failed, 0);
assert.equal(green.summary.tests, 17);
verification.green = { exitCode: green.status, ...green.summary };
console.log(green.stdout.split('\n').filter((line) => line.startsWith('PASS ')).join('\n'));

if (record) {
  writeFileSync(join(ROOT, 'evidence/reproduced-red.txt'), red.stdout);
  writeFileSync(join(ROOT, 'evidence/reproduced-green.txt'), green.stdout);
  writeFileSync(join(ROOT, 'evidence/verification.json'), `${JSON.stringify(verification, null, 2)}\n`);
}
console.log(`VERIFIED ${JSON.stringify({ redFailures: verification.red.failed, greenGroups: verification.green.passed, ...verification.green.metrics, patch: verification.patch, oldCheckout: verification.oldCheckout })}`);
