# Independent review: standalone orbital calendar candidate

Verdict: no blocking code or test findings within this standalone review against surviving source revision `843a4a088a9e20760421b4c81f890d026a53ae6b`. This verdict does not approve integration into the unavailable latest source, an application build, or deployment.

## Exact reviewed implementation

| Artifact | SHA-256 |
| --- | --- |
| Original orbital source | `6756859b26da60494203f5903532ed8b7ffe76ef2d9ae69ab4d1c2b629fec79b` |
| Candidate orbital source | `890d71b2e588911201a6db9ed78b61f9704260f51b14dccccc21b43f8900c21b` |
| Unified patch | `02ea4336e6b2054c32bcbf0bbb2399113064335bc14e310e00f19b9d0f634a2d` |
| Harness | `734506abd503c088ec0cd34e8c4d89f98e1690be9e1cb963a1e6c4a76df64067` |
| Final test suite | `32d7f76dd606df70d9123b9b10e08ec0ac19ba2a3b4797ccc46268c97e1e12d3` |
| Verification runner | `249fbdeb1774e9f695668ac933698412517eeb5699e279ed5e5c8c9fd74d710f` |
| Source provenance | `4d634dfd633e60cf79802e5c8929e518e7d4973c10b3b20a455ab5ba5bd9312e` |

Review used Node v24.19.0. No implementation or test file was edited by the reviewer. All reviewer writes are under `review/`.

## Findings and evidence

1. **Source fidelity:** all 12 captured files independently matched both the old working-tree bytes and the Git objects at the stated full revision. All 151 tracked-file hashes matched at review start and review end; Git status stayed clean. Reference slices cover every executable dependency used by the Gregorian helper: the original error class, integer/date validation, stem/branch tables, Julian Day calculation, cycle calculation, and `getDailyPillar`. Full-file and slice SHA checks precede execution.

2. **Execution seams:** the frozen harness processes source slices separately: only the original error class uses Node TypeScript transform mode for its constructor parameter property; the validator, tables, and calendar calculation slices use strip mode. The orbital source also uses strip mode. The harness removes only checked module imports and export declaration wrappers; it does not rewrite the calculation bodies. A VM binding supplies the exact extracted helper. Native Date methods are retained while the clock is frozen. This establishes source-body behavior, not normal ESM dependency loading or bundling.

3. **Calendar arithmetic:** the candidate invokes the existing helper once with the native local year, one-based month, and day, and forwards its stem/element without recalculation. The independent oracle uses UTC day ordinals rather than the helper's Julian Day formula, retaining the application's existing 2000-01-01 = 무오 anchor. Every date in 1900–2100 passed. This checks arithmetic consistency with that anchor, not independent astrological or astronomical validity.

4. **Regression discrimination:** the independently rerun original suite exited 1 with all three expected behavioral failures: the 2000 anchor mismatch, repeated stem at Jan 31 → Feb 1, and mismatch against the ordinal expectation. These are assertion failures, not extraction/loading failures. The final candidate suite exited 0 with all 17 groups passing.

5. **Coverage:** the final run checked 73,414 supported dates; 73,413 adjacent transitions; 24 explicit month/year/leap-century boundaries; 24 rejected malformed or unsupported helper inputs; nine clock-error assertions; and 900 relationship-output comparisons over 15 owner/friend variants. Seven separate TZ processes checked 27 instants, local midnight/year edges, spring/fall DST, 23/25-hour days, and Lord Howe's half-hour changes. Cross-zone consistency preserves local-date selection rather than imposing a UTC or fixed Korea policy.

6. **Output preservation:** bytes from `ownerStem` through the function end remain unchanged. The comparison suite and an independent classification matrix cover all four classifications, Korean messages, return keys, defaults, ordering, duplicate identifiers, self filtering, empty lists, and input immutability. Supported valid clocks change only `elementStatus`.

7. **Boundary caveat:** `getDailyPillar` rejects invalid clocks and years outside 1900–2100. The candidate now propagates `SajuInputError` with status 400 before filtering friends. Empty and self-only friend lists therefore also throw under these conditions, whereas the original could return an empty array. This behavior is documented and exercised, including separate reviewer checks. Impossible Gregorian triples are checked at the helper boundary because native Date normally normalizes them before orbital code receives date parts.

8. **Patch scope:** the one-file patch passed a zero-fuzz dry run and application under `review/patch-target`, producing exactly the candidate SHA. The final verification runner was also independently executed from an identical package copy under `review/runner-copy`, so its temporary patch work remained within the permitted review directory. It passed its own exact-application checks and the read-only old-checkout check. Reviewer-created disposable copies were then removed; logs and content hashes remain. The patch was never applied to the old checkout or latest source.

## Documentation review

The README accurately describes the frozen harness modes and source extraction. An initial reviewer concern used a pre-freeze harness read and was withdrawn after rereading hash `734506abd503c088ec0cd34e8c4d89f98e1690be9e1cb963a1e6c4a76df64067`. All saved final execution evidence used this frozen harness. Final documentation hashes and completed-review wording are verified separately in `final-document-check.json` after package refreeze.

## Verification limits

Latest reported revision `2709bb7` was unavailable and was not inspected. No conclusion is made about whether this defect exists there. The older `38bca01` diff was also unavailable; its reported date-refresh work does not establish this formula's state.

No application build, application typecheck or lint, full-module/runtime dependency loading, repository integration suite, native-browser/UI/WebGL validation, install, network retrieval, credential use, Git initialization or commit, external upload, integration, or deployment was performed by this review. The old checkout and source snapshots remained unchanged. The complete candidate file must not overwrite newer source: reconcile the small change against recovered current code and verify current app behavior first.

## Saved review evidence

- `final-review-run-evidence.json` and `final-original-regression.log` / `final-candidate-full.log`: final-hash direct suite rerun.
- `final-verify-runner.json` and `.log`: independent full runner execution from the review-only copy.
- `patch-verification.json`: zero-fuzz patch evidence.
- `additional-semantics.json`: helper delegation and invalid-clock empty-list characterization.
- `old-checkout-review-start.json` / `old-checkout-review-end.json`: unchanged old source evidence.
- `final-document-check.json`: final documentation and frozen artifact verification, completed after refreeze.
