# Calendar consistency candidate: verified standalone

The surviving old source at **843a4a0** reproduces the orbital date defect. Its 30-day-month approximation repeats `을·WOOD` across 2026-01-31 → 2026-02-01; the app's existing helper advances to `병·FIRE`. The one-file patch delegates to that unchanged helper with local year/month/day.

Final verification on Node 24.19.0:

- Original source: **3 expected regression assertions fail**.
- Candidate: **17 test groups pass**; all **73,414 supported dates** agree with an independent UTC day-ordinal oracle using the app's existing anchor.
- Coverage includes 24 boundaries, leap-century behavior, 24 invalid date inputs, 900 output-preservation comparisons, and 27 instants across seven timezones with DST transitions.
- Nine assertions verify invalid-clock/range errors, including empty/self-only friend lists. This inherited helper validation occurs before filtering and is a documented change from the old approximation.
- The one-file patch dry-runs and applies exactly to a disposable copy. The old checkout remains clean and all **151 tracked-file hashes are unchanged**.

Run `node --disable-warning=ExperimentalWarning verify.mjs` from this package to reproduce. See `README.md` for extraction seams and `evidence/verification.json` for the saved results.

**Not integrated or live.** Latest reported source **2709bb7 is unavailable**, so its current defect status is unknown. The older queued 38bca01 concerned date refresh and does not establish the state of this formula. No build, app typecheck/lint, application integration/browser test, network, package install, external write, commit or deployment occurred.

The complete candidate is a reference against 843a4a0, not a file to overwrite newer source with. Recover and inspect the latest helper/orbital code, reconcile only the small date-delegation change while preserving newer behavior, then run current app checks. The completed [independent standalone review](review/INDEPENDENT_REVIEW.md) found no blocking code or test findings against the recorded exact hashes; it does not establish app integration or live-site readiness.
