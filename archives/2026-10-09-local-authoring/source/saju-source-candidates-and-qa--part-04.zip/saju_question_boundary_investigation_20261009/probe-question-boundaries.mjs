// Characterization only. No application patch, external provider, or actual D1.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { stripTypeScriptTypes } from 'node:module';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';

const artifactRoot = path.dirname(fileURLToPath(import.meta.url));
const manifest = JSON.parse(readFileSync(path.join(artifactRoot, 'source-manifest.json'), 'utf8'));
const sourceRoot = path.join(artifactRoot, 'source-snapshots');
const sha256 = value => createHash('sha256').update(value).digest('hex');
const source = file => {
  const value = readFileSync(path.join(sourceRoot, file), 'utf8');
  assert.equal(sha256(value), manifest.snapshots.find(item => item.path === file)?.sha256, file);
  return value;
};
for (const entry of manifest.snapshots) source(entry.path);
const helperSource = readFileSync(manifest.reviewedHelper.path, 'utf8');
assert.equal(sha256(helperSource), manifest.reviewedHelper.sha256);
const helper = (await import(`data:text/javascript;base64,${Buffer.from(stripTypeScriptTypes(helperSource, { mode: 'strip' })).toString('base64')}`)).truncateUtf16WithoutSplittingPair;

const birth = { name: '테스트', birthYear: 2000, birthMonth: 2, birthDay: 29, calendarType: 'solar', isUnknownTime: true };
const pillar = { gan: '갑', ji: '자', ganHanja: '甲', jiHanja: '子', ganElement: 'wood', jiElement: 'water', ganElementName: '목', jiElementName: '수', shipshinGan: '비견', shipshinJi: '정인' };
const makeAnalysis = input => ({ ...input, yearPillar: pillar, monthPillar: pillar, dayPillar: pillar, elementsCount: { wood: 3, fire: 1, earth: 1, metal: 1, water: 0 }, dominantElement: '목', lackingElement: '수', dayMaster: '甲木', dayMasterMetaphor: 'fixture', patternName: 'fixture', yongshin: 'fixture', daewunNumber: 1, daewunList: [] });
const fortuneFixture = { id: 'ft_fixture', createdAt: '2026-10-09T00:00:00.000Z', analysis: makeAnalysis(birth), category: 'consult', generation: { mode: 'template', reason: 'not_configured' }, summary: 'fixture', sections: [] };
const observations = [];
const results = [];
const blocked = { network: 0, lunar: 0, unexpectedImports: 0 };

// Execute the complete route, parser, AI, and storage source bodies after Node's
// built-in TypeScript erasure. Only dependency imports link to explicit modules.
async function setup({ missingFortune = false } = {}) {
  const calls = { analyze: [], generate: [], ask: [], saveFortune: [], getFortune: [], addChatMessage: [], sql: [], logs: [] };
  const context = vm.createContext({
    Request, Response, SyntaxError, Error, TypeError, AbortController,
    crypto: { randomUUID: () => '00000000-0000-4000-8000-000000000001' },
    console: { error: (...args) => calls.logs.push(args), warn: (...args) => calls.logs.push(args) },
    fetch: () => { blocked.network++; throw new Error('NETWORK_FORBIDDEN'); },
    setTimeout: () => { throw new Error('PROVIDER_TIMER_FORBIDDEN'); },
    clearTimeout: () => {},
  });
  const modules = new Map();
  const synthetic = (id, exports) => {
    const module = new vm.SyntheticModule(Object.keys(exports), function () {
      for (const [key, value] of Object.entries(exports)) this.setExport(key, value);
    }, { context, identifier: id });
    modules.set(id, module);
    return module;
  };
  const production = (id, file, appended = '') => {
    const module = new vm.SourceTextModule(stripTypeScriptTypes(source(file), { mode: 'transform' }) + appended, { context, identifier: id });
    modules.set(id, module);
    return module;
  };
  const resolve = async (specifier, referring) => {
    const relative = {
      './input-error': 'input-error', './lunar-calendar': 'lunar-mock',
      '@/lib/saju/input': 'input', '@/lib/saju/manse': 'analysis-mock',
      '@/lib/db/store': 'storage-tap', '@/lib/ai/doryeong-ai': 'ai-tap',
      '@/app/chatgpt-auth': 'auth-mock',
    };
    const resolved = modules.get(relative[specifier] || specifier);
    if (!resolved) { blocked.unexpectedImports++; throw Error(`UNEXPECTED_IMPORT ${referring.identifier}: ${specifier}`); }
    return resolved;
  };
  const evaluate = async module => {
    if (module.status === 'unlinked') await module.link(resolve);
    if (module.status !== 'evaluated') await module.evaluate();
    return module.namespace;
  };
  synthetic('next/server', { NextRequest: Request, NextResponse: { json: (body, init) => Response.json(body, init) } });
  synthetic('lunar-mock', { koreanLunarToSolar: () => { blocked.lunar++; throw Error('LUNAR_OUT_OF_SCOPE'); } });
  synthetic('analysis-mock', { analyzeSaju: input => { calls.analyze.push(input); return makeAnalysis(input); } });
  synthetic('auth-mock', { getChatGPTUser: async () => ({ userId: 'synthetic-owner' }) });
  // This is a fake prepared-statement API, not a D1 connection. Record the exact
  // arguments the unchanged historical store would bind, without database IO.
  synthetic('cloudflare:workers', { env: { DB: { prepare(sql) {
    const call = { sql, bound: [], operation: null };
    calls.sql.push(call);
    return {
      bind(...bound) { call.bound = bound; return this; },
      async run() { call.operation = 'run'; return { meta: { changes: 1 } }; },
      async first() { call.operation = 'first'; return missingFortune ? null : { data: JSON.stringify(fortuneFixture) }; },
      async all() { call.operation = 'all'; return { results: [] }; },
    };
  } } } });
  production('input-error', 'lib/saju/input-error.ts');
  const parserModule = production('input', 'lib/saju/input.ts');
  const storageModule = production('storage-original', 'lib/db/store.ts');
  // One export-only instrumentation line exposes the existing private cleaner.
  // No cleaner/route/template body, constant, or import is rewritten.
  const aiModule = production('ai-original', 'lib/ai/doryeong-ai.ts', '\nexport { cleanQuestion as __probeCleanQuestion };\n');
  const ai = await evaluate(aiModule);
  const storage = await evaluate(storageModule);
  synthetic('ai-tap', {
    generateFortune: async (...args) => { calls.generate.push(args); return ai.generateFortune(...args); },
    askDoryeong: async (...args) => { calls.ask.push(args); return ai.askDoryeong(...args); },
  });
  synthetic('storage-tap', {
    DataStoreError: storage.DataStoreError,
    db: {
      async saveFortune(value) { calls.saveFortune.push(value); return storage.db.saveFortune(value); },
      async getFortune(id) { calls.getFortune.push(id); return storage.db.getFortune(id); },
      async addChatMessage(...args) { calls.addChatMessage.push(args); return storage.db.addChatMessage(...args); },
      listFortunes: (...args) => storage.db.listFortunes(...args),
    },
  });
  const saju = await evaluate(production('saju-route', 'app/api/saju/route.ts'));
  const chat = await evaluate(production('chat-route', 'app/api/saju/[id]/chat/route.ts'));
  const parser = await evaluate(parserModule);
  return { calls, ai, parser, saju, chat };
}

const request = value => new Request('https://offline.invalid/api/saju', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(value) });
const rawRequest = body => new Request('https://offline.invalid/api/saju', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body });
async function post(route, state, value, raw = false) {
  const req = raw ? rawRequest(value) : request(value);
  const response = route === 'saju' ? await state.saju.POST(req) : await state.chat.POST(req, { params: Promise.resolve({ id: 'ft_fixture' }) });
  return { status: response.status, wireJson: await response.text() };
}
const profile = value => value === undefined ? { kind: 'undefined' } : {
  units: value.length, wellFormed: value.isWellFormed(),
  tailCodeUnits: Array.from({ length: Math.min(4, value.length) }, (_, index) => value.charCodeAt(value.length - Math.min(4, value.length) + index).toString(16)),
  lastTwelveJson: JSON.stringify(value.slice(-12)),
};
async function check(name, fn) {
  try { await fn(); results.push({ name, passed: true }); }
  catch (error) { results.push({ name, passed: false, error: error.stack || String(error) }); }
}
const validCases = [
  ['499-BMP-plus-astral', '가'.repeat(499) + '🙂'],
  ['499-BMP-plus-astral-trimmed', ' \t' + '가'.repeat(499) + '🙂' + '\u3000\n'],
  ['498-BMP-plus-astral-fits', '가'.repeat(498) + '🙂'],
  ['500-BMP-plus-astral', '가'.repeat(500) + '🙂'],
  ['501-BMP', '가'.repeat(501)],
  ['251-astral', '🙂'.repeat(251)],
  ['short-trimming', '\t 질문 🙂 \u3000'],
];
for (const [id, question] of validCases) {
  for (const route of ['saju', 'chat']) {
    await check(`historical actual ${route} route: ${id}`, async () => {
      assert.ok(question.isWellFormed());
      const state = await setup();
      const body = route === 'saju' ? { ...birth, category: 'consult', customQuestion: question } : { question };
      const parsedInput = await request(body).json();
      assert.equal(route === 'saju' ? parsedInput.customQuestion : parsedInput.question, question);
      const result = await post(route, state, body);
      assert.equal(result.status, 200);
      const expected = question.trim().slice(0, 500);
      const aiQuestion = route === 'saju' ? state.calls.generate[0][2] : state.calls.ask[0][1];
      assert.equal(aiQuestion, expected);
      assert.equal(state.ai.__probeCleanQuestion(aiQuestion), expected);
      const returned = JSON.parse(result.wireJson);
      let storageQuestion;
      let storageSerialization;
      if (route === 'saju') {
        assert.equal(state.calls.analyze.length, 1);
        assert.equal(state.calls.analyze[0].birthDay, 29);
        assert.equal(state.calls.analyze[0].solarBirthDate.day, 29);
        assert.equal(returned.fortune.generation.mode, 'template');
        const text = state.calls.saveFortune[0].sections[2].content;
        assert.ok(text.startsWith(`남겨주신 질문: “${expected}”\n`));
        storageQuestion = text.slice('남겨주신 질문: “'.length, '남겨주신 질문: “'.length + expected.length);
        const boundJson = state.calls.sql.find(call => call.operation === 'run').bound[3];
        assert.equal(JSON.parse(boundJson).sections[2].content, text);
        assert.equal(returned.fortune.sections[2].content, text);
        storageSerialization = { binding: 'JSON.stringify(fortune)', jsonEscapesLoneHigh: boundJson.includes('\\ud83d'), jsonRoundTripPreserves: true };
      } else {
        const userCall = state.calls.addChatMessage.find(args => args[1] === 'user');
        storageQuestion = userCall[2];
        assert.equal(storageQuestion, expected);
        const boundUser = state.calls.sql.find(call => call.operation === 'run' && call.bound[2] === 'user').bound[3];
        assert.equal(boundUser, expected);
        assert.ok(returned.reply.includes(`“${expected}”`));
        const replyCall = state.calls.addChatMessage.find(args => args[1] === 'doryeong');
        assert.equal(replyCall[2], returned.reply);
        storageSerialization = { binding: 'direct string parameter before D1 transport', actualD1OutcomeTested: false };
      }
      assert.equal(storageQuestion, expected);
      assert.equal(blocked.network, 0);
      const reviewedHelperOutput = helper(question.trim(), 500);
      assert.ok(reviewedHelperOutput.isWellFormed());
      assert.ok(reviewedHelperOutput.length <= 500);
      observations.push({ route, id, input: profile(question), afterRouteAtAI: profile(aiQuestion), atStorage: profile(storageQuestion), responseJsonEscapesLoneHigh: result.wireJson.includes('\\ud83d'), storageSerialization, existingHelperOnOriginal: profile(reviewedHelperOutput), existingHelperAfterOldCut: profile(helper(aiQuestion, 500)) });
      if (id.startsWith('499-BMP')) {
        assert.equal(aiQuestion.isWellFormed(), false);
        assert.equal(aiQuestion.charCodeAt(499), 0xd83d);
        assert.equal(reviewedHelperOutput, '가'.repeat(499));
        assert.equal(helper(aiQuestion, 500), aiQuestion, 'Cannot recover an already-discarded low surrogate');
      } else assert.equal(aiQuestion.isWellFormed(), true);
    });
  }
}

for (const route of ['saju', 'chat']) {
  for (const [id, value, raw] of [['invalid-json', '{', true], ['null-body', null], ['array-body', []], ['string-body', 'question'], ['number-body', 42]]) {
    await check(`${route}: body guard ${id}`, async () => {
      const state = await setup();
      assert.equal((await post(route, state, value, raw)).status, 400);
      assert.equal(state.calls.generate.length + state.calls.ask.length + state.calls.sql.length, 0);
    });
  }
}
for (const question of [null, 42, false, [], {}, true]) {
  for (const route of ['saju', 'chat']) {
    await check(`${route}: question type guard ${JSON.stringify(question)}`, async () => {
      const state = await setup();
      const body = route === 'saju' ? { ...birth, customQuestion: question } : { question };
      assert.equal((await post(route, state, body)).status, 400);
      assert.equal(state.calls.generate.length + state.calls.ask.length + state.calls.sql.length, 0);
    });
  }
}
for (const question of [undefined, '', ' \t\u3000\r\n']) {
  await check(`saju preserves optional/empty question ${JSON.stringify(question)}`, async () => {
    const state = await setup();
    const result = await post('saju', state, { ...birth, customQuestion: question });
    assert.equal(result.status, 200);
    assert.equal(state.calls.generate[0][2], question?.trim());
    assert.equal(state.ai.__probeCleanQuestion(state.calls.generate[0][2]), undefined);
    assert.equal(JSON.parse(result.wireJson).fortune.sections[2].title, '3. 생활 속에서 살펴볼 점');
  });
  await check(`chat preserves empty/missing rejection ${JSON.stringify(question)}`, async () => {
    const state = await setup();
    assert.equal((await post('chat', state, { question })).status, 400);
    assert.equal(state.calls.getFortune.length + state.calls.ask.length + state.calls.sql.length, 0);
  });
}
for (const category of [null, 42, 'invalid']) {
  await check(`saju category guard ${JSON.stringify(category)}`, async () => {
    const state = await setup();
    assert.equal((await post('saju', state, { ...birth, category, customQuestion: validCases[0][1] })).status, 400);
    assert.equal(state.calls.analyze.length + state.calls.generate.length + state.calls.sql.length, 0);
  });
}
await check('saju preserves real solar date validation', async () => {
  const state = await setup();
  assert.equal((await post('saju', state, { ...birth, birthYear: 2001, customQuestion: validCases[0][1] })).status, 400);
  assert.equal(state.calls.analyze.length + state.calls.generate.length + state.calls.sql.length, 0);
});
await check('chat preserves missing-fortune 404 before generation/storage writes', async () => {
  const state = await setup({ missingFortune: true });
  const result = await post('chat', state, { question: validCases[0][1] });
  assert.equal(result.status, 404);
  assert.equal(JSON.parse(result.wireJson).error, '사주 결과를 찾을 수 없습니다.');
  assert.equal(state.calls.getFortune.length, 1);
  assert.equal(state.calls.ask.length + state.calls.addChatMessage.length, 0);
  assert.ok(state.calls.sql.every(call => call.operation === 'first'));
});
const aiCleanerObservations = [];
await check('private AI cleaner separately retains its 500-unit cap and empty semantics', async () => {
  const state = await setup();
  for (const [id, question] of validCases) {
    const cleaned = state.ai.__probeCleanQuestion(question);
    assert.equal(cleaned, question.trim().slice(0, 500));
    aiCleanerObservations.push({ id, directInput: profile(question), privateCleanerOutput: profile(cleaned) });
  }
  assert.equal(state.ai.__probeCleanQuestion(), undefined);
  assert.equal(state.ai.__probeCleanQuestion(' \t\u3000'), undefined);
});
await check('existing malformed question input remains outside the reviewed helper guarantee', async () => {
  const state = await setup();
  for (const question of ['가'.repeat(499) + '\ud83d', '가'.repeat(499) + '\ude42', '\ud83dA' + '가'.repeat(501)]) {
    assert.equal(question.isWellFormed(), false);
    assert.equal(state.ai.__probeCleanQuestion(question), question.slice(0, 500));
    assert.equal(helper(question, 500), question.slice(0, 500));
  }
});
let transportObservation;
await check('JSON preserves lone surrogates while direct UTF8 and URL conversions do not', () => {
  const damaged = validCases[0][1].slice(0, 500);
  const replacement = '가'.repeat(499) + '\ufffd';
  const json = JSON.stringify({ question: damaged });
  assert.ok(json.includes('\\ud83d'));
  assert.equal(JSON.parse(Buffer.from(json, 'utf8').toString('utf8')).question, damaged);
  assert.equal(Buffer.from(damaged, 'utf8').toString('utf8'), replacement);
  assert.equal(new TextDecoder().decode(new TextEncoder().encode(damaged)), replacement);
  assert.equal(new URLSearchParams(new URLSearchParams({ question: damaged }).toString()).get('question'), replacement);
  assert.throws(() => encodeURIComponent(damaged), URIError);
  transportObservation = { input: profile(damaged), jsonRoundTrip: profile(JSON.parse(json).question), directUtf8RoundTrip: profile(Buffer.from(damaged, 'utf8').toString('utf8')), URLSearchParams: profile(new URLSearchParams({ question: damaged }).get('question')), encodeURIComponent: 'throws URIError', conclusion: 'Replacement is transport-specific. JSON escaping preserves the malformed JS string; actual D1/provider transport behavior is not established.' };
});
await check('all snapshots, helper and historical checkout remain unchanged', () => {
  for (const entry of manifest.snapshots) {
    source(entry.path);
    assert.equal(sha256(readFileSync(path.join(manifest.historicalCheckout, entry.path))), entry.sha256);
  }
  assert.equal(sha256(readFileSync(manifest.reviewedHelper.path)), manifest.reviewedHelper.sha256);
  assert.equal(execFileSync('git', ['rev-parse', 'HEAD'], { cwd: manifest.historicalCheckout, encoding: 'utf8' }).trim(), manifest.historicalCommit);
  assert.equal(execFileSync('git', ['status', '--porcelain=v1', '--untracked-files=all'], { cwd: manifest.historicalCheckout, encoding: 'utf8' }), manifest.initialGitStatus);
  assert.deepEqual(blocked, { network: 0, lunar: 0, unexpectedImports: 0 });
});
const summary = { runtime: process.version, historicalCommit: manifest.historicalCommit, tests: results.length, passed: results.filter(item => item.passed).length, failed: results.filter(item => !item.passed).length, observedRouteCases: observations.length, sourceSnapshotsHashVerified: manifest.snapshots.length, helperHash: manifest.reviewedHelper.sha256, productionCodeChanged: false, providerOrD1Calls: false, blocked };
writeFileSync(path.join(artifactRoot, 'probe-results.json'), JSON.stringify({ summary, results, observations, aiCleanerObservations, transportObservation }, null, 2) + '\n');
console.log(JSON.stringify(summary, null, 2));
for (const failure of results.filter(item => !item.passed)) console.error(failure.name, failure.error);
process.exitCode = summary.failed ? 1 : 0;
