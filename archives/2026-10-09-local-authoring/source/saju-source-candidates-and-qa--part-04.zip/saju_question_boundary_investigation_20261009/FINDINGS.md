# Question boundary characterization, historical source only

The existing UTF-16 truncation defect also reaches question generation and storage handoffs. This is a coverage extension of the already-reviewed name-boundary finding, not a separate algorithm or implemented fix.

## Result

On historical commit `843a4a088a9e20760421b4c81f890d026a53ae6b`, submit a valid question consisting of 499 `가` characters followed by `🙂` (501 UTF-16 code units, 500 Unicode code points). Both actual POST route bodies accept the JSON request, trim it, then truncate to 500 UTF-16 units. The result is 499 `가` characters followed by the isolated high surrogate `U+D83D`.

- `app/api/saju/route.ts:24`: the malformed `customQuestion` reaches `generateFortune`. The actual local AI template embeds it in `fortune.sections[2].content`; the value reaches `db.saveFortune`, the historical store's JSON string binding, and the native JSON response.
- `app/api/saju/[id]/chat/route.ts:16`: the malformed `cleanQuestion` reaches `askDoryeong` and the user-content storage argument. The actual local AI template includes the malformed question in its reply, which also reaches the reply-content storage argument and native JSON response.
- `lib/ai/doryeong-ai.ts:192`: direct invocation of the existing private `cleanQuestion` on the same valid original input independently reproduces the split at `MAX_QUESTION_CHARS = 500`. Calling it after a route has already discarded the low surrogate cannot repair the input.

Both padded and unpadded inputs reproduce the split. Controls that remain well formed include 498 BMP characters plus the astral character (exactly 500 units), 500 BMP characters followed by the astral character, 501 BMP characters, and 251 astral characters. Short questions retain trimming behavior.

## JSON is not a Unicode repair step

The incoming well-formed question survives native `Request` JSON decoding intact. The route introduces the malformed string.

`JSON.stringify` escapes its isolated surrogate as `\ud83d`. Encoding that JSON string as UTF-8 and subsequently parsing it recreates the same malformed JavaScript string. The historical fortune store uses `JSON.stringify(fortune)` and therefore preserves the malformed value at its prepared-statement binding. The response's native `Response.json` round trip likewise preserves it.

Directly encoding the malformed string using `Buffer` or `TextEncoder`, or placing it into `URLSearchParams`, produces a replacement character `U+FFFD`. `encodeURIComponent` throws `URIError` instead. These are transport-specific observations. The chat store binds the direct string before any actual D1 transport; this investigation does **not** establish whether real D1 would preserve, replace, or reject it. No provider transport was exercised.

## Scope and seams

The probe executes complete, hash-pinned historical source bodies for both routes, the input parser and input-error class, AI module, and store. Node's built-in TypeScript transform removes types; route bodies and normalization expressions are not rewritten. One appended export exposes the existing private AI cleaner for separate characterization.

Explicit replacements are:

- `next/server`: native `Request` plus `NextResponse.json` backed by native `Response.json`. The installed Next.js runtime is not tested.
- `@/lib/saju/manse`: a deterministic, synthetic analysis fixture. Actual `parseJsonBody`, `parseSajuInput`, solar-date validation, and input errors execute. Lunar conversion is a throwing, unused seam; calendar correctness is not assessed.
- AI import: argument-recording wrappers delegate to the complete historical AI module. Its existing `configuredProvider()` returns `undefined`, so the actual local templates run. `fetch` and provider timers are blocked; no environment variables, credentials, or actual providers are used.
- Storage import: argument-recording wrappers delegate to the complete historical store. Authentication returns a synthetic owner, and `cloudflare:workers` receives an in-memory prepared-statement recorder. It records the exact SQL bind arguments and returns fixtures; it performs no D1 IO and does not test database persistence or atomicity.
- All other runtime imports are rejected. Type-only imports are erased.

The old chat route predates queued atomic-exchange persistence `875a283`. Its historical write structure is used only to observe question/reply strings. It is **not** represented as current behavior, retested as an atomicity issue, or provided as a replacement route.

## Preserved controls

The 51 passing characterization checks confirm the existing defect as an expected observation; they do not mean it is fixed. They cover:

- 14 accepted route cases, including the split, exact-fit and trim controls.
- Invalid JSON and null, array, primitive bodies rejected before generation or storage.
- Non-string question types rejected by both routes.
- Optional/empty initial questions retained as allowed inputs; the AI cleaner maps empty strings to `undefined`.
- Missing/empty chat questions rejected before fortune lookup.
- Invalid initial categories and invalid solar dates rejected before generation/storage.
- Chat missing-fortune `404` retained, with no AI invocation or storage write.
- Private AI cleaner behavior, pre-existing malformed input outside the helper guarantee, and transport differences.
- Source snapshots, reviewed helper hash, original commit, and originally clean checkout status unchanged.

## Reusing the reviewed helper

Reusing `truncateUtf16WithoutSplittingPair` at the current canonical question truncation sites is justified. The existing helper, imported unchanged and hash checked as `4d84f006107e4b30aa60598574fdd4a6160fef03d25a7743e6a29b3e6887f53f`, returns 499 BMP characters for the split case and retains complete characters within the existing 500-unit cap. It has not been copied, modified, or redesigned here.

It must act on the original trimmed string **before** the destructive slice. Adding it after an old route's slice cannot recover the discarded low surrogate. Preserve existing type/empty guards, trimming ownership, optional-question semantics, and cap values. Existing malformed inputs, normalization, and full grapheme preservation remain outside its guarantee.

Latest `2709bb7` is unavailable, so this report identifies historical sites only. Any eventual change should be small normalization hunks reconciled into restored latest code and its canonical cap ownership, preserving queued `875a283` and other newer behavior. No implementation, patch package, commit, upload, or deployment is included.

## Reproduce and evidence

Run from this directory with Node 24:

```sh
node --experimental-vm-modules probe-question-boundaries.mjs
```

The probe uses Node built-ins only. It reads the unchanged reviewed helper from the path recorded in `source-manifest.json`; no package installation is needed. Both VM modules and TypeScript stripping emit Node experimental-feature warnings.

- `source-manifest.json`: commit identity, seven snapshot hashes, helper identity, initial checkout status, and latest-source limitation.
- `source-snapshots/`: byte-for-byte source evidence, including the historical store and erased type definitions.
- `probe-results.json`: 51/51 passing characterization checks, 14 route observations, private-cleaner observations, and transport evidence.
- `probe-question-boundaries.mjs`: documented, isolated executable reproduction.

No network request, actual provider call, lunar-conversion call, actual D1 call, or unexpected import occurred. The historical checkout and the existing helper remain unchanged.
