import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { stripTypeScriptTypes } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const review = path.dirname(fileURLToPath(import.meta.url));
const artifact = path.dirname(review);
const historical = path.resolve(artifact, '../saju_planet_preview');
const hash = value => createHash('sha256').update(value).digest('hex');
const git = (...args) => execFileSync('git', args, { cwd: historical, encoding: 'utf8', env: { ...process.env, GIT_OPTIONAL_LOCKS: '0' } });
function sourceSnapshot() {
  return { head: git('rev-parse', 'HEAD').trim(), status: git('status', '--porcelain=v1'),
    trackedFiles: Object.fromEntries(git('ls-files', '-z').split('\0').filter(Boolean).map(name => [name, hash(readFileSync(path.join(historical, name)))])) };
}
const before = sourceSnapshot();
assert.equal(before.head, '843a4a088a9e20760421b4c81f890d026a53ae6b');
assert.equal(before.status, '');
assert.deepEqual(before, JSON.parse(readFileSync(path.join(artifact, 'source-before.json'), 'utf8')));
const original = readFileSync(path.join(historical, 'lib/saju/input.ts'), 'utf8');
const errorSource = readFileSync(path.join(historical, 'lib/saju/input-error.ts'), 'utf8');
const helperSource = readFileSync(path.join(artifact, 'candidate/name-boundary.ts'), 'utf8');
const patchSource = readFileSync(path.join(artifact, 'candidate.patch'), 'utf8');

// Execute the actual unified patch in memory, independently of the author's oldLine replacement.
const patchLines = patchSource.trimEnd().split('\n');
const patchedFiles = {};
let cursor = 0;
while (cursor < patchLines.length) {
  const beforeHeader = patchLines[cursor++];
  const afterHeader = patchLines[cursor++];
  assert.ok(beforeHeader.startsWith('--- '));
  assert.ok(afterHeader.startsWith('+++ b/'));
  const name = afterHeader.slice(6);
  assert.ok(['lib/saju/input.ts', 'lib/saju/name-boundary.ts'].includes(name));
  const oldLines = beforeHeader === '--- /dev/null' ? [] : original.trimEnd().split('\n');
  let consumed = 0;
  const output = [];
  while (cursor < patchLines.length && patchLines[cursor].startsWith('@@ ')) {
    const hunk = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/.exec(patchLines[cursor++]);
    assert.ok(hunk);
    const start = Number(hunk[1]) === 0 ? 0 : Number(hunk[1]) - 1;
    assert.ok(start >= consumed);
    output.push(...oldLines.slice(consumed, start));
    consumed = start;
    let removed = 0, added = 0;
    while (cursor < patchLines.length && !patchLines[cursor].startsWith('@@ ') && !patchLines[cursor].startsWith('--- ')) {
      const line = patchLines[cursor++];
      assert.ok([' ', '-', '+'].includes(line[0]));
      if (line[0] !== '+') { assert.equal(line.slice(1), oldLines[consumed++]); removed++; }
      if (line[0] !== '-') { output.push(line.slice(1)); added++; }
    }
    assert.equal(removed, Number(hunk[2] ?? 1));
    assert.equal(added, Number(hunk[4] ?? 1));
  }
  output.push(...oldLines.slice(consumed));
  assert.equal(patchedFiles[name], undefined);
  patchedFiles[name] = output.join('\n') + '\n';
}
assert.equal(Object.keys(patchedFiles).length, 2);
assert.equal(patchedFiles['lib/saju/name-boundary.ts'], helperSource);
const candidateSource = patchedFiles['lib/saju/input.ts'];
const nameLine = '  const name = typeof input.name === "string" ? truncateUtf16WithoutSplittingPair(input.name.trim(), 50) : "";';
assert.equal(candidateSource.split(nameLine).length - 1, 1);
assert.equal(candidateSource.replace('import { truncateUtf16WithoutSplittingPair } from "./name-boundary";\n', '')
  .replace(nameLine, '  const name = typeof input.name === "string" ? input.name.trim().slice(0, 50) : "";'), original);

const url = source => `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
const errorUrl = url(stripTypeScriptTypes(errorSource, { mode: 'transform' }));
const helperUrl = url(stripTypeScriptTypes(helperSource, { mode: 'strip' }));
// Controlled lunar dependency tests parser call arguments/branching only, not calendar conversion.
const lunarUrl = url('export function koreanLunarToSolar(date, leap) { return {year: date.year, month: date.month, day: date.day, reviewSeam: true, leap}; }');
async function load(source) {
  const isolated = source.replaceAll('"./input-error"', JSON.stringify(errorUrl))
    .replace('"./lunar-calendar"', JSON.stringify(lunarUrl))
    .replace('"./name-boundary"', JSON.stringify(helperUrl));
  return import(url(stripTypeScriptTypes(isolated, { mode: 'strip' })));
}
const baseline = await load(original);
const candidate = await load(candidateSource);
const { truncateUtf16WithoutSplittingPair: truncate } = await import(helperUrl);
const birth = { birthYear: 2000, birthMonth: 2, birthDay: 29, birthHour: 12, birthMinute: 30 };
const results = [];
async function check(label, action) { await action(); results.push(label); }
function prefixOracle(value, cap) {
  let output = '';
  for (const scalarOrMalformedUnit of value) {
    if (output.length + scalarOrMalformedUnit.length > cap) break;
    output += scalarOrMalformedUnit;
  }
  return output;
}
let seed = 0x75819e32;
const next = () => (seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0);
const tokens = ['A', '가', '𠮷', '🙂', '\ud800', '\udbff', '\udc00', '\udfff', '\ud7ff', '\ue000', 'e\u0301', '👩‍💻', '🇰🇷', '👍🏻', ' ', '\u3000', '\u0000'];
for (let index = 0; index < 5000; index++) {
  let value = '';
  const length = next() % 100;
  for (let count = 0; count < length; count++) value += tokens[next() % tokens.length];
  const cap = next() % 100;
  await check(`independent-scalar-prefix-${index}`, () => {
    const output = truncate(value, cap);
    assert.equal(output, prefixOracle(value, cap));
    assert.ok(output.length <= cap);
    if (value.length <= cap) assert.equal(output, value);
    const slice = value.slice(0, cap);
    assert.ok(output === slice || output === slice.slice(0, -1));
  });
}
const overrides = [
  {}, { gender: 'female' }, { gender: 'other' }, { gender: null },
  { calendarType: 'solar' }, { calendarType: 'lunar' }, { calendarType: 'leap-lunar' }, { calendarType: 'bad' }, { calendarType: null },
  { birthYear: 2001 }, { birthMonth: 4, birthDay: 31 }, { birthYear: '2000', birthMonth: ' 2 ', birthDay: '29' },
  { birthYear: 1900, birthMonth: 1, birthDay: 1 }, { birthYear: 2100, birthMonth: 12, birthDay: 31 },
  { isUnknownTime: true }, { isUnknownTime: true, birthHour: 'garbage', birthMinute: [] },
  { isUnknownTime: false }, { isUnknownTime: 'false' }, { isUnknownTime: null },
  { birthHour: undefined }, { birthMinute: undefined }, { birthHour: 23, birthMinute: 59 }, { birthHour: 0, birthMinute: 0 },
  { calendarType: 'lunar', birthYear: 2050, birthMonth: 11, birthDay: 18 },
  { calendarType: 'lunar', birthYear: 2050, birthMonth: 11, birthDay: 19 },
  { calendarType: 'lunar', birthDay: 31 }, { calendarType: 'leap-lunar', birthYear: 2051 },
];
for (const field of ['birthYear', 'birthMonth', 'birthDay', 'birthHour', 'birthMinute']) {
  for (const value of [undefined, null, [], {}, true, '', '  ', '-1', '1.5', '1e1', '01', -1, 0, 1.5, 9999, NaN, Infinity]) overrides.push({ [field]: value });
}
function outcome(parser, payload) {
  try {
    const { name, ...rest } = parser.parseSajuInput(payload);
    return { kind: 'success', name, rest };
  } catch (error) { return { kind: 'error', name: error.name, message: error.message, status: error.status }; }
}
for (const [index, override] of overrides.entries()) {
  for (const [nameIndex, name] of ['홍길동', '가'.repeat(49) + '🙂', '\ud800' + '가'.repeat(48) + '🙂', ' \u3000 ', 42].entries()) {
    await check(`non-name-and-error-parity-${index}-${nameIndex}`, () => {
      const payload = { ...birth, ...override, name };
      const old = outcome(baseline, payload);
      const current = outcome(candidate, payload);
      if (old.kind === 'error') assert.deepEqual(current, old);
      else {
        assert.equal(current.kind, 'success');
        assert.deepEqual(current.rest, old.rest);
        assert.equal(current.name, prefixOracle(name.trim(), 50));
      }
    });
  }
}
for (const [index, payload] of [undefined, null, false, [], 42, '', 'text', {}, { name: '' }].entries()) {
  await check(`top-level-object-error-${index}`, () => assert.deepEqual(outcome(candidate, payload), outcome(baseline, payload)));
}
await check('json-ingress-invalid-syntax-and-other-errors', async () => {
  for (const parser of [baseline, candidate]) {
    await assert.rejects(parser.parseJsonBody({ json: async () => { throw new SyntaxError('bad JSON'); } }), { name: 'SajuInputError', status: 400, message: 'JSON 입력 형식을 확인해주세요.' });
    const error = new Error('request failure');
    await assert.rejects(parser.parseJsonBody({ json: async () => { throw error; } }), candidate => candidate === error);
    await assert.rejects(parser.parseJsonBody({ json: async () => [] }), { name: 'SajuInputError', status: 400 });
  }
});
await check('actual-patched-json-ingress-and-wire-distinction', async () => {
  const input = '가'.repeat(49) + '🙂';
  const bodyText = JSON.stringify({ ...birth, name: input });
  for (const parser of [baseline, candidate]) {
    const body = await parser.parseJsonBody({ json: async () => JSON.parse(bodyText) });
    assert.equal(body.name, input);
    const name = parser.parseSajuInput(body).name;
    assert.equal(JSON.parse(Buffer.from(JSON.stringify({ name }), 'utf8').toString('utf8')).name, name);
    if (parser === baseline) {
      assert.equal(name.charCodeAt(49), 0xd83d);
      assert.equal(name.isWellFormed(), false);
      assert.equal(Buffer.from(name, 'utf8').toString('utf8'), '가'.repeat(49) + '\ufffd');
      assert.equal(new URLSearchParams({ name }).get('name'), '가'.repeat(49) + '\ufffd');
      assert.throws(() => encodeURIComponent(name), URIError);
    } else {
      assert.equal(name, '가'.repeat(49));
      assert.equal(Buffer.from(name, 'utf8').toString('utf8'), name);
      assert.equal(new URLSearchParams({ name }).get('name'), name);
      assert.equal(decodeURIComponent(encodeURIComponent(name)), name);
    }
  }
});
await check('trim-order-and-no-normalization', () => {
  for (const name of [' \t' + '가'.repeat(49) + '🙂\r\n', '\u3000𠮷田\u00a0', 'Jose\u0301', '\u1100\u1161', '가'.repeat(49) + 'e\u0301', '가'.repeat(48) + '👩‍💻']) {
    assert.equal(candidate.parseSajuInput({ ...birth, name }).name, prefixOracle(name.trim(), 50));
  }
});
await check('unknown-property-omission-and-hour-periods', () => {
  const parsed = candidate.parseSajuInput({ ...birth, name: '홍길동', unrelated: 'discarded' });
  assert.equal(Object.hasOwn(parsed, 'unrelated'), false);
  assert.deepEqual(candidate.HOUR_PERIODS, baseline.HOUR_PERIODS);
});
assert.deepEqual(sourceSnapshot(), before);
const report = { runtime: process.version, checksPassed: results.length, checksFailed: 0,
  historicalHead: before.head, historicalTrackedFilesUnchanged: Object.keys(before.trackedFiles).length,
  parserSha256: hash(original), errorModuleSha256: hash(errorSource), helperSha256: hash(helperSource),
  patchSha256: hash(patchSource), patchedParserSha256: hash(candidateSource),
  seams: ['Only error/lunar/helper import specifiers are replaced in memory before TypeScript stripping.', 'Real error class is transformed; lunar dependency is a deterministic recording seam for parser branching, not a real lunar conversion.'],
  groups: { randomizedScalarPrefix: 5000, fieldAndErrorParity: overrides.length * 5, topLevelInputs: 9, groupedRegressionChecks: 4 }, results };
writeFileSync(path.join(review, 'independent-results.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ ...report, results: undefined }, null, 2));
