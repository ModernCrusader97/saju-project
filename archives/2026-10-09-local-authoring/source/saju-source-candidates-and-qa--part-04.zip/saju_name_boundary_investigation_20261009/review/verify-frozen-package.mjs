import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const review = path.dirname(fileURLToPath(import.meta.url));
const artifact = path.dirname(review);
const historical = path.resolve(artifact, '../saju_planet_preview');
const sha256 = value => createHash('sha256').update(value).digest('hex');
const frozen = readFileSync(path.join(artifact, 'frozen-manifest.sha256'), 'utf8');
const entries = frozen.trim().split('\n').map(line => {
  const match = /^([a-f0-9]{64})  (.+)$/.exec(line);
  assert.ok(match, `Invalid manifest line: ${line}`);
  assert.ok(!path.isAbsolute(match[2]) && !match[2].split('/').includes('..') && !match[2].startsWith('review/'));
  return { name: match[2], expected: match[1] };
});
function verifyFrozen(root) {
  for (const { name, expected } of entries) assert.equal(sha256(readFileSync(path.join(root, name))), expected, `Frozen hash: ${name}`);
}
verifyFrozen(artifact);
const outcomes = [];
function run(label, root, script, args = [], expectedExit = 0, hideGit = false) {
  const outputDir = path.join(review, 'final-runs', label);
  mkdirSync(outputDir, { recursive: true });
  const restrictToPackage = hideGit && !args.some(argument => argument.startsWith('--verify-checkout='));
  const permissionArgs = restrictToPackage ? ['--permission', `--allow-fs-read=${root}`, `--allow-fs-write=${outputDir}`] : [];
  const result = spawnSync(process.execPath, [...permissionArgs, path.join(root, script), ...args], {
    cwd: root, encoding: 'utf8',
    env: { ...process.env, SAJU_BOUNDARY_OUTPUT_DIR: outputDir, ...(hideGit ? { PATH: '' } : {}) },
  });
  writeFileSync(path.join(outputDir, 'stdout.log'), result.stdout ?? '');
  writeFileSync(path.join(outputDir, 'stderr.log'), result.stderr ?? '');
  const summaryFile = script === 'reproduce.mjs' ? 'evidence.json' : args.includes('--candidate') ? 'green-results.json' : 'red-results.json';
  const resultPath = path.join(outputDir, summaryFile);
  const document = existsSync(resultPath) ? JSON.parse(readFileSync(resultPath, 'utf8')) : null;
  const summary = document?.summary ?? (document && { ...document, observations: undefined, matrix: undefined, invalidNameControls: undefined, alreadyMalformedControls: undefined });
  outcomes.push({ label, script, args, scriptSha256: sha256(readFileSync(path.join(root, script))), exitCode: result.status, gitUnavailableByPath: hideGit, readsRestrictedToPackage: restrictToPackage, summary });
  assert.equal(result.status, expectedExit, `${label} unexpected exit: ${result.stderr}`);
  return { document, stderr: result.stderr, summary };
}
const reproduction = run('evidence', artifact, 'reproduce.mjs').document;
const baseline = run('baseline', artifact, 'test-boundary.mjs', [], 1).document;
const candidate = run('candidate', artifact, 'test-boundary.mjs', ['--candidate']).document;
assert.deepEqual(reproduction, JSON.parse(readFileSync(path.join(artifact, 'evidence.json'), 'utf8')));
assert.deepEqual(baseline, JSON.parse(readFileSync(path.join(artifact, 'red-results.json'), 'utf8')));
assert.deepEqual(candidate, JSON.parse(readFileSync(path.join(artifact, 'green-results.json'), 'utf8')));
assert.equal(baseline.summary.tests, 986);
assert.equal(baseline.summary.failed, 18);
assert.equal(candidate.summary.tests, 987);
assert.equal(candidate.summary.failed, 0);
const checked = run('explicit-checkout', artifact, 'test-boundary.mjs', ['--candidate', `--verify-checkout=${historical}`]).document;
assert.equal(checked.summary.originalCheckoutVerification.verified, true);
assert.equal(checked.summary.originalCheckoutVerification.files, 151);

// Detached copy: no sibling checkout exists and PATH cannot resolve Git.
const detached = path.join(review, 'detached', 'candidate-package');
mkdirSync(detached, { recursive: true });
assert.equal(existsSync(path.resolve(detached, '../saju_planet_preview')), false);
for (const { name } of entries) {
  const target = path.join(detached, name);
  mkdirSync(path.dirname(target), { recursive: true });
  writeFileSync(target, readFileSync(path.join(artifact, name)));
}
writeFileSync(path.join(detached, 'frozen-manifest.sha256'), frozen);
verifyFrozen(detached);
const detachedEvidence = run('detached-evidence', detached, 'reproduce.mjs', [], 0, true).document;
assert.deepEqual({ ...detachedEvidence, sourceRoot: reproduction.sourceRoot }, reproduction);
const detachedBaseline = run('detached-baseline', detached, 'test-boundary.mjs', [], 1, true).document;
assert.deepEqual(detachedBaseline, baseline);
const detachedCandidate = run('detached-candidate', detached, 'test-boundary.mjs', ['--candidate'], 0, true).document;
assert.deepEqual(detachedCandidate, candidate);
const missingPath = path.join(review, 'intentionally-nonexistent-checkout');
assert.equal(existsSync(missingPath), false);
const unavailable = run('explicit-missing-checkout', detached, 'test-boundary.mjs', ['--candidate', `--verify-checkout=${missingPath}`], 1, true).document;
assert.equal(unavailable.summary.originalCheckoutVerification.status, 'unavailable');
assert.equal(unavailable.summary.originalCheckoutVerification.verified, false);
assert.equal(unavailable.summary.failed, 0);

const tampered = path.join(detached, 'snapshots/original/lib/saju/input.ts');
const snapshotBytes = readFileSync(tampered);
writeFileSync(tampered, Buffer.concat([snapshotBytes, Buffer.from('\n// Deliberate review-only integrity-test tamper\n')]));
const rejected = run('tampered-snapshot', detached, 'test-boundary.mjs', ['--candidate'], 1, true);
assert.equal(rejected.document, null);
assert.match(rejected.stderr, /Snapshot hash: lib\/saju\/input.ts/);
writeFileSync(tampered, snapshotBytes);
verifyFrozen(detached);
verifyFrozen(artifact);
writeFileSync(path.join(review, 'published-rerun.json'), JSON.stringify({ frozenManifestSha256: sha256(frozen), outcomes }, null, 2) + '\n');
console.log(JSON.stringify({ frozenManifestSha256: sha256(frozen), frozenFiles: entries.length, runs: outcomes.map(({ label, exitCode, summary }) => ({ label, exitCode, tests: summary?.tests, failed: summary?.failed, checkout: summary?.originalCheckoutVerification })) }, null, 2));
