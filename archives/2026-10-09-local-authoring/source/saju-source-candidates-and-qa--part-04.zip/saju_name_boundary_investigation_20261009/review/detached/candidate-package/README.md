# SaJu name truncation boundary: investigation and isolated candidate

The historical parser demonstrably creates invalid UTF-16 from valid names. With 49 Korean BMP characters followed by 🙂, the trimmed input has 51 UTF-16 units. `parseSajuInput` returns 50 units ending in a lone U+D83D. Direct UTF-8 encoding replaces that unit with U+FFFD; the result no longer equals the parser's string. The same bug affects ordinary astral CJK text such as 𠮷 at that boundary.

The isolated candidate preserves the existing 50-UTF-16-unit limit and trim order. It reduces the slice endpoint by one only when the endpoint divides an existing high-surrogate/low-surrogate pair. The example then returns the 49 intact Korean characters. No source checkout was edited, committed, built, uploaded, or deployed.

## Evidence and scope

- Historical provenance: clean commit `843a4a088a9e20760421b4c81f890d026a53ae6b`, originally read from `../saju_planet_preview`. Default execution now uses the included hash-pinned `snapshots/original/` files and does not require that checkout. This is not a claim about the unavailable latest source or a live deployment.
- `lib/saju/input.ts` SHA-256: `7880ae0a8808631918cc3d33ac4acc39955443fac9c4d24acc11077b17e220cf`.
- Runtime: Node `v24.19.0`. Only built-in Node APIs were used for reproduction and tests; Python standard-library difflib generated the patch. No packages were installed or loaded.
- The harness reads a byte-identical snapshot of the actual historical `input.ts`, rewrites only import specifiers in memory, and runs its actual `parseJsonBody` and `parseSajuInput`. Node strips TypeScript from the parser. The real `input-error.ts` snapshot is transformed by Node because it uses a constructor parameter property. The lunar import is an explicit throwing seam, separately checked; its source and `types.ts` are included for provenance. All substantive parser cases use a real valid solar payload: 2000-02-29, 12:30, known time, male, solar.
- Original `source-before.json`/`source-after.json` manifests cover all 151 tracked files. Captured hashes, HEAD and empty Git status match. Every default run verifies all four included source snapshots against pinned hashes and the original manifests. A separate optional original-checkout verification rechecked all 151 files, revision and status successfully. No source-file contents beyond the four relevant modules are packaged.
- `reproduce.mjs` records 28 named well-formed controls plus an 896-case generated matrix. Four named cases and nine generated cases produce invalid UTF-16 in the historical parser. The cases overlap and are not incident counts.

The first red run occurred before the candidate helper existed: 937 checks, 14 expected failures. Subsequent endpoint coverage added 49 combinations of the inclusive surrogate-range limits and adjacent ordinary code units. The final red run has 986 checks, 968 passing and 18 expected failures. The final candidate run has 987 checks, all passing; it includes one additional helper-level check with seven assertions. The 18 baseline failures are the four named split-pair cases, nine generated split-pair cases, one malformed-interior case with a separate valid pair at the cut, and four surrogate endpoint-pair cases.

`red-run.log`, `red-results.json`, `green-run.log`, and `green-results.json` retain the final executions. Exit codes are 1 for the expected baseline regression and 0 for the candidate. These final default runs, plus `reproduce.mjs`, ran under Node's permission model with file reads/writes allowed only inside this artifact directory. The old checkout was inaccessible to those Node processes, proving that it is not a runtime dependency. Node emits its expected experimental `stripTypeScriptTypes` warning; there are no package/build results to infer from this harness.

`packaging-check/verified/` records the separately requested live original-checkout check (151 files verified; exit 0). `packaging-check/unavailable/` records a nonexistent optional checkout: all 987 functional checks pass, but checkout status is `unavailable` and the process exits 1. Without the optional flag, status is explicitly `not-requested`, never a claim that the current original checkout was verified.

## Transport and display distinction

- `Buffer.from(name, 'utf8').toString('utf8')` and `TextEncoder`/`TextDecoder` change a lone surrogate to U+FFFD.
- `URLSearchParams` similarly converts it to U+FFFD. `encodeURIComponent` throws `URIError` for that ill-formed string.
- `JSON.stringify` escapes the lone surrogate. A JSON → UTF-8 → JSON parse round-trip retains the original lone UTF-16 code unit. JSON escaping therefore preserves the invalid string rather than repairing it. It does **not** demonstrate data loss in JSON storage by itself.
- Static callers retain the parsed name: `lib/saju/manse.ts:217` parses it and `:331` returns it; `app/api/guin/route.ts:22` and `app/api/guin/[id]/route.ts:57` store it in returned data. `lib/db/store.ts:14` serializes values as JSON. These paths were read, not executed end to end.
- This establishes a parser-level integrity bug and transport-dependent output inconsistency. No browser rendering, glyph behavior, actual HTTP framework response, database operation, or production defect was verified.

## Narrow correction and compatibility

`candidate/name-boundary.ts` contains the independently reusable algorithm. The caller supplies its existing shared integer limit and already-trimmed string. The helper checks only the two code units around the cut. It adds no normalization, grapheme segmentation, rejection policy, or input-wide Unicode repair.

Covered behavior:

- In-cap well-formed names remain exact after the same existing trim, including BMP/Korean, astral CJK, emoji, decomposed Latin and decomposed Korean.
- 48 BMP units plus one astral character fit exactly at 50. 49 BMP units plus one astral character return 49 intact units. 50 BMP units plus an astral character return the same 50 BMP units as before.
- 25 two-unit emoji still fit the 50-unit cap; 26 still truncate to 25. This is not a 50-code-point or 50-grapheme rule.
- Whitespace-only, empty, missing and non-string names retain the historical rejection. Solar date validation remains active.
- Isolated high/low surrogates and malformed interior text remain unchanged outside the proven split-pair case. A malformed interior plus a separately valid pair at the cut only changes that cut. This is intentional scope control, not a recommendation to accept malformed text in a different current contract.
- Combining marks, ZWJ sequences, modifiers and flags can still be split between complete code points. Their grapheme appearance can therefore change, just as before. Preserving whole graphemes would be a separate naming-policy decision.

## Integration requirement after latest-source restoration

The queued `28fa9f4` change already centralizes the 50-unit name contract. Reuse that existing shared canonical parser/helper and limit when integrating this correction. Add the boundary check at its canonical truncation step, and let its existing callers continue using it. Do not introduce separate frontend/backend truncators or a second limit constant.

`candidate.patch` is a minimal demonstration against the designated historical revision only. It adds the helper and replaces the historical parser's one slice call. Its literal `50` reflects that old source, not a request to add a competing limit to the restored code. `git apply --check` succeeds on that historical checkout, but the patch has not been applied there.

Do not copy the full historical input module over restored latest code, blindly apply this patch to latest, or treat this candidate as a substitute for restoration. Preserve any independently queued input validation and name-contract work. Re-express the small algorithm in the restored shared helper, pass its canonical limit, rerun these boundary contracts plus the restored project's relevant checks, and reconcile any current malformed-input policy rather than weakening it.

## Reproduction and review

From this directory:

1. `node reproduce.mjs` records the old parser behavior; exit 0 means the historical defect and controls were reproduced.
2. `node test-boundary.mjs` runs the desired contract against old source and must exit 1 with the documented 18 baseline failures.
3. `node test-boundary.mjs --candidate` runs the same snapshotted parser with only the candidate helper import and call substituted in memory; exit 0, 987 passing checks.
4. Optionally append `--verify-checkout=/absolute/path/to/the/historical/checkout` to either script to verify the original 151-file manifest plus Git revision/status. An unavailable or changed checkout is explicitly reported and makes the run exit 1; no original checkout is read by default.
5. When that historical checkout exists, `git -C /absolute/path/to/the/historical/checkout apply --check "$PWD/candidate.patch"` validates patch context without applying it. Git is not needed for the default parser tests.

For independent review after freeze, create/use `review/` and set `SAJU_BOUNDARY_OUTPUT_DIR="$PWD/review"` when running any harness command, redirecting logs there as well. This keeps frozen result files intact. Default source reads stay inside this artifact; the explicit optional checkout flag adds that designated read-only source. Do not overwrite frozen outputs unless a new revision of the artifact is intended.

`frozen-manifest.sha256` hashes the candidate, tests, report and evidence files. No application build, network access, browser, deployment, desktop, external account, or latest-source retrieval was performed. This candidate is ready for independent review, not a claim that a deployed fix exists.
