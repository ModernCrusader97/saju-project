// Read-only investigation of the historical parser, using only Node built-ins.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { stripTypeScriptTypes } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const artifactDir = "/workspace/scratch/c9f1a9454187/saju_name_boundary_investigation_20261009";
const sourceRoot = path.resolve(artifactDir, '../saju_planet_preview');
const expectedHead = '843a4a088a9e20760421b4c81f890d026a53ae6b';
const sha256 = (value) => createHash('sha256').update(value).digest('hex');
const git = (...args) => execFileSync('git', args, {
  cwd: sourceRoot, encoding: 'utf8', env: { ...process.env, GIT_OPTIONAL_LOCKS: '0' },
});
const snapshot = () => ({
  head: git('rev-parse', 'HEAD').trim(),
  status: git('status', '--porcelain=v1'),
  trackedFiles: Object.fromEntries(git('ls-files', '-z').split('\0').filter(Boolean).map((name) => [
    name, sha256(readFileSync(path.join(sourceRoot, name))),
  ])),
});
const before = snapshot();
assert.equal(before.head, expectedHead, 'Only the explicitly designated historical revision is in scope');
assert.equal(before.status, '', 'The historical source must remain clean');
writeFileSync(path.join("/workspace/scratch/c9f1a9454187/saju_name_boundary_investigation_20261009/review/evidence", 'source-before.json'), JSON.stringify(before, null, 2) + '\n');

const inputSource = readFileSync(path.join(sourceRoot, 'lib/saju/input.ts'), 'utf8');
const errorSource = readFileSync(path.join(sourceRoot, 'lib/saju/input-error.ts'), 'utf8');
const dataUrl = (source) => `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
// Transform is needed only for the real error class's TS constructor parameter property.
const errorUrl = dataUrl(stripTypeScriptTypes(errorSource, { mode: 'transform' }));
// The lunar dependency would import a package. Solar cases must never call it.
const lunarUrl = dataUrl('export function koreanLunarToSolar() { throw new Error("SOLAR_ONLY_LUNAR_SEAM_CALLED"); }');
assert.equal(inputSource.split('"./input-error"').length - 1, 2);
assert.equal(inputSource.split('"./lunar-calendar"').length - 1, 1);
const isolatedSource = inputSource
  .replaceAll('"./input-error"', JSON.stringify(errorUrl))
  .replace('"./lunar-calendar"', JSON.stringify(lunarUrl));
assert.equal(isolatedSource
  .replaceAll(JSON.stringify(errorUrl), '"./input-error"')
  .replace(JSON.stringify(lunarUrl), '"./lunar-calendar"'), inputSource,
  'The parser body and every statement must be byte-identical; only import specifiers may change');
const parser = await import(dataUrl(stripTypeScriptTypes(isolatedSource, { mode: 'strip' })));

const solarPayload = {
  gender: 'male', calendarType: 'solar',
  birthYear: 2000, birthMonth: 2, birthDay: 29,
  birthHour: 12, birthMinute: 30, isUnknownTime: false,
};
const expectedBirthFields = {
  ...solarPayload, solarBirthDate: { year: 2000, month: 2, day: 29 },
};
const unitHex = (value) => Array.from({ length: value.length }, (_, i) =>
  value.charCodeAt(i).toString(16).padStart(4, '0'));
const inspect = (value) => ({
  utf16Units: value.length,
  codePoints: [...value].length,
  wellFormed: value.isWellFormed(),
  tailUtf16Hex: unitHex(value.slice(-8)),
  escapedJson: JSON.stringify(value),
});
const namedCases = [
  ['ascii-short', 'Alice'],
  ['korean-short', '홍길동'],
  ['astral-cjk-short', '𠮷田'],
  ['leading-trailing-space', ' \t홍길동\r\n'],
  ['unicode-surrounding-space', '\u00a0\u3000홍 길동\u3000\u00a0'],
  ['internal-space', '홍  길동'],
  ['bmp-49', 'A'.repeat(49)],
  ['bmp-50', 'A'.repeat(50)],
  ['bmp-51', 'A'.repeat(51)],
  ['korean-50', '가'.repeat(50)],
  ['korean-51', '가'.repeat(51)],
  ['emoji-at-49-50', '가'.repeat(48) + '🙂'],
  ['emoji-at-50-51', '가'.repeat(49) + '🙂'],
  ['emoji-after-50', '가'.repeat(50) + '🙂'],
  ['astral-cjk-at-50-51', '가'.repeat(49) + '𠮷'],
  ['astral-cjk-at-start', '𠮷' + '가'.repeat(49)],
  ['24-emojis', '🙂'.repeat(24)],
  ['25-emojis', '🙂'.repeat(25)],
  ['26-emojis', '🙂'.repeat(26)],
  ['24-emojis-bmp-emoji', '🙂'.repeat(24) + '가🙂'],
  ['whitespace-around-split-boundary', '\u3000 ' + '가'.repeat(49) + '🙂 \u3000'],
  ['composed-latin-unchanged', 'José'],
  ['decomposed-latin-unchanged', 'Jose\u0301'],
  ['decomposed-korean-unchanged', '\u1100\u1161'],
  ['combining-mark-beyond-cap', '가'.repeat(49) + 'e\u0301'],
  ['zwj-grapheme-beyond-cap', '가'.repeat(48) + '👩‍💻'],
  ['modifier-grapheme-beyond-cap', '가'.repeat(48) + '👍🏻'],
  ['flag-grapheme-beyond-cap', '가'.repeat(48) + '🇰🇷'],
];

async function observe(id, inputName) {
  assert.ok(inputName.isWellFormed(), `${id}: the synthetic input must be well-formed`);
  const jsonText = JSON.stringify({ name: inputName, ...solarPayload });
  const body = await parser.parseJsonBody({ json: async () => JSON.parse(jsonText) });
  const parsed = parser.parseSajuInput(body);
  const { name, ...birthFields } = parsed;
  assert.deepEqual(birthFields, expectedBirthFields, `${id}: valid solar birth remains intact`);
  assert.equal(name, inputName.trim().slice(0, 50), `${id}: evidence must match the old parser contract`);
  assert.ok(name.length > 0 && name.length <= 50, `${id}: established cap is UTF-16 units`);
  const trimmed = inputName.trim();
  if (trimmed.length <= 50) assert.equal(name, trimmed, `${id}: accepted in-cap input remains exact`);
  const bufferRoundTrip = Buffer.from(name, 'utf8').toString('utf8');
  const textCodecRoundTrip = new TextDecoder().decode(new TextEncoder().encode(name));
  const jsonRoundTrip = JSON.parse(Buffer.from(JSON.stringify({ name }), 'utf8').toString('utf8')).name;
  const urlRoundTrip = new URLSearchParams(new URLSearchParams({ name }).toString()).get('name');
  let uri;
  try { uri = { kind: 'ok', value: encodeURIComponent(name) }; }
  catch (error) { uri = { kind: 'error', name: error.name, message: error.message }; }
  assert.equal(bufferRoundTrip, textCodecRoundTrip);
  assert.equal(jsonRoundTrip, name, `${id}: JSON escaping preserves even lone surrogate code units`);
  assert.equal(bufferRoundTrip === name, name.isWellFormed());
  assert.equal(urlRoundTrip === name, name.isWellFormed());
  assert.equal(uri.kind === 'ok', name.isWellFormed());
  return {
    id, input: inspect(inputName), trimmed: inspect(trimmed), output: inspect(name),
    directUtf8RoundTrip: { equal: bufferRoundTrip === name, value: inspect(bufferRoundTrip) },
    textEncoderRoundTripEqual: textCodecRoundTrip === name,
    jsonUtf8RoundTripEqual: jsonRoundTrip === name,
    urlSearchParamsRoundTripEqual: urlRoundTrip === name,
    uriEncoding: uri,
    solarBirthFieldsUnchanged: true,
  };
}

const observations = [];
for (const [id, name] of namedCases) observations.push(await observe(id, name));
const matrix = [];
const tails = ['A', '가', '𠮷', '🙂', 'e\u0301', '👩‍💻', '👍🏻', '🇰🇷'];
for (const prefix of ['가', '🙂']) {
  for (let count = 0; count <= 55; count++) {
    for (const [tailIndex, tail] of tails.entries()) {
      const result = await observe(`matrix-${prefix.codePointAt(0).toString(16)}-${count}-${tailIndex}`, prefix.repeat(count) + tail);
      matrix.push({
        id: result.id, inputUnits: result.input.utf16Units, outputUnits: result.output.utf16Units,
        wellFormed: result.output.wellFormed, utf8RoundTripEqual: result.directUtf8RoundTrip.equal,
      });
    }
  }
}
const invalidNameControls = [];
for (const [id, name] of [['empty', ''], ['whitespace-only', ' \t\u3000\r\n'], ['non-string', 42], ['missing', undefined]]) {
  let observed;
  try { parser.parseSajuInput({ name, ...solarPayload }); }
  catch (error) { observed = { name: error.name, status: error.status, message: error.message }; }
  assert.deepEqual(observed, { name: 'SajuInputError', status: 400, message: '이름을 입력해주세요.' });
  invalidNameControls.push({ id, error: observed });
}
// Diagnostic controls only: no proposal to sanitize or newly reject already malformed input.
const alreadyMalformedControls = [];
for (const [id, name] of [['preexisting-high-surrogate', '가'.repeat(49) + '\ud83d'], ['preexisting-low-surrogate', '가'.repeat(49) + '\ude42']]) {
  assert.equal(name.isWellFormed(), false);
  const output = parser.parseSajuInput({ name, ...solarPayload }).name;
  assert.equal(output, name);
  alreadyMalformedControls.push({ id, output: inspect(output) });
}
assert.throws(() => parser.parseSajuInput({ name: '홍길동', ...solarPayload, birthYear: 2001 }), {
  name: 'SajuInputError', message: '존재하지 않는 생년월일입니다. 날짜를 다시 확인해주세요.',
});
// Independently exercise the import seam so accidentally invoking lunar conversion cannot pass unnoticed.
assert.throws(() => parser.parseSajuInput({ name: '홍길동', ...solarPayload, calendarType: 'lunar' }), /SOLAR_ONLY_LUNAR_SEAM_CALLED/);

const namedFailures = observations.filter((item) => !item.output.wellFormed).map((item) => item.id);
assert.deepEqual(namedFailures, ['emoji-at-50-51', 'astral-cjk-at-50-51', '24-emojis-bmp-emoji', 'whitespace-around-split-boundary']);
const after = snapshot();
assert.deepEqual(after, before, 'No tracked source bytes, revision or status may change');
writeFileSync(path.join("/workspace/scratch/c9f1a9454187/saju_name_boundary_investigation_20261009/review/evidence", 'source-after.json'), JSON.stringify(after, null, 2) + '\n');
const evidence = {
  result: 'Historical parser data corruption reproduced; no fix implemented',
  runtime: process.version, sourceRoot, head: before.head,
  parserSha256: sha256(inputSource), errorModuleSha256: sha256(errorSource),
  sourceFilesHashed: Object.keys(before.trackedFiles).length, sourcePreserved: true,
  method: {
    parser: 'Actual historical input.ts, built-in TypeScript strip mode; only 3 import/re-export specifiers replaced in memory',
    error: 'Actual input-error.ts, built-in TypeScript transform mode for constructor parameter property',
    lunar: 'Throwing explicit seam; no lunar package loaded; seam checked once separately',
    birthPayload: solarPayload, jsonIngress: 'Actual parseJsonBody then actual parseSajuInput',
  },
  totals: {
    namedWellFormedInputs: observations.length,
    namedFailures,
    generatedWellFormedInputs: matrix.length,
    generatedFailures: matrix.filter((item) => !item.wellFormed).length,
    invalidNameControls: invalidNameControls.length,
    alreadyMalformedControls: alreadyMalformedControls.length,
  },
  observations, matrix, invalidNameControls, alreadyMalformedControls,
};
writeFileSync(path.join("/workspace/scratch/c9f1a9454187/saju_name_boundary_investigation_20261009/review/evidence", 'evidence.json'), JSON.stringify(evidence, null, 2) + '\n');
console.log(JSON.stringify({ ...evidence, observations: undefined, matrix: undefined, invalidNameControls: undefined, alreadyMalformedControls: undefined }, null, 2));
if (process.argv.includes('--require-well-formed')) {
  assert.equal(namedFailures.length, 0, 'REGRESSION: valid names must not become ill-formed at the 50 UTF-16-unit boundary');
}
