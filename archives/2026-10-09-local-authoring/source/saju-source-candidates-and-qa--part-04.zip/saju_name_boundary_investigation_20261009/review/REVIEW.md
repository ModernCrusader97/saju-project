# Independent review: historical SaJu name-boundary candidate

Reviewed on 2026-10-09 using Node v24.19.0. Verdict: no blocking correctness, scope, or packaging issue found in this standalone historical-source candidate. This is a bounded approval of the algorithm and reproducible evidence, not approval of integration into unavailable latest source or of an application build/deployment.

The final frozen package manifest is SHA-256 `ef644ac0520010d9ecb387807dfd7eff56439b747640e20e51be37f91ef2da8c`. Runtime review used the preceding manifest `66d1e59174f4784e7547a7b4925a867fb8ca0a984daf4aa64a74a709fa2563f7`; all 26 listed files matched before and after those runs. The subsequent documentation-only refreeze changes README.md to link this completed review. Its complete diff was reviewed, the other 25 frozen code/test/evidence/snapshot files were independently confirmed byte-identical, and all 26 final hashes were checked. No repeat execution was needed for that documentation change. Review writes were confined to `review/`; the reviewer did not change the historical checkout or frozen package files.

## Findings and behavior

The candidate changes only the historical parser's name truncation call and adds a 15-line helper. It retains the existing string check, calls `trim()` in the same place, supplies the same 50 UTF-16-unit limit, and leaves the rest of the parser byte-for-byte intact. An independent unified-diff reader reconstructed the candidate from `candidate.patch` and executed it. The patched helper exactly equals `candidate/name-boundary.ts`.

The helper inspects the units immediately before and after the cut. It backs off one unit only when the first is U+D800–U+DBFF and the second is U+DC00–U+DFFF, with inclusive bounds. The early return preserves in-cap strings exactly. The documented caller precondition is a non-negative integer cap; production demonstration passes 50. No normalization, grapheme segmentation, whole-string repair, new rejection policy, or alternative name-length policy was introduced.

The historical failure was reproduced through actual `parseJsonBody` and `parseSajuInput`: 49 Korean BMP characters followed by 🙂 produce 50 units ending in U+D83D. The candidate returns the 49 intact Korean units. An astral character fitting at units 49–50 remains intact; one starting after the 50-unit cap is still omitted. Korean, ASCII, astral CJK, emoji, whitespace trimming, decomposed Latin/Korean, 25/26-emoji boundaries, and adjacent surrogate-range endpoints retain the intended contract.

Malformed strings already present in input remain malformed except for the separately valid pair cut by truncation. Combining marks, ZWJ sequences, modifiers, and flags can still be truncated between complete code points. These are explicit scope limits, not newly repaired behavior.

The transport explanation is correct: direct UTF-8 conversion and URLSearchParams replace a lone surrogate with U+FFFD; encodeURIComponent throws URIError. JSON.stringify escapes and preserves the malformed UTF-16 unit through a JSON/UTF-8/parse round trip. The evidence does not establish corruption by JSON serialization or actual storage. The README's cited historical parser callers/storage paths were checked statically; they were not executed end to end.

## Fresh verification

The following final commands completed as expected:

- `node review/verify-frozen-package.mjs` exited 0 after nine subprocess runs with their expected individual exit codes.
- `node review/independent-checks.mjs` exited 0 with 5,573 independent checks passing.
- `git -C ../saju_planet_preview apply --check "$PWD/candidate.patch"` exited 0 without applying the patch.

Published-suite rerun:

- Historical baseline: 986 checks, 968 passing, 18 expected failures, exit 1.
- Candidate: 987 checks, all passing, exit 0.
- Reproduction: 28 named well-formed inputs and 896 generated inputs; four named and nine generated split-pair failures in the old parser. Named and generated cases overlap and are not incident counts.
- The extra candidate check is one helper-level group with seven assertions. The current 986/987 totals supersede the earlier 937/938 totals. The 49 endpoint combinations add four baseline failures.
- Final evidence and result JSON matched the frozen published files exactly. Relocated reproduction differs only in its recorded sourceRoot path.

Independent checks executed the actual patch rather than the author's in-memory replacement code:

- 5,000 deterministic scalar-prefix cases cover arbitrary supplied caps, valid Unicode, malformed units, ordinary whitespace, combining sequences, and zero-cap behavior using an iterator-based oracle.
- 560 parser comparisons preserve non-name outputs and exact error name/message/status across gender, calendar type, numeric/string date/time fields, valid/invalid solar dates, unknown-time behavior, unsupported lunar dates, and invalid values.
- Nine top-level invalid/empty payload comparisons preserve object/name validation.
- Four grouped checks cover JSON ingress failures, wire/URL differences, trim order/no normalization, omission of unrelated fields, and unchanged HOUR_PERIODS.

The independent checks are additional review evidence; their totals should not be summed with the published suite as a count of unique scenarios or individual assertions.

Packaging verification copied the 26 frozen files into `review/detached/candidate-package`, where no sibling historical checkout exists. Reproduction, baseline, and candidate were run there with an empty PATH and Node permissions allowing reads only inside that copied package. All produced the expected results. This verifies default execution does not require Git or the historical checkout. An explicitly missing checkout reported `unavailable`, verified=false, and exit 1 despite 987 passing functional checks. A deliberately altered review-only snapshot was rejected by its hash assertion before tests; it was then restored and all copied frozen hashes rechecked.

Separate explicit verification of the real old checkout confirmed clean HEAD `843a4a088a9e20760421b4c81f890d026a53ae6b` and all 151 tracked file hashes matching the captured manifest. The independent suite also compared complete before/after source snapshots. Git status remained empty.

## Execution boundaries and integration requirement

The published suite runs the actual snapshotted historical parser and actual error class after Node TypeScript stripping/transformation. Only dependency specifiers are rewritten in memory; the candidate additionally substitutes the narrow helper import/call. Request.json is supplied by a controlled JSON round trip, not a framework HTTP server. The published lunar dependency is an explicit throwing seam, separately exercised. The independent field-parity suite uses a deterministic lunar seam to inspect argument/branch preservation; it does not validate real lunar conversion.

No TypeScript semantic typecheck, package installation, application build, browser rendering, framework request/response, database write, latest-source test, integration, deployment, network, credentials, or external-account action was performed. Node's experimental stripTypeScriptTypes warning is expected. The README's claim about the order of the earliest red run is implementation provenance; this review independently establishes current red/green behavior, not that earlier event's timing.

Latest source 2709bb7 was not accessed. The reported queued 28fa9f4 shared name contract was not inspected in this review. Integration must reuse that restored canonical helper and shared limit, preserve its existing validation policies, and rerun applicable project checks. The historical patch's literal 50 is a demonstration of the old contract. It must not introduce duplicate frontend/backend rules, replace the latest input.ts wholesale, or weaken any newer malformed-input policy.

## Exact reviewed hashes

- Historical `lib/saju/input.ts`: `7880ae0a8808631918cc3d33ac4acc39955443fac9c4d24acc11077b17e220cf`
- Historical `lib/saju/input-error.ts`: `a1533c1b2c00755ed076e978990d0fb8119ec80ff5599096da4781990b54285a`
- `candidate/name-boundary.ts`: `4d84f006107e4b30aa60598574fdd4a6160fef03d25a7743e6a29b3e6887f53f`
- `candidate.patch`: `8e07392e6761c52b599f267840f5b81fe8755015262937112d9e0e7ba332a817`
- Independently reconstructed parser: `8e481fe700c35d43c74a63011371cc643db1b735333ce78bddd0795d0071f33b`
- `test-boundary.mjs`: `441feae52692b51dd4cbb1b83040ac553106effdb73582f58453e64cde5d9bdc`
- `reproduce.mjs`: `a9936fd126ca989d2daef5657c0109188d49fe0ec21c1f94ecf2fe93ba58259e`
- `harness-support.mjs`: `c415bbc3e22d69289b7c9b41ad25b95af0508d80287ed728f12c150f6c519d0d`
- Final `README.md`: `ad4753b5a9e31c0afc0076bb40b68ebe07fa8eea908be5800b1716cc65244f54` (documentation-only update from runtime-reviewed `6a6f2d09b3e584652130a736c3fe94111c65421f245cf46dfda4bb3c6283d378`)
- `review/verify-frozen-package.mjs`: `3fb00c51bf16ae22d153248d2438d36bf1ff15ecbe08a98d0d95b26082f4db5e`
- `review/independent-checks.mjs`: `07d74e1a9cf272aa557fd51fe332cf16bda4160e9a87dea76d8acb86188b7292`
- `review/published-rerun.json`: `b2a65bf8775c1eccfae0774d10986e6023e8a157a2a85baf9f0d42a4c4baeca0`
- `review/independent-results.json`: `b88e58f63bc1684ee9dda91cc0fed2911d46bf9fd21c0fc62998f89445f01d2a`

Current review evidence is in `published-rerun.json`, `independent-results.json`, and `final-runs/`. Earlier review-only output under `baseline/`, `candidate/`, `evidence/`, and the `published-*.mjs`/`run-published.mjs` files predates self-contained packaging and is retained as historical review work; it is not the final verification harness.
