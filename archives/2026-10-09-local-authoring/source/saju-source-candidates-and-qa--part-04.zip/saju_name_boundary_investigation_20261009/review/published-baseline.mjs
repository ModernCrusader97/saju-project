// One unchanged contract suite against the real old parser or a narrowly patched in-memory copy.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { stripTypeScriptTypes } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const artifactDir = "/workspace/scratch/c9f1a9454187/saju_name_boundary_investigation_20261009";
const root = path.resolve(artifactDir, '../saju_planet_preview');
const candidate = process.argv.includes('--candidate');
const sha256 = (text) => createHash('sha256').update(text).digest('hex');
const dataUrl = (source) => `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
const evidence = JSON.parse(readFileSync(path.join(artifactDir, 'evidence.json'), 'utf8'));
const manifest = JSON.parse(readFileSync(path.join(artifactDir, 'source-before.json'), 'utf8'));
const original = readFileSync(path.join(root, 'lib/saju/input.ts'), 'utf8');
assert.equal(sha256(original), evidence.parserSha256);
const errorSource = readFileSync(path.join(root, 'lib/saju/input-error.ts'), 'utf8');
const errorUrl = dataUrl(stripTypeScriptTypes(errorSource, { mode: 'transform' }));
const lunarUrl = dataUrl('export function koreanLunarToSolar() { throw new Error("SOLAR_ONLY_LUNAR_SEAM_CALLED"); }');
let source = original;
let helper;
let helperSource;
if (candidate) {
  helperSource = readFileSync(path.join(artifactDir, 'candidate/name-boundary.ts'), 'utf8');
  const helperUrl = dataUrl(stripTypeScriptTypes(helperSource, { mode: 'strip' }));
  helper = (await import(helperUrl)).truncateUtf16WithoutSplittingPair;
  const oldLine = '  const name = typeof input.name === "string" ? input.name.trim().slice(0, 50) : "";';
  assert.equal(source.split(oldLine).length - 1, 1);
  source = source.replace(oldLine, '  const name = typeof input.name === "string" ? truncateUtf16WithoutSplittingPair(input.name.trim(), 50) : "";');
  source = `import { truncateUtf16WithoutSplittingPair } from ${JSON.stringify(helperUrl)};\n` + source;
}
source = source.replaceAll('"./input-error"', JSON.stringify(errorUrl))
  .replace('"./lunar-calendar"', JSON.stringify(lunarUrl));
const parser = await import(dataUrl(stripTypeScriptTypes(source, { mode: 'strip' })));
const birth = evidence.method.birthPayload;
const expectedBirth = { ...birth, solarBirthDate: { year: 2000, month: 2, day: 29 } };
const results = [];
async function check(name, action) {
  try { await action(); results.push({ name, passed: true }); }
  catch (error) { results.push({ name, passed: false, error: error.message }); }
}
async function parseName(name, overrides = {}) {
  const serialized = JSON.stringify({ name, ...birth, ...overrides });
  const body = await parser.parseJsonBody({ json: async () => JSON.parse(serialized) });
  return parser.parseSajuInput(body);
}
// Independent oracle for WELL-FORMED names only: longest prefix of whole code points inside 50 units.
function wholeCodePointPrefix(value) {
  let result = '';
  for (const codePoint of value.trim()) {
    if (result.length + codePoint.length > 50) break;
    result += codePoint;
  }
  return result;
}
async function validInputCheck(value) {
  assert.equal(value.isWellFormed(), true);
  const { name, ...date } = await parseName(value);
  assert.equal(name, wholeCodePointPrefix(value), 'Preserve complete code points inside the existing UTF-16 cap');
  assert.equal(name.isWellFormed(), true, 'A valid name must remain well-formed');
  assert.ok(name.length <= 50);
  assert.deepEqual(date, expectedBirth);
  assert.equal(Buffer.from(name, 'utf8').toString('utf8'), name);
  assert.equal(new TextDecoder().decode(new TextEncoder().encode(name)), name);
  assert.equal(JSON.parse(Buffer.from(JSON.stringify({ name }), 'utf8').toString('utf8')).name, name);
  assert.equal(new URLSearchParams(new URLSearchParams({ name }).toString()).get('name'), name);
  assert.equal(decodeURIComponent(encodeURIComponent(name)), name);
  if (value.trim().length <= 50) assert.equal(name, value.trim());
}
// The production change that makes these tests pass is only boundary-aware truncation.
for (const item of evidence.observations) {
  await check(`actual parser: ${item.id}`, () => validInputCheck(JSON.parse(item.input.escapedJson)));
}
const tails = ['A', '가', '𠮷', '🙂', 'e\u0301', '👩‍💻', '👍🏻', '🇰🇷'];
for (const prefix of ['가', '🙂']) {
  for (let count = 0; count <= 55; count++) {
    for (const [tailIndex, tail] of tails.entries()) {
      await check(`actual parser matrix ${prefix.codePointAt(0).toString(16)}-${count}-${tailIndex}`,
        () => validInputCheck(prefix.repeat(count) + tail));
    }
  }
}
for (const [id, name] of [['empty', ''], ['whitespace-only', ' \t\u3000\r\n'], ['non-string', 42], ['missing', undefined]]) {
  await check(`unchanged rejection: ${id}`, async () => {
    await assert.rejects(() => parseName(name), { name: 'SajuInputError', status: 400, message: '이름을 입력해주세요.' });
  });
}
for (const [id, name] of [
  ['isolated-high-at-cap', '가'.repeat(49) + '\ud83d'],
  ['isolated-low-at-cap', '가'.repeat(49) + '\ude42'],
  ['isolated-high-before-bmp-overflow', '가'.repeat(49) + '\ud83dA'],
  ['malformed-interior', '\ud83dA' + '가'.repeat(55)],
]) {
  await check(`preserve malformed input outside split-pair case: ${id}`, async () => {
    const { name: output } = await parseName(name);
    assert.equal(output, name.trim().slice(0, 50));
    assert.equal(output.isWellFormed(), false);
  });
}
await check('malformed interior remains, only boundary pair backs off', async () => {
  const { name } = await parseName('\ud800' + '가'.repeat(48) + '🙂');
  assert.equal(name, '\ud800' + '가'.repeat(48));
  assert.equal(name.isWellFormed(), false);
});
await check('no Unicode normalization', async () => {
  assert.equal((await parseName('Jose\u0301')).name, 'Jose\u0301');
  assert.equal((await parseName('\u1100\u1161')).name, '\u1100\u1161');
});
await check('grapheme preservation remains outside scope', async () => {
  assert.equal((await parseName('가'.repeat(49) + 'e\u0301')).name, '가'.repeat(49) + 'e');
  assert.equal((await parseName('가'.repeat(48) + '👩‍💻')).name, '가'.repeat(48) + '👩');
  assert.equal((await parseName('가'.repeat(48) + '👍🏻')).name, '가'.repeat(48) + '👍');
  assert.equal((await parseName('가'.repeat(48) + '🇰🇷')).name, '가'.repeat(48) + '🇰');
});
await check('solar date validation remains real', async () => {
  await assert.rejects(() => parseName('홍길동', { birthYear: 2001 }), {
    name: 'SajuInputError', message: '존재하지 않는 생년월일입니다. 날짜를 다시 확인해주세요.',
  });
});
await check('lunar dependency is an explicit throwing seam', async () => {
  await assert.rejects(() => parseName('홍길동', { calendarType: 'lunar' }), /SOLAR_ONLY_LUNAR_SEAM_CALLED/);
});
// Exercise the inclusive surrogate-range endpoints and their nearest non-surrogate neighbors.
// The scalar oracle is independent of the helper's explicit numeric range comparisons.
const boundaryUnits = [0x0041, 0xd7ff, 0xd800, 0xdbff, 0xdc00, 0xdfff, 0xe000];
for (const first of boundaryUnits) {
  for (const second of boundaryUnits) {
    await check(`boundary endpoint units ${first.toString(16)}-${second.toString(16)}`, async () => {
      const suffix = String.fromCharCode(first, second);
      const input = '가'.repeat(49) + suffix;
      const isExistingPair = [...suffix].length === 1 && suffix.codePointAt(0) > 0xffff;
      const expected = isExistingPair ? '가'.repeat(49) : input.slice(0, 50);
      assert.equal((await parseName(input)).name, expected);
    });
  }
}
if (candidate) {
  await check('helper respects supplied shared limit without trimming or normalizing', () => {
    assert.equal(helper('A🙂', 2), 'A');
    assert.equal(helper('A🙂', 3), 'A🙂');
    assert.equal(helper('🙂', 1), '');
    assert.equal(helper('🙂', 2), '🙂');
    assert.equal(helper('🙂', 0), '');
    assert.equal(helper(' A ', 50), ' A ');
    assert.equal(helper('e\u0301', 1), 'e');
  });
}
const gitOptions = { cwd: root, encoding: 'utf8', env: { ...process.env, GIT_OPTIONAL_LOCKS: '0' } };
assert.equal(execFileSync('git', ['rev-parse', 'HEAD'], gitOptions).trim(), manifest.head);
assert.equal(execFileSync('git', ['status', '--porcelain=v1'], gitOptions), manifest.status);
for (const [name, hash] of Object.entries(manifest.trackedFiles)) {
  assert.equal(sha256(readFileSync(path.join(root, name))), hash, `Source file changed: ${name}`);
}
const summary = {
  mode: candidate ? 'candidate' : 'baseline', runtime: process.version,
  historicalParserSha256: sha256(original), helperSha256: helperSource === undefined ? null : sha256(helperSource),
  historicalSourcePreserved: true,
  tests: results.length, passed: results.filter((result) => result.passed).length,
  failed: results.filter((result) => !result.passed).length,
};
writeFileSync(path.join("/workspace/scratch/c9f1a9454187/saju_name_boundary_investigation_20261009/review/baseline", candidate ? 'green-results.json' : 'red-results.json'), JSON.stringify({ summary, results }, null, 2) + '\n');
console.log(JSON.stringify(summary, null, 2));
for (const failure of results.filter((result) => !result.passed)) console.error(`FAIL ${failure.name}: ${failure.error}`);
process.exitCode = summary.failed ? 1 : 0;
