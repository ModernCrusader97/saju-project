import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const review = path.dirname(fileURLToPath(import.meta.url));
const artifact = path.dirname(review);
const sha256 = value => createHash('sha256').update(value).digest('hex');
const outcomes = [];
for (const [script, modes] of [['reproduce.mjs', ['evidence']], ['test-boundary.mjs', ['baseline', 'candidate']]]) {
  const original = readFileSync(path.join(artifact, script), 'utf8');
  const dirLine = 'const artifactDir = path.dirname(fileURLToPath(import.meta.url));';
  assert.equal(original.split(dirLine).length - 1, 1);
  for (const mode of modes) {
    const outputDir = path.join(review, mode);
    mkdirSync(outputDir, { recursive: true });
    // Change only import.meta-based input location and write destinations. Assertions are untouched.
    const isolated = original.replace(dirLine, `const artifactDir = ${JSON.stringify(artifact)};`)
      .replaceAll('writeFileSync(path.join(artifactDir,', `writeFileSync(path.join(${JSON.stringify(outputDir)},`);
    assert.ok(isolated.includes(`writeFileSync(path.join(${JSON.stringify(outputDir)},`));
    const runner = path.join(review, `published-${mode}.mjs`);
    writeFileSync(runner, isolated);
    const result = spawnSync(process.execPath, [runner, ...(mode === 'candidate' ? ['--candidate'] : [])], { encoding: 'utf8' });
    writeFileSync(path.join(outputDir, 'stdout.log'), result.stdout);
    writeFileSync(path.join(outputDir, 'stderr.log'), result.stderr);
    const summaryFile = mode === 'evidence' ? 'evidence.json' : mode === 'candidate' ? 'green-results.json' : 'red-results.json';
    const document = JSON.parse(readFileSync(path.join(outputDir, summaryFile), 'utf8'));
    const summary = document.summary ?? document.totals;
    outcomes.push({ script, mode, scriptSha256: sha256(original), isolatedRunnerSha256: sha256(isolated), exitCode: result.status, summary });
    assert.equal(result.status, mode === 'baseline' ? 1 : 0);
    const published = readFileSync(path.join(artifact, summaryFile));
    assert.equal(sha256(readFileSync(path.join(outputDir, summaryFile))), sha256(published), `${mode} output differs from published evidence`);
  }
}
writeFileSync(path.join(review, 'published-rerun.json'), JSON.stringify(outcomes, null, 2) + '\n');
console.log(JSON.stringify(outcomes, null, 2));
