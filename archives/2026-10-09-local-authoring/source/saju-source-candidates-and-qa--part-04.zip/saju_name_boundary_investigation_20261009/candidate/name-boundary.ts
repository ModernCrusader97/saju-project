/**
 * Keep the existing UTF-16-unit cap without cutting an existing surrogate pair.
 * The caller supplies the shared non-negative integer limit and owns trimming.
 * This does not normalize text, preserve graphemes, or repair malformed input.
 */
export function truncateUtf16WithoutSplittingPair(value: string, maxUnits: number): string {
  if (value.length <= maxUnits) return value;
  let end = maxUnits;
  const before = value.charCodeAt(end - 1);
  const after = value.charCodeAt(end);
  if (before >= 0xd800 && before <= 0xdbff && after >= 0xdc00 && after <= 0xdfff) {
    end -= 1;
  }
  return value.slice(0, end);
}
