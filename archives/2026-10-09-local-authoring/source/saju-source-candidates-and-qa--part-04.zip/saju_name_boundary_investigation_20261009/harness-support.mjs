import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const artifactDir = path.dirname(fileURLToPath(import.meta.url));
export const snapshotRoot = path.join(artifactDir, 'snapshots/original');
const sha256 = (content) => createHash('sha256').update(content).digest('hex');
const expectedHead = '843a4a088a9e20760421b4c81f890d026a53ae6b';
const pinnedParserSha = '7880ae0a8808631918cc3d33ac4acc39955443fac9c4d24acc11077b17e220cf';
const pinnedErrorSha = 'a1533c1b2c00755ed076e978990d0fb8119ec80ff5599096da4781990b54285a';

export function readHashPinnedSnapshots() {
  const manifest = JSON.parse(readFileSync(path.join(artifactDir, 'snapshots/manifest.json'), 'utf8'));
  const originalManifest = JSON.parse(readFileSync(path.join(artifactDir, 'source-before.json'), 'utf8'));
  const originalAfter = JSON.parse(readFileSync(path.join(artifactDir, 'source-after.json'), 'utf8'));
  assert.equal(manifest.head, expectedHead);
  assert.equal(originalManifest.head, expectedHead);
  assert.equal(originalManifest.status, '');
  assert.deepEqual(originalAfter, originalManifest, 'Captured original source hashes must agree');
  assert.equal(manifest.trackedFiles['lib/saju/input.ts'], pinnedParserSha);
  assert.equal(manifest.trackedFiles['lib/saju/input-error.ts'], pinnedErrorSha);
  assert.deepEqual(Object.keys(manifest.trackedFiles).sort(), [
    'lib/saju/input-error.ts', 'lib/saju/input.ts', 'lib/saju/lunar-calendar.ts', 'lib/saju/types.ts',
  ]);
  for (const [name, expected] of Object.entries(manifest.trackedFiles)) {
    assert.equal(expected, originalManifest.trackedFiles[name], `Snapshot provenance: ${name}`);
    assert.equal(sha256(readFileSync(path.join(snapshotRoot, name))), expected, `Snapshot hash: ${name}`);
  }
  return manifest;
}

// Optional, explicit live-checkout check. Default artifact execution needs neither Git nor the old checkout.
export function verifyOriginalCheckout() {
  const option = process.argv.find((argument) => argument.startsWith('--verify-checkout='));
  if (!option) return { requested: false, status: 'not-requested', verified: false };
  const root = path.resolve(option.slice('--verify-checkout='.length));
  if (!existsSync(root)) return { requested: true, path: root, status: 'unavailable', verified: false };
  try {
    const manifest = JSON.parse(readFileSync(path.join(artifactDir, 'source-before.json'), 'utf8'));
    const options = { cwd: root, encoding: 'utf8', env: { ...process.env, GIT_OPTIONAL_LOCKS: '0' } };
    assert.equal(execFileSync('git', ['rev-parse', 'HEAD'], options).trim(), manifest.head);
    assert.equal(execFileSync('git', ['status', '--porcelain=v1'], options), manifest.status);
    for (const [name, expected] of Object.entries(manifest.trackedFiles)) {
      assert.equal(sha256(readFileSync(path.join(root, name))), expected, `Original checkout hash: ${name}`);
    }
    return { requested: true, path: root, status: 'verified', verified: true, files: Object.keys(manifest.trackedFiles).length };
  } catch (error) {
    return { requested: true, path: root, status: 'failed', verified: false, error: error.message };
  }
}

export function checkoutVerificationFailed(result) {
  return result.requested && !result.verified;
}
